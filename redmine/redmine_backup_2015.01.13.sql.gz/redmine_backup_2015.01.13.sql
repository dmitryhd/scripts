-- MySQL dump 10.13  Distrib 5.5.38, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: redmine
-- ------------------------------------------------------
-- Server version	5.5.38-0ubuntu0.14.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `container_id` int(11) DEFAULT NULL,
  `container_type` varchar(30) DEFAULT NULL,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `disk_filename` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `content_type` varchar(255) DEFAULT '',
  `digest` varchar(40) NOT NULL DEFAULT '',
  `downloads` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `disk_directory` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_attachments_on_author_id` (`author_id`),
  KEY `index_attachments_on_created_on` (`created_on`),
  KEY `index_attachments_on_container_id_and_container_type` (`container_id`,`container_type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
INSERT INTO `attachments` VALUES (1,5,'WikiPage','03_04_db.sql.tgz','141021144732_03_04_db.sql.tgz',3347599,'','7f5af3959c0fc58b2901f832f2962ea6',0,3,'2014-10-21 14:47:32','Последний дамп базы данных. create database 06_12_db_new; mysql -u root -p111111 06_12_db_new < 06_12_db.sql','2014/10'),(2,4,'WikiPage','JavaClient.jar','141021144944_JavaClient.jar',971907,'','8d62e85033f4dbf46ce894fe08bd5d3e',0,3,'2014-10-21 14:49:44','Клиент для KVM','2014/10'),(3,NULL,NULL,'tftp-server-0.32-4.i386.rpm','141021145335_tftp-server-0.32-4.i386.rpm',24804,'','708b564a48bde595c5ccebc6457e7a90',0,3,'2014-10-21 14:53:35',NULL,'2014/10'),(4,7,'WikiPage','libwrap0-7.6-882.5.i586.rpm','141021150817_libwrap0-7.6-882.5.i586.rpm',19422,'','3ec2d42d1e551e859b59bca0a5e45f64',0,3,'2014-10-21 15:08:17','','2014/10'),(5,7,'WikiPage','tftp-server-0.32-4.i386.rpm','141021150818_tftp-server-0.32-4.i386.rpm',24804,'','708b564a48bde595c5ccebc6457e7a90',0,3,'2014-10-21 15:08:18','','2014/10');
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_sources`
--

DROP TABLE IF EXISTS `auth_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(60) NOT NULL DEFAULT '',
  `host` varchar(60) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `account_password` varchar(255) DEFAULT '',
  `base_dn` varchar(255) DEFAULT NULL,
  `attr_login` varchar(30) DEFAULT NULL,
  `attr_firstname` varchar(30) DEFAULT NULL,
  `attr_lastname` varchar(30) DEFAULT NULL,
  `attr_mail` varchar(30) DEFAULT NULL,
  `onthefly_register` tinyint(1) NOT NULL DEFAULT '0',
  `tls` tinyint(1) NOT NULL DEFAULT '0',
  `filter` varchar(255) DEFAULT NULL,
  `timeout` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_auth_sources_on_id_and_type` (`id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_sources`
--

LOCK TABLES `auth_sources` WRITE;
/*!40000 ALTER TABLE `auth_sources` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boards`
--

DROP TABLE IF EXISTS `boards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT '1',
  `topics_count` int(11) NOT NULL DEFAULT '0',
  `messages_count` int(11) NOT NULL DEFAULT '0',
  `last_message_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `boards_project_id` (`project_id`),
  KEY `index_boards_on_last_message_id` (`last_message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boards`
--

LOCK TABLES `boards` WRITE;
/*!40000 ALTER TABLE `boards` DISABLE KEYS */;
/*!40000 ALTER TABLE `boards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changes`
--

DROP TABLE IF EXISTS `changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changeset_id` int(11) NOT NULL,
  `action` varchar(1) NOT NULL DEFAULT '',
  `path` text NOT NULL,
  `from_path` text,
  `from_revision` varchar(255) DEFAULT NULL,
  `revision` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `changesets_changeset_id` (`changeset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changes`
--

LOCK TABLES `changes` WRITE;
/*!40000 ALTER TABLE `changes` DISABLE KEYS */;
/*!40000 ALTER TABLE `changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changeset_parents`
--

DROP TABLE IF EXISTS `changeset_parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changeset_parents` (
  `changeset_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  KEY `changeset_parents_changeset_ids` (`changeset_id`),
  KEY `changeset_parents_parent_ids` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changeset_parents`
--

LOCK TABLES `changeset_parents` WRITE;
/*!40000 ALTER TABLE `changeset_parents` DISABLE KEYS */;
/*!40000 ALTER TABLE `changeset_parents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changesets`
--

DROP TABLE IF EXISTS `changesets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changesets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `repository_id` int(11) NOT NULL,
  `revision` varchar(255) NOT NULL,
  `committer` varchar(255) DEFAULT NULL,
  `committed_on` datetime NOT NULL,
  `comments` longtext,
  `commit_date` date DEFAULT NULL,
  `scmid` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `changesets_repos_rev` (`repository_id`,`revision`),
  KEY `index_changesets_on_user_id` (`user_id`),
  KEY `index_changesets_on_repository_id` (`repository_id`),
  KEY `index_changesets_on_committed_on` (`committed_on`),
  KEY `changesets_repos_scmid` (`repository_id`,`scmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changesets`
--

LOCK TABLES `changesets` WRITE;
/*!40000 ALTER TABLE `changesets` DISABLE KEYS */;
/*!40000 ALTER TABLE `changesets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changesets_issues`
--

DROP TABLE IF EXISTS `changesets_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changesets_issues` (
  `changeset_id` int(11) NOT NULL,
  `issue_id` int(11) NOT NULL,
  UNIQUE KEY `changesets_issues_ids` (`changeset_id`,`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changesets_issues`
--

LOCK TABLES `changesets_issues` WRITE;
/*!40000 ALTER TABLE `changesets_issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `changesets_issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commented_type` varchar(30) NOT NULL DEFAULT '',
  `commented_id` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `comments` text,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_comments_on_commented_id_and_commented_type` (`commented_id`,`commented_type`),
  KEY `index_comments_on_author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `field_format` varchar(30) NOT NULL DEFAULT '',
  `possible_values` text,
  `regexp` varchar(255) DEFAULT '',
  `min_length` int(11) DEFAULT NULL,
  `max_length` int(11) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_for_all` tinyint(1) NOT NULL DEFAULT '0',
  `is_filter` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT '1',
  `searchable` tinyint(1) DEFAULT '0',
  `default_value` text,
  `editable` tinyint(1) DEFAULT '1',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `multiple` tinyint(1) DEFAULT '0',
  `format_store` text,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `index_custom_fields_on_id_and_type` (`id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields_projects`
--

DROP TABLE IF EXISTS `custom_fields_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields_projects` (
  `custom_field_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `index_custom_fields_projects_on_custom_field_id_and_project_id` (`custom_field_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields_projects`
--

LOCK TABLES `custom_fields_projects` WRITE;
/*!40000 ALTER TABLE `custom_fields_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields_roles`
--

DROP TABLE IF EXISTS `custom_fields_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields_roles` (
  `custom_field_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  UNIQUE KEY `custom_fields_roles_ids` (`custom_field_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields_roles`
--

LOCK TABLES `custom_fields_roles` WRITE;
/*!40000 ALTER TABLE `custom_fields_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields_trackers`
--

DROP TABLE IF EXISTS `custom_fields_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields_trackers` (
  `custom_field_id` int(11) NOT NULL DEFAULT '0',
  `tracker_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `index_custom_fields_trackers_on_custom_field_id_and_tracker_id` (`custom_field_id`,`tracker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields_trackers`
--

LOCK TABLES `custom_fields_trackers` WRITE;
/*!40000 ALTER TABLE `custom_fields_trackers` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields_trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_values`
--

DROP TABLE IF EXISTS `custom_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customized_type` varchar(30) NOT NULL DEFAULT '',
  `customized_id` int(11) NOT NULL DEFAULT '0',
  `custom_field_id` int(11) NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`),
  KEY `custom_values_customized` (`customized_type`,`customized_id`),
  KEY `index_custom_values_on_custom_field_id` (`custom_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_values`
--

LOCK TABLES `custom_values` WRITE;
/*!40000 ALTER TABLE `custom_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(60) NOT NULL DEFAULT '',
  `description` text,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_project_id` (`project_id`),
  KEY `index_documents_on_category_id` (`category_id`),
  KEY `index_documents_on_created_on` (`created_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enabled_modules`
--

DROP TABLE IF EXISTS `enabled_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enabled_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `enabled_modules_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enabled_modules`
--

LOCK TABLES `enabled_modules` WRITE;
/*!40000 ALTER TABLE `enabled_modules` DISABLE KEYS */;
INSERT INTO `enabled_modules` VALUES (1,1,'issue_tracking'),(2,1,'time_tracking'),(3,1,'news'),(4,1,'documents'),(5,1,'files'),(6,1,'wiki'),(7,1,'repository'),(8,1,'boards'),(9,1,'calendar'),(10,1,'gantt'),(11,2,'issue_tracking'),(12,2,'time_tracking'),(16,2,'wiki'),(21,2,'redmine_timetracker_plugin'),(22,3,'issue_tracking'),(23,3,'time_tracking'),(24,3,'wiki'),(25,3,'redmine_timetracker_plugin');
/*!40000 ALTER TABLE `enabled_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enumerations`
--

DROP TABLE IF EXISTS `enumerations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enumerations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `position` int(11) DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `project_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `position_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_enumerations_on_project_id` (`project_id`),
  KEY `index_enumerations_on_id_and_type` (`id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enumerations`
--

LOCK TABLES `enumerations` WRITE;
/*!40000 ALTER TABLE `enumerations` DISABLE KEYS */;
INSERT INTO `enumerations` VALUES (1,'Low',1,0,'IssuePriority',1,NULL,NULL,'lowest'),(2,'Normal',2,1,'IssuePriority',1,NULL,NULL,'default'),(3,'High',3,0,'IssuePriority',1,NULL,NULL,'high3'),(4,'Urgent',4,0,'IssuePriority',1,NULL,NULL,'high2'),(5,'Immediate',5,0,'IssuePriority',1,NULL,NULL,'highest'),(6,'User documentation',1,0,'DocumentCategory',1,NULL,NULL,NULL),(7,'Technical documentation',2,0,'DocumentCategory',1,NULL,NULL,NULL),(8,'Design',2,0,'TimeEntryActivity',1,NULL,NULL,NULL),(9,'Development',1,0,'TimeEntryActivity',1,NULL,NULL,NULL),(10,'Design',3,0,'TimeEntryActivity',1,2,8,NULL),(11,'Development',4,0,'TimeEntryActivity',1,2,9,NULL);
/*!40000 ALTER TABLE `enumerations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_users`
--

DROP TABLE IF EXISTS `groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups_users` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  UNIQUE KEY `groups_users_ids` (`group_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups_users`
--

LOCK TABLES `groups_users` WRITE;
/*!40000 ALTER TABLE `groups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_categories`
--

DROP TABLE IF EXISTS `issue_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(30) NOT NULL DEFAULT '',
  `assigned_to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_categories_project_id` (`project_id`),
  KEY `index_issue_categories_on_assigned_to_id` (`assigned_to_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_categories`
--

LOCK TABLES `issue_categories` WRITE;
/*!40000 ALTER TABLE `issue_categories` DISABLE KEYS */;
INSERT INTO `issue_categories` VALUES (1,2,'GUI',NULL),(2,2,'system bug',3),(3,2,'Менеджмент',NULL),(4,2,'architecture',3),(5,2,'Инструментарий',NULL),(6,2,'Настройка',3),(7,2,'testing',3),(8,2,'Отчеты',NULL),(9,2,'Железо',NULL),(10,2,'Рефакторинг',3),(11,2,'hardware bug',3),(12,2,'План',3);
/*!40000 ALTER TABLE `issue_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_relations`
--

DROP TABLE IF EXISTS `issue_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_from_id` int(11) NOT NULL,
  `issue_to_id` int(11) NOT NULL,
  `relation_type` varchar(255) NOT NULL DEFAULT '',
  `delay` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_issue_relations_on_issue_from_id_and_issue_to_id` (`issue_from_id`,`issue_to_id`),
  KEY `index_issue_relations_on_issue_from_id` (`issue_from_id`),
  KEY `index_issue_relations_on_issue_to_id` (`issue_to_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_relations`
--

LOCK TABLES `issue_relations` WRITE;
/*!40000 ALTER TABLE `issue_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_statuses`
--

DROP TABLE IF EXISTS `issue_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT '1',
  `default_done_ratio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_issue_statuses_on_position` (`position`),
  KEY `index_issue_statuses_on_is_closed` (`is_closed`),
  KEY `index_issue_statuses_on_is_default` (`is_default`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_statuses`
--

LOCK TABLES `issue_statuses` WRITE;
/*!40000 ALTER TABLE `issue_statuses` DISABLE KEYS */;
INSERT INTO `issue_statuses` VALUES (1,'New',0,1,1,NULL),(2,'In Progress',0,0,2,NULL),(3,'Resolved',0,0,3,NULL),(4,'Feedback',0,0,4,NULL),(5,'Closed',1,0,5,NULL),(6,'Rejected',1,0,6,NULL);
/*!40000 ALTER TABLE `issue_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `due_date` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `assigned_to_id` int(11) DEFAULT NULL,
  `priority_id` int(11) NOT NULL,
  `fixed_version_id` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `lock_version` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `done_ratio` int(11) NOT NULL DEFAULT '0',
  `estimated_hours` float DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `root_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `closed_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issues_project_id` (`project_id`),
  KEY `index_issues_on_status_id` (`status_id`),
  KEY `index_issues_on_category_id` (`category_id`),
  KEY `index_issues_on_assigned_to_id` (`assigned_to_id`),
  KEY `index_issues_on_fixed_version_id` (`fixed_version_id`),
  KEY `index_issues_on_tracker_id` (`tracker_id`),
  KEY `index_issues_on_priority_id` (`priority_id`),
  KEY `index_issues_on_author_id` (`author_id`),
  KEY `index_issues_on_created_on` (`created_on`),
  KEY `index_issues_on_root_id_and_lft_and_rgt` (`root_id`,`lft`,`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES (1,1,1,'sss','s',NULL,NULL,1,NULL,2,NULL,1,0,'2014-08-26 07:10:10','2014-08-26 07:10:10','2014-08-26',0,NULL,NULL,1,1,2,0,NULL),(2,2,2,'Слежение за процессом задачи','','2014-09-30',NULL,3,NULL,2,NULL,3,1,'2014-08-27 04:21:33','2015-01-12 08:57:09','2014-08-27',100,NULL,NULL,2,1,2,0,NULL),(3,2,2,'Проверка хэш суммы исполняемого файла (???)','','2014-09-30',NULL,1,NULL,1,NULL,3,1,'2014-08-27 04:21:57','2015-01-12 09:01:34','2014-08-27',0,NULL,135,135,20,21,0,NULL),(4,2,2,'Кукарекалка','','2014-09-30',NULL,1,NULL,2,NULL,3,2,'2014-08-27 04:22:09','2015-01-12 09:25:37','2014-08-27',0,NULL,131,131,40,41,0,NULL),(5,2,2,'Добавить поле у параметра, которое отключает сбор','','2014-09-30',1,1,3,2,NULL,3,2,'2014-08-27 04:23:50','2015-01-12 13:45:25','2014-08-27',0,2,131,131,38,39,0,NULL),(6,2,2,'веб - админка пользователя - окна сделать пошире','','2014-09-30',1,3,3,2,NULL,3,1,'2014-08-27 04:24:28','2015-01-12 09:00:43','2014-08-27',100,3,131,131,36,37,0,NULL),(7,2,2,'Руссификация полей модели','','2014-09-30',1,1,3,1,NULL,3,2,'2014-08-27 04:24:58','2015-01-12 13:45:32','2014-08-27',0,2,131,131,34,35,0,NULL),(8,2,2,'веб - часы крупнее','','2014-09-30',1,3,3,2,NULL,3,1,'2014-08-27 04:25:15','2014-09-05 02:11:59','2014-08-27',100,1,NULL,8,1,2,0,NULL),(9,2,2,'веб - страницы в журнале ','','2014-09-30',1,3,3,2,NULL,3,1,'2014-08-27 04:25:37','2014-09-05 01:07:47','2014-08-27',100,3,NULL,9,1,2,0,NULL),(10,1,2,'dhcp при отключении не продляет таймаут на выключение','','2014-10-31',2,1,3,2,NULL,3,1,'2014-08-27 04:27:14','2015-01-12 08:56:50','2014-08-27',0,3,135,135,16,17,0,NULL),(11,2,2,'веб - отображать статус dhcp ','','2014-09-30',1,3,3,2,NULL,3,2,'2014-08-27 04:27:58','2014-10-06 04:30:51','2014-08-27',100,NULL,NULL,11,1,2,0,NULL),(12,2,2,'веб - навигация по графику','сутки \r\nнеделя\r\nмесяц\r\nгод','2014-09-30',1,3,3,2,NULL,3,2,'2014-08-27 04:28:29','2014-10-23 14:10:51','2014-08-27',100,NULL,NULL,12,1,2,0,NULL),(13,2,2,'Добавить режим слежения на графике','','2014-09-30',1,1,3,2,NULL,3,2,'2014-08-27 04:28:55','2015-01-12 13:45:44','2014-08-27',0,2,131,131,32,33,0,NULL),(14,2,2,'веб - вместо None на экране в данный момент не доступно','http://127.0.0.1/nms/device/MonitoringServer/\r\nВкладка \"отправленные пакеты\"','2014-09-30',1,3,3,2,NULL,3,3,'2014-08-27 04:29:28','2014-10-23 15:25:32','2014-08-27',100,1,NULL,14,1,2,0,NULL),(15,2,2,'веб - сообщение о перезапуске выводить красивей','','2014-09-30',2,3,3,2,NULL,3,2,'2014-08-27 04:30:32','2014-10-07 04:27:47','2014-08-27',100,1,NULL,15,1,2,0,NULL),(16,2,2,'веб - выровнять поле в параметрах устр-ва по пр. краю','','2014-09-30',1,3,3,2,NULL,3,1,'2014-08-27 04:31:08','2014-09-04 01:50:40','2014-08-27',100,1,NULL,16,1,2,0,NULL),(17,1,2,'При добавлении парам. группы значение копируется из словаря','',NULL,2,1,3,2,NULL,3,2,'2014-08-27 04:31:40','2015-01-12 13:46:33','2014-08-27',0,NULL,135,135,18,19,0,NULL),(18,2,2,'Сохранять в параметре точность (знаки)','',NULL,1,1,5,2,1,3,2,'2014-08-27 04:32:02','2015-01-12 10:58:52','2014-08-27',0,NULL,131,131,28,29,0,NULL),(19,2,2,'Проверка системы - добавить доступность шары','',NULL,NULL,3,3,2,NULL,3,3,'2014-08-27 04:32:17','2014-10-06 04:15:20','2014-08-27',100,NULL,NULL,19,1,2,0,NULL),(20,2,2,'SNMP win7 видео под win7','',NULL,NULL,3,3,2,NULL,3,3,'2014-08-27 04:32:39','2015-01-12 08:56:28','2014-08-27',100,NULL,NULL,20,1,2,0,NULL),(21,2,2,'распр питания - алерт не нужен','',NULL,1,3,3,2,NULL,3,1,'2014-08-27 04:33:17','2015-01-12 08:56:11','2014-08-27',100,NULL,NULL,21,1,2,0,NULL),(22,2,2,'распр. питания - мощность фазы считать самим','Сделать новый параметр, который рассчитывается из 220*ток',NULL,6,3,3,2,NULL,3,3,'2014-08-27 04:33:51','2014-10-21 14:20:34','2014-08-27',100,NULL,NULL,22,1,2,0,NULL),(23,2,2,'распр. питания - не выдавать алерты когда питания нет','',NULL,2,3,3,2,NULL,3,1,'2014-08-27 04:34:15','2014-10-20 11:08:38','2014-08-27',100,NULL,NULL,23,1,2,0,NULL),(24,2,2,'Аккуратный shutdown','',NULL,NULL,1,3,2,NULL,3,2,'2014-08-27 04:34:29','2015-01-12 14:21:24','2014-08-27',0,NULL,135,135,14,15,0,NULL),(25,2,2,'404 fancy page','','2014-10-15',1,3,3,2,NULL,3,3,'2014-09-04 01:36:38','2015-01-12 08:59:38','2014-09-04',100,NULL,NULL,25,1,2,0,'2014-10-06 03:35:42'),(26,2,2,'Сделать красивую навигацию по страницам в журнале','','2014-10-15',1,3,3,2,NULL,3,3,'2014-09-04 01:49:09','2014-10-06 03:30:00','2014-09-04',100,NULL,NULL,26,1,2,0,NULL),(27,3,2,'Документация','','2015-02-01',12,1,3,3,NULL,3,6,'2014-09-04 02:11:39','2015-01-12 11:01:15','2014-09-04',33,48,NULL,27,1,8,0,NULL),(28,3,2,'Отчет о НИР','# Посмотреть, в каком состоянии отчет\r\n# Добавить ссылки на литературу\r\n# Уточнить, можно ли LaTeX\r\n# Есть ли ГОСТ на отчет\r\n# Включить таблицу с поддержкой видеокарт тайан http://tyan.com/tech/GPU/TYAN_GPU_Supporting_Lists.html ?\r\n# Написать про SSD\r\n# Вычитать самому\r\n# Дать вычитать СВ','2014-12-10',8,1,3,1,NULL,3,6,'2014-09-04 02:12:13','2015-01-12 14:24:41','2014-09-04',60,40,27,27,2,3,0,NULL),(29,1,2,'Переадресация с 127.0.0.1 на nms','',NULL,1,3,3,2,NULL,3,2,'2014-09-05 01:34:18','2014-10-01 04:21:32','2014-09-05',100,NULL,NULL,29,1,2,0,NULL),(30,1,2,'Заставить все тесты работать','',NULL,2,3,3,2,NULL,3,1,'2014-09-09 06:36:53','2014-09-28 23:40:56','2014-09-09',100,NULL,NULL,30,1,2,0,NULL),(31,3,2,'Обучение Володи','','2014-10-31',NULL,3,3,1,NULL,3,2,'2014-09-09 23:37:33','2015-01-12 08:58:59','2014-09-09',100,NULL,NULL,31,1,2,0,'2014-09-24 03:17:35'),(32,3,2,'Обучение Маши','','2014-11-30',NULL,3,3,2,NULL,3,1,'2014-09-09 23:37:52','2015-01-12 08:58:53','2014-09-09',100,NULL,NULL,32,1,2,0,NULL),(33,1,2,'База данных - убрать опции в конструкторе','',NULL,4,1,3,2,NULL,3,3,'2014-09-10 03:46:57','2015-01-12 08:55:43','2014-09-10',0,NULL,135,135,12,13,0,NULL),(34,2,2,'Создать новый вью с обзором и пользователем','',NULL,1,3,3,2,NULL,3,2,'2014-09-24 01:18:55','2014-09-24 02:30:02','2014-09-24',100,NULL,NULL,34,1,2,0,NULL),(35,1,2,'плывет меню','',NULL,1,3,3,2,NULL,3,1,'2014-09-24 01:19:07','2014-09-24 07:07:25','2014-09-24',100,NULL,NULL,35,1,2,0,NULL),(36,2,2,'Рефакторинг view с классами','',NULL,NULL,1,3,2,NULL,3,2,'2014-09-24 07:08:06','2015-01-12 13:45:57','2014-09-24',0,NULL,131,131,26,27,0,NULL),(37,1,2,'Упростить конфигурацию','В данный момент чтобы добавить параметр нужно\r\n1. добавить в файл load_to_database параметр\r\n2. прописать в файле parameters в группу параметров\r\n3. в файле devices добавить в устройство\r\n\r\nНадо сделать добавление в 1-2 файлах.',NULL,4,3,3,2,NULL,3,3,'2014-09-24 23:58:50','2014-11-10 08:47:09','2014-09-24',100,NULL,NULL,37,1,2,0,NULL),(38,3,2,'Обучение','',NULL,NULL,3,3,2,NULL,3,1,'2014-09-25 00:19:18','2015-01-12 08:55:05','2014-09-25',100,NULL,NULL,38,1,2,0,NULL),(39,3,3,'Обучение','',NULL,NULL,1,NULL,2,NULL,3,0,'2014-09-25 01:09:51','2014-09-25 01:09:51','2014-09-25',0,NULL,NULL,39,1,2,0,NULL),(40,1,2,'Убрать упоминание о Django в логин скрине','',NULL,NULL,3,3,2,NULL,3,2,'2014-09-25 04:15:53','2014-10-01 03:44:14','2014-09-25',100,NULL,NULL,40,1,2,0,NULL),(41,3,3,'Планирование','',NULL,NULL,2,3,2,NULL,3,0,'2014-09-28 23:40:15','2014-09-28 23:40:15','2014-09-28',0,NULL,NULL,41,1,2,0,NULL),(42,3,3,'Отдых','',NULL,NULL,1,3,2,NULL,3,0,'2014-09-28 23:45:49','2014-09-28 23:45:49','2014-09-28',0,NULL,NULL,42,1,2,0,NULL),(43,1,2,'Почистить директорию проекта от лишних файлов','admin.py -> models\r\ndjango tests\r\ndel generator\r\nmanagement/commands load_parameters_into_db.py del\r\ndel power.sh\r\nspecify interface to power_control.py\r\ndel scheduler\r\ndel templatetags/dictionary_extras.py\r\nmake directory for tests\r\n',NULL,2,3,3,2,NULL,3,1,'2014-10-02 03:48:15','2014-10-21 11:31:17','2014-10-02',100,NULL,NULL,43,1,2,0,NULL),(44,2,2,'функция для проверки dhcp','',NULL,NULL,3,NULL,2,NULL,3,1,'2014-10-06 04:11:35','2014-10-06 04:30:30','2014-10-06',100,NULL,NULL,44,1,2,0,NULL),(45,1,2,'веб - при переходе между страницами есть скачки','',NULL,NULL,3,NULL,2,NULL,3,1,'2014-10-06 04:14:09','2014-10-07 04:36:10','2014-10-06',0,NULL,NULL,45,1,2,0,NULL),(46,1,2,'Не отображается текущее время, когда находишься в админке','http://127.0.0.1/admin/nms_app/parametermodel/',NULL,1,1,3,1,NULL,3,4,'2014-10-07 04:28:47','2015-01-12 13:45:50','2014-10-07',0,NULL,131,131,30,31,0,NULL),(47,1,2,'при слишком большом приближении на графике - ошибка','http://127.0.0.1/nms/parameter/GPUServer03/CPU0_DIMM_A0/?from=1396580276&to=1396580286',NULL,1,3,3,2,NULL,3,2,'2014-10-07 05:16:43','2014-10-21 14:30:06','2014-10-07',100,NULL,NULL,47,1,2,0,NULL),(48,1,2,'Сделать процедуру очищения старых алертов','Пример бага:\r\nПроблема есть в журнале: http://127.0.0.1/nms/alerts\r\nНо нет на графике: http://127.0.0.1/nms/parameter/FileServer02BMC/FRNT_FAN1/?from=1396575545&to=1396576258\r\n',NULL,1,3,3,3,NULL,3,7,'2014-10-20 13:04:51','2014-10-23 09:34:22','2014-10-20',100,NULL,NULL,48,1,2,0,NULL),(49,2,2,'xml config?','Надо ли делать конфиг в xml файле?\r\nплюс - просто изменять программно\r\nминус - без хмл проще доступ к переменным',NULL,4,3,4,1,NULL,3,5,'2014-10-20 14:20:56','2015-01-12 08:47:48','2014-10-20',100,NULL,NULL,49,1,2,0,NULL),(50,2,2,'Telnet/ssh for nat','Make methods for getting data through telnet/ssh\r\nadd methods get_telnet_function ()\r\n            set_telnet_function ()\r\nand others',NULL,NULL,1,3,2,NULL,4,2,'2014-10-20 16:08:12','2015-01-12 09:39:48','2014-10-20',0,NULL,135,135,10,11,0,NULL),(51,3,2,'Менеджмент','Сюда буду логировать все время, которое тратится на создание тасков, разговоры и прочее.',NULL,3,3,3,1,NULL,3,4,'2014-10-21 09:51:56','2015-01-12 08:47:14','2014-10-21',100,NULL,NULL,51,1,2,0,NULL),(52,3,2,'Настроить виртуалку на машине у Антона','',NULL,5,3,4,2,NULL,3,3,'2014-10-21 09:56:26','2014-11-10 10:13:57','2014-10-21',100,NULL,NULL,52,1,2,0,NULL),(53,2,2,'Добавить функцию перерасчета всех вычисляемых параметров','В админке сделать. \r\nМожно проверить по параметру: http://127.0.0.1/nms/parameter/rPDU10/DeviceLoad_7921/?from=1396582437&to=1396604918\r\nН=',NULL,6,1,3,2,NULL,3,3,'2014-10-21 11:50:46','2015-01-12 09:25:25','2014-10-21',10,NULL,131,131,24,25,0,NULL),(55,1,2,'переписать шаблон для админки','Старый потерялся! Что за хрень вообще?',NULL,1,3,3,3,NULL,3,2,'2014-10-21 14:05:22','2014-10-21 15:41:27','2014-10-21',100,NULL,NULL,55,1,2,0,NULL),(56,1,2,'обработчик значений параметра не вызывается при сборе параметра','',NULL,2,3,3,2,NULL,3,0,'2014-10-21 14:19:25','2014-10-21 14:19:25','2014-10-21',100,NULL,NULL,56,1,2,0,NULL),(57,2,2,'Бекап базы данных в веб интерфейсе','',NULL,4,3,3,2,NULL,3,3,'2014-10-23 07:17:41','2014-10-23 13:28:29','2014-10-23',100,NULL,60,60,6,9,0,NULL),(58,2,2,'Очищение таблицы алертов в веб интерфейсе','',NULL,1,3,3,2,NULL,3,3,'2014-10-23 07:18:05','2014-10-23 11:35:25','2014-10-23',100,NULL,60,60,4,5,0,NULL),(59,2,2,'Тестирование веба с аутентификацией в джанго','',NULL,5,3,3,3,NULL,3,1,'2014-10-23 07:42:49','2014-10-23 08:28:23','2014-10-23',100,NULL,NULL,59,1,2,0,NULL),(60,2,2,'Менеджмент баз данных в веб','',NULL,1,3,3,2,NULL,3,9,'2014-10-23 11:34:44','2014-11-18 12:05:47','2014-10-23',100,0.5,NULL,60,1,12,0,NULL),(61,2,2,'отображать размер баз данных ','',NULL,1,3,3,2,NULL,3,1,'2014-10-23 11:35:13','2014-10-23 13:25:17','2014-10-23',100,NULL,60,60,2,3,0,NULL),(62,2,2,'Связь розеток с серверами','Сделать вью, на котором можно будет привязать номера розеток к устройству.','2014-12-17',1,3,3,2,NULL,3,5,'2014-10-23 11:47:30','2015-01-12 10:56:11','2014-10-23',100,8,131,131,22,23,0,NULL),(63,2,2,'Сделать тест веб интерфейса для бекапа','',NULL,7,3,3,2,NULL,3,3,'2014-10-23 11:51:02','2015-01-12 09:17:49','2014-10-23',100,NULL,57,60,7,8,0,'2014-10-23 13:28:11'),(64,2,2,'Отображать диапазон дат в базе данных','',NULL,1,3,3,2,NULL,3,4,'2014-10-23 13:26:19','2014-11-18 12:05:24','2014-10-23',100,0.5,60,60,10,11,0,NULL),(65,1,2,'Postprocess у параметра применяется в 2х местах','место А - views в виде флоатов\r\nместо В - device collect в виде строчек\r\n\r\nparameters.postprocess\r\n',NULL,2,3,3,4,NULL,3,4,'2014-10-23 13:40:54','2014-10-24 08:32:32','2014-10-23',100,NULL,NULL,65,1,2,0,NULL),(67,3,2,'Посмотреть джамперы на серверах','Вдруг может быть так, что на серверах отключена куча мониторинга?',NULL,9,3,3,1,NULL,3,4,'2014-10-23 15:00:28','2015-01-12 14:30:23','2014-10-23',100,NULL,133,133,10,11,0,NULL),(68,1,2,'Группировать параметры в группы у девайса','http://127.0.0.1/nms/device/GPUServer03/ - например температура модуля памяти\r\n\r\nи писать среднее.',NULL,1,1,3,1,NULL,3,1,'2014-10-23 15:52:52','2015-01-12 08:39:12','2014-10-23',0,NULL,131,131,20,21,0,NULL),(69,2,2,'Не забыть проверить работу NTP в будущей системе','',NULL,4,1,3,1,NULL,3,1,'2014-10-24 14:31:26','2015-01-12 08:38:53','2014-10-24',0,NULL,133,133,8,9,0,NULL),(70,1,2,'Исправление недочетов (посещение датацентра 28.10.14)','',NULL,2,3,3,2,NULL,3,16,'2014-10-29 08:22:41','2015-01-12 08:37:38','2014-10-29',100,NULL,NULL,70,1,20,0,NULL),(71,1,2,'недочеты: не собирает параметры, связанные с сетью кроме некоторых.','http://127.0.0.1/nms/parameter/FileServer02/sw_in_errors_1/ - например.',NULL,2,3,3,2,NULL,3,3,'2014-10-29 08:23:49','2015-01-12 08:35:08','2014-10-29',100,NULL,70,70,2,3,0,NULL),(72,1,2,'недочеты: иконка компании плохо отображается при дефолтном разрешении','',NULL,1,3,3,2,NULL,3,2,'2014-10-29 08:24:25','2014-11-10 10:55:35','2014-10-29',100,NULL,70,70,4,5,0,NULL),(73,1,2,'недочеты: настроить перенаправления с логина на ту страницу, откуда послало на логин','',NULL,1,3,3,2,NULL,3,2,'2014-10-29 08:25:10','2014-10-30 12:33:36','2014-10-29',100,NULL,70,70,6,7,0,NULL),(74,1,2,'недочеты: забрать файл hosts','',NULL,NULL,3,NULL,2,NULL,3,3,'2014-10-29 08:25:24','2015-01-12 08:35:27','2014-10-29',100,NULL,70,70,8,9,0,NULL),(75,1,2,'недочеты: в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.','',NULL,NULL,3,NULL,2,NULL,3,3,'2014-10-29 08:25:58','2015-01-12 08:35:43','2014-10-29',100,NULL,70,70,10,11,0,NULL),(76,1,2,'автоматизация: написать скрипт деплоя на уже настроенный сервер','Надо потестить!',NULL,NULL,3,NULL,2,NULL,3,4,'2014-10-29 08:26:44','2015-01-12 08:36:09','2014-10-29',100,NULL,70,70,12,13,0,NULL),(77,2,2,'Написать скрипт настройки сервера','',NULL,4,2,3,2,NULL,3,3,'2014-10-29 08:26:59','2015-01-12 13:47:08','2014-10-29',30,NULL,135,135,6,7,0,NULL),(78,1,2,'при деплое отключать напрочь логи','',NULL,NULL,3,3,2,NULL,3,1,'2014-10-29 08:27:24','2014-10-29 09:35:45','2014-10-29',100,NULL,70,70,14,15,0,NULL),(79,1,2,'Включить сжатие логов','',NULL,NULL,2,3,2,NULL,3,3,'2014-10-29 08:27:32','2015-01-12 14:22:54','2014-10-29',10,NULL,135,135,8,9,0,NULL),(80,1,2,'вопрос: почему при заполненности ж.д. пускает только по определенным интерфейсам:?','',NULL,NULL,3,NULL,2,NULL,3,2,'2014-10-29 08:28:01','2015-01-12 08:37:24','2014-10-29',100,NULL,70,70,16,17,0,NULL),(81,1,2,'ie 8 - очень плохо отображается все','',NULL,NULL,1,5,2,NULL,3,2,'2014-10-29 08:29:34','2015-01-12 10:58:19','2014-10-29',0,NULL,131,131,18,19,0,NULL),(82,1,2,'дублирование local_settings','',NULL,2,3,3,2,NULL,3,0,'2014-10-29 09:38:16','2014-10-29 09:38:16','2014-10-29',100,NULL,70,70,18,19,0,NULL),(83,2,2,'Глобальный рефакторинг','',NULL,4,3,3,2,NULL,3,8,'2014-10-29 09:42:49','2014-11-10 10:44:16','2014-10-31',100,NULL,NULL,83,1,6,0,NULL),(84,1,2,'Что-то с параметром число портов в мониторинге ','http://127.0.0.1/nms/device/Switch1810_24_monitoring/',NULL,NULL,1,NULL,2,1,3,2,'2014-10-30 11:33:33','2015-01-12 09:23:07','2014-10-30',0,NULL,135,135,4,5,0,NULL),(85,1,2,'База данных становится рид онли, когда запускаешь load_parameters','',NULL,NULL,2,NULL,2,1,3,3,'2014-10-30 11:42:59','2015-01-12 14:23:00','2014-10-30',0,NULL,135,135,2,3,0,NULL),(86,2,2,'рефакторинг: вынос групп параметров из девайсов в отдельный файл','',NULL,10,3,3,2,NULL,3,1,'2014-10-31 10:24:00','2014-10-31 13:17:10','2014-10-31',100,NULL,83,83,2,3,0,NULL),(87,2,2,'рефакторинг: переименовать все константы по пеп8','',NULL,10,3,3,2,NULL,3,2,'2014-10-31 10:57:42','2014-11-10 10:43:58','2014-10-31',100,NULL,83,83,4,5,0,NULL),(88,2,2,'План на второй визит к заказчику','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку +\r\n2. Напомнить СВ про пропуск\r\n3. захватить вим конфиг + bashrc\r\n4. взять с собой тетрадку и ручку\r\n\r\n1. Забрать hosts\r\n2. Взять бекап базы данных\r\n3. составить план адресации.\r\nпока понятно, что \r\n130.144.17.55 - control (csu)\r\n25.2.0.2 (csm)\r\n25.1.0.2 (csm)\r\n130.144.17.62 - (csm)\r\n4. Протестировать по списку всю новую функциональность.\r\n5. логотип, база, создать список параметров\r\n6. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. узнать, можно ли вообще что-то повключать, повыключать (например чтобы узнать где какая розетка)\r\n10. диагностика розеток\r\n12. план розеток\r\n13. проверить скрипт деплоя',NULL,3,3,3,2,NULL,3,7,'2014-11-10 08:33:11','2014-11-10 17:04:42','2014-11-10',100,NULL,NULL,88,1,2,0,NULL),(89,1,2,'что-то не-то с одним из свитчей','',NULL,NULL,3,NULL,2,NULL,3,1,'2014-11-10 08:41:23','2015-01-12 08:32:48','2014-11-10',100,NULL,NULL,89,1,2,0,NULL),(90,1,2,'Проблемы, обнаруженные во второй визит 11.11.2014','','2014-11-19',2,3,3,3,NULL,3,51,'2014-11-14 08:55:32','2015-01-12 08:26:56','2014-11-14',100,2.5,NULL,90,1,42,0,NULL),(91,1,2,'Время в коллекторе собирается не в UTC+0, поэтому при переводе времени на сервере есть проблемы с отображением времени','','2014-11-18',4,3,3,2,NULL,3,4,'2014-11-14 08:57:11','2014-11-17 14:28:04','2014-11-14',100,1,90,90,2,3,0,NULL),(92,1,2,'IPMI error в protocols','',NULL,2,3,3,3,NULL,3,0,'2014-11-14 08:57:50','2014-11-14 08:57:50','2014-11-14',100,NULL,90,90,4,5,0,NULL),(93,1,2,'При деплое необходимо удалять *.pyc, иначе возникают ошибки','',NULL,2,3,3,2,NULL,3,2,'2014-11-14 08:58:19','2014-11-14 09:42:36','2014-11-14',100,NULL,90,90,6,7,0,NULL),(94,1,2,'Не собираются параметры коммутатор решающего поля','',NULL,11,3,3,2,NULL,3,1,'2014-11-14 08:59:04','2015-01-12 08:20:29','2014-11-14',100,NULL,90,90,8,9,0,NULL),(95,1,2,'Логи не отключились при деплое','оказалось просто не перезапускался коллектор',NULL,2,3,3,2,NULL,3,0,'2014-11-14 08:59:46','2014-11-14 08:59:46','2014-11-14',100,NULL,90,90,10,11,0,NULL),(96,1,2,'Ошибка в коллектор watchdog','',NULL,2,3,3,2,NULL,3,0,'2014-11-14 09:00:08','2014-11-14 09:00:08','2014-11-14',100,NULL,90,90,12,13,0,NULL),(97,1,2,'Отображение на маленьком мониторе','* \"Питание и ...\"\r\n* Админ плывет+',NULL,1,3,3,2,NULL,3,1,'2014-11-14 09:01:23','2014-11-18 12:10:16','2014-11-14',100,NULL,90,90,14,15,0,NULL),(98,1,2,'По дефолту показыать график за последний день','',NULL,1,3,3,2,NULL,3,1,'2014-11-14 09:01:49','2014-11-14 14:32:59','2014-11-14',100,NULL,90,90,16,17,0,NULL),(99,1,2,'Отображать сообщение на графике, если данных нет','',NULL,1,3,3,2,NULL,3,3,'2014-11-14 09:02:13','2014-11-17 08:58:37','2014-11-17',100,NULL,90,90,18,21,0,NULL),(100,1,2,'Отображать в параметре - когда был в последний раз собран','',NULL,1,3,3,2,NULL,3,2,'2014-11-14 09:02:34','2014-11-14 14:47:55','2014-11-14',100,NULL,90,90,22,23,0,NULL),(101,1,2,'корректно отображать ip устройства','','2014-11-19',1,3,3,2,NULL,3,2,'2014-11-14 09:02:52','2014-11-18 11:33:12','2014-11-14',100,1,90,90,24,25,0,NULL),(102,1,2,'Не работают BMC fs1, fs2, csm','',NULL,11,3,3,2,NULL,3,1,'2014-11-14 09:03:24','2015-01-12 08:21:01','2014-11-14',100,NULL,90,90,26,27,0,NULL),(103,1,2,'Не собираются параметры датчика влажн 1, темпер 2, задней двери на Мод. контр. окр. среды. 1 и постоянный алерт на датчик температуры 2','',NULL,11,3,3,2,NULL,3,2,'2014-11-14 09:04:36','2015-01-12 08:22:04','2014-11-14',100,NULL,90,90,28,29,0,NULL),(104,2,2,'группировать параметры для вычислительных модулей','','2014-11-19',1,3,3,2,NULL,3,4,'2014-11-14 09:04:59','2015-01-12 09:24:46','2014-11-14',100,3,131,131,8,9,0,'2015-01-12 08:32:20'),(105,2,2,'сделать хоть какой snmp для виндовых машин','',NULL,4,3,3,2,NULL,3,2,'2014-11-14 09:05:28','2015-01-12 08:19:53','2014-11-14',100,NULL,90,90,30,31,0,NULL),(106,2,2,'группировать параметры при отображении','',NULL,4,3,3,2,NULL,3,5,'2014-11-14 09:05:49','2015-01-12 09:24:55','2014-11-14',100,NULL,131,131,12,13,0,'2015-01-12 08:39:44'),(107,2,2,'Группировать алерты по устройствам, типу отказа','Уточнить, что хочу сделать. Большой тикет',NULL,1,1,3,2,NULL,3,5,'2014-11-14 09:07:15','2015-01-12 14:22:20','2014-11-14',10,NULL,131,131,4,5,0,NULL),(108,2,2,'Время в 24 формате в алертах','',NULL,1,3,3,2,NULL,3,3,'2014-11-14 09:07:31','2014-11-14 14:55:27','2014-11-14',100,NULL,90,90,32,33,0,NULL),(109,2,2,'Возникает ошибка о том, что устройство недоступно на 1 минуту. И на графике этого не видно','','2014-11-27',1,3,3,2,NULL,3,5,'2014-11-14 09:08:04','2015-01-12 08:22:41','2014-11-14',80,NULL,131,131,10,11,0,NULL),(110,2,2,'Сделать специальный вид для просмотра алерта?','',NULL,1,1,3,2,NULL,3,3,'2014-11-14 09:08:25','2015-01-12 14:24:29','2014-11-14',10,NULL,131,131,6,7,0,NULL),(111,2,2,'Сортировать в доступности по сети в онлайн тесте выч. модули по имени.','',NULL,1,3,3,2,NULL,3,3,'2014-11-14 09:08:54','2014-11-14 15:58:30','2014-11-14',100,NULL,90,90,34,35,0,NULL),(112,2,2,'Сделать ссылки на веб интерфейс каждого устройства и на спецификацию','','2014-11-18',1,3,3,2,NULL,3,2,'2014-11-14 09:09:31','2014-11-18 10:48:07','2014-11-14',100,NULL,90,90,36,37,0,NULL),(113,2,2,'при нажатии на алерт показывать график с правильным временем','',NULL,1,3,3,2,NULL,3,2,'2014-11-14 09:47:02','2014-11-17 09:15:35','2014-11-14',100,NULL,90,90,38,39,0,NULL),(114,2,2,'рефакторинг тестов для базы данных','исп setUpClass и отдельный тест',NULL,4,3,3,2,NULL,3,1,'2014-11-14 10:01:21','2014-11-14 12:15:43','2014-11-14',100,NULL,NULL,114,1,2,0,NULL),(115,1,2,'Если не выделен объект, приближает к 0-0','',NULL,1,3,3,2,NULL,3,0,'2014-11-17 08:58:24','2014-11-17 08:58:24','2014-11-17',100,NULL,99,90,19,20,0,NULL),(116,1,2,'Алерты отсортированы в неправильном порядке в виде журнал.','','2014-11-19',1,3,3,2,NULL,3,2,'2014-11-18 08:18:35','2014-11-18 14:20:16','2014-11-18',100,0.5,90,90,40,41,0,NULL),(117,3,2,'Задачи на следующий приезд','# Настроить доступ с АРМ мониторинга на все интерфейсы.\r\n# Разобраться, какому свитчу назначен какой ip.\r\n# Прощелкать все ссылки в устройствах.\r\n# Возникает ошибка о том, что устройство недоступно на 1 минуту. И на графике этого не видно','2014-11-26',6,3,3,2,NULL,3,2,'2014-11-18 08:51:15','2015-01-12 08:45:15','2014-11-18',100,8,NULL,117,1,2,0,NULL),(118,2,2,'Изменить отображение информации о сетевых интерфейсах','* Удобнее смотреть скорость интерфейсов.\r\n* Сделать специальный вид для свитчей.\r\n* Передвинуть параметр про переданные пакеты наверх списка.\r\n* Отображать не в октетах, а в мб.\r\n','2014-11-26',1,1,3,2,NULL,3,2,'2014-11-18 10:02:48','2015-01-12 10:56:54','2014-11-18',10,3,131,131,2,3,0,NULL),(119,1,2,'Написать документацию разработчика','',NULL,4,1,3,2,NULL,3,3,'2014-11-26 08:56:31','2015-01-12 14:25:03','2014-11-26',0,NULL,27,27,6,7,0,NULL),(120,1,2,'Неправильный цпу тайм','',NULL,2,1,5,2,1,3,5,'2014-11-27 10:56:33','2015-01-12 14:25:09','2014-11-27',0,NULL,130,130,2,3,0,NULL),(121,1,2,'рефакторинг power control view','',NULL,4,3,3,2,NULL,3,0,'2014-12-03 13:31:34','2014-12-03 13:31:34','2014-12-03',100,3,NULL,121,1,2,0,NULL),(122,3,2,'Задачи проставленные в визит к заказчику 02.12.2014','',NULL,NULL,3,NULL,2,NULL,3,15,'2014-12-03 16:35:15','2015-01-12 08:31:24','2014-12-03',100,NULL,NULL,122,1,8,0,NULL),(123,3,2,'Настроить оборудование (switch 1910, rmu 1стойки, pdu b(ближний) 1й стойки)','',NULL,6,3,3,2,NULL,3,2,'2014-12-03 16:36:31','2015-01-12 08:27:49','2014-12-03',100,NULL,122,122,2,3,0,NULL),(124,3,2,'Установить свой SNMP агент на машины с windows2012r2 (установлено, работает, осталось разобраться с MIB на мониторинге)','',NULL,NULL,3,NULL,2,NULL,3,2,'2014-12-03 16:37:50','2014-12-03 17:21:51','2014-12-03',100,NULL,122,122,4,5,0,NULL),(125,3,2,'Выключение устройств через розетки','# В управлении питанием добавить кнопки выключения устройств\r\n# Сделать вью, на котором можно будет привязать номера розеток к устройству.',NULL,1,1,3,2,NULL,3,5,'2014-12-03 16:39:40','2015-01-12 14:24:20','2014-12-03',60,NULL,131,131,14,15,0,NULL),(126,3,2,'Тестовое ПО (проверить на GPU)','',NULL,NULL,3,NULL,2,NULL,3,2,'2014-12-03 16:42:38','2015-01-12 08:24:43','2014-12-03',100,NULL,122,122,6,7,0,NULL),(127,3,2,'Взятие под контроль 2й стойки','',NULL,NULL,1,NULL,2,NULL,3,1,'2014-12-03 16:44:25','2015-01-12 08:30:06','2014-12-03',0,NULL,133,133,6,7,0,NULL),(128,3,2,'Виртуальная машина для 1го отдела (управление сетевой загрузкой)','',NULL,NULL,1,NULL,2,NULL,3,1,'2014-12-03 16:45:13','2015-01-12 08:29:55','2014-12-03',0,NULL,133,133,4,5,0,NULL),(129,3,2,'косметические исправления','-1. отображать версию программы в вебе-\r\n-2. переход к веб интерфейсу устройств не по хостнейму-\r\n-3. обновить документацию - пароли-\r\n-4. писать секунды во времени окончания-\r\n-5. кнопки перехода между страницами-',NULL,NULL,3,3,2,1,3,5,'2014-12-03 18:31:39','2015-01-12 11:37:09','2014-12-03',100,NULL,131,131,16,17,0,NULL),(130,2,2,'SNMP агент для мониторинга Windows машин','',NULL,12,4,3,2,1,3,6,'2015-01-12 08:13:43','2015-01-12 14:25:39','2014-11-27',0,NULL,NULL,130,1,4,0,NULL),(131,2,2,'Улучшения графического интерфейса NMS','','2014-12-17',12,4,3,2,NULL,3,26,'2015-01-12 08:18:42','2015-01-12 14:24:06','2014-08-27',40,23,NULL,131,1,42,0,NULL),(132,2,2,'Тестовое ПО','# cpu - linpack + \r\n# gpu - ati AMD-APP-SDK benchmark +\r\n# disk - dd test +\r\n# storage - dd test -\r\n# ram - memtester -\r\n# network - ping -',NULL,12,4,3,3,1,3,10,'2015-01-12 08:24:26','2015-01-12 14:31:46','2015-01-12',0,NULL,NULL,132,1,10,0,NULL),(133,3,2,'Настройка оборудования у заказчика','',NULL,12,4,3,2,NULL,3,8,'2015-01-12 08:25:50','2015-01-12 14:30:23','2014-10-23',20,NULL,NULL,133,1,12,0,NULL),(134,2,2,'Поставить правильный ip у switch hp 1910','',NULL,NULL,1,NULL,2,NULL,3,2,'2015-01-12 08:28:13','2015-01-12 13:46:22','2015-01-12',0,NULL,133,133,2,3,0,NULL),(135,2,2,'Улучшения ядра NMS','','2015-01-19',12,4,3,2,NULL,3,14,'2015-01-12 08:33:31','2015-01-12 14:23:47','2014-08-27',10,3,NULL,135,1,24,0,NULL),(137,2,2,'Переписать тест memtest','',NULL,7,2,3,2,1,3,1,'2015-01-12 09:29:53','2015-01-12 14:22:48','2015-01-12',0,NULL,132,132,2,3,0,NULL),(138,2,2,'Тест СХД','',NULL,7,2,3,2,1,3,1,'2015-01-12 09:30:32','2015-01-12 14:22:42','2015-01-12',0,NULL,132,132,4,5,0,NULL),(139,2,2,'Тест ping','',NULL,NULL,2,3,2,NULL,3,3,'2015-01-12 09:38:09','2015-01-12 14:22:36','2015-01-12',0,NULL,132,132,6,7,0,NULL),(140,2,2,'Написать спецификацию настройки для нового комплекса','','2015-02-01',8,1,3,3,1,3,2,'2015-01-12 11:00:08','2015-01-12 13:44:31','2015-01-12',0,8,27,27,4,5,0,NULL),(141,2,2,'Переписать работу с базами данных на sqlalchemy','','2015-01-19',4,2,5,2,1,3,1,'2015-01-12 11:09:33','2015-01-12 11:10:21','2014-12-01',70,NULL,135,135,22,23,0,NULL),(142,2,2,'Протестировать все видеокарты 8, 4x4','',NULL,9,2,3,3,NULL,3,0,'2015-01-12 14:31:46','2015-01-12 14:31:46','2015-01-12',0,NULL,132,132,8,9,0,NULL);
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_details`
--

DROP TABLE IF EXISTS `journal_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `journal_id` int(11) NOT NULL DEFAULT '0',
  `property` varchar(30) NOT NULL DEFAULT '',
  `prop_key` varchar(30) NOT NULL DEFAULT '',
  `old_value` text,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `journal_details_journal_id` (`journal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=448 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_details`
--

LOCK TABLES `journal_details` WRITE;
/*!40000 ALTER TABLE `journal_details` DISABLE KEYS */;
INSERT INTO `journal_details` VALUES (1,1,'attr','status_id','1','3'),(2,1,'attr','done_ratio','0','100'),(3,2,'attr','status_id','1','3'),(4,2,'attr','done_ratio','0','100'),(5,3,'attr','status_id','1','3'),(6,3,'attr','done_ratio','0','100'),(7,4,'attr','subject','База данных','База данных - убрать при создании опции. Операция чек занимает ОЧЕНЬ много времени ()'),(8,5,'attr','status_id','1','3'),(9,6,'attr','done_ratio','0','100'),(10,7,'attr','status_id','1','5'),(11,7,'attr','priority_id','2','1'),(12,7,'attr','done_ratio','0','100'),(13,8,'attr','status_id','1','3'),(14,8,'attr','done_ratio','0','100'),(15,9,'attr','status_id','1','3'),(16,9,'attr','done_ratio','0','100'),(17,10,'attr','status_id','1','2'),(18,11,'attr','status_id','1','2'),(19,12,'attr','status_id','1','2'),(20,13,'attr','status_id','1','2'),(21,14,'attr','status_id','1','2'),(22,15,'attr','status_id','1','2'),(23,16,'attr','status_id','1','2'),(24,17,'attr','status_id','1','2'),(25,18,'attr','status_id','1','2'),(26,19,'attr','status_id','2','3'),(27,19,'attr','done_ratio','0','100'),(28,20,'attr','status_id','2','3'),(29,20,'attr','done_ratio','0','100'),(30,21,'attr','status_id','2','3'),(31,21,'attr','done_ratio','0','100'),(32,22,'attr','status_id','2','6'),(33,22,'attr','done_ratio','0','100'),(34,23,'attr','done_ratio','0','100'),(35,24,'attr','status_id','2','3'),(36,25,'attr','status_id','2','3'),(37,25,'attr','done_ratio','0','100'),(38,26,'attr','status_id','2','3'),(39,26,'attr','done_ratio','0','100'),(40,27,'attr','status_id','2','3'),(41,27,'attr','done_ratio','0','100'),(42,28,'attr','status_id','1','3'),(43,29,'attr','status_id','1','3'),(44,29,'attr','done_ratio','0','100'),(45,31,'attr','tracker_id','1','2'),(46,31,'attr','priority_id','2','1'),(47,32,'attr','subject','see later','Сделать процедуру очищения старых алертов'),(48,33,'attr','tracker_id','1','3'),(49,34,'attr','tracker_id','3','1'),(50,34,'attr','subject','Настройка конфигов','Упростить конфигурацию'),(51,34,'attr','category_id',NULL,'4'),(52,35,'attr','description','','В данный момент чтобы добавить параметр нужно\r\n1. добавить в файл load_to_database параметр\r\n2. прописать в файле parameters в группу параметров\r\n3. в файле devices добавить в устройство\r\n\r\nНадо сделать добавление в 1-2 файлах.'),(53,36,'attr','description','http://127.0.0.1/nms/parameter/FileServer02BMC/FRNT_FAN1/?from=1396575545&to=1396576258\r\nhttp://127.0.0.1/nms/alerts','Пример бага:\r\nПроблема есть в журнале: http://127.0.0.1/nms/alerts\r\nНо нет на графике: http://127.0.0.1/nms/parameter/FileServer02BMC/FRNT_FAN1/?from=1396575545&to=1396576258\r\n'),(54,37,'attr','assigned_to_id',NULL,'3'),(55,38,'attr','category_id',NULL,'1'),(56,39,'attr','category_id',NULL,'4'),(57,39,'attr','assigned_to_id',NULL,'4'),(58,40,'attr','description','','Надо ли делать конфиг в xml файле?\r\nплюс - просто изменять программно\r\nминус - без хмл проще доступ к переменным'),(59,41,'attr','category_id',NULL,'1'),(60,41,'attr','assigned_to_id',NULL,'3'),(61,42,'attr','description','http://127.0.0.1/admin/nms_app/parametermodel/','http://127.0.0.1/admin/nms_app/parametermodel/\r\nБлин, сам не понял, что написал. Надо вспомнить в чем тут дело.'),(62,42,'attr','category_id',NULL,'1'),(63,42,'attr','assigned_to_id',NULL,'3'),(64,42,'attr','priority_id','2','1'),(65,43,'attr','category_id',NULL,'4'),(66,43,'attr','assigned_to_id',NULL,'3'),(67,44,'attr','status_id','1','3'),(68,44,'attr','done_ratio','0','100'),(69,45,'attr','description','','Сделать новый параметр, который рассчитывается из 220*ток'),(70,45,'attr','category_id','2','6'),(71,45,'attr','status_id','1','2'),(72,45,'attr','done_ratio','0','20'),(73,47,'attr','status_id','2','3'),(74,47,'attr','done_ratio','20','100'),(75,48,'attr','status_id','1','3'),(76,48,'attr','done_ratio','0','100'),(77,49,'attr','priority_id','2','3'),(78,50,'attr','priority_id','2','3'),(79,51,'attr','status_id','2','3'),(80,51,'attr','done_ratio','0','100'),(81,52,'attr','status_id','1','2'),(82,53,'attr','status_id','1','2'),(83,54,'attr','status_id','1','2'),(84,55,'attr','priority_id','2','3'),(85,56,'attr','done_ratio','0','60'),(86,57,'attr','status_id','2','3'),(87,57,'attr','done_ratio','0','100'),(88,58,'attr','status_id','2','3'),(89,58,'attr','done_ratio','0','100'),(90,59,'attr','done_ratio','0','100'),(91,60,'attr','status_id','1','3'),(92,61,'attr','parent_id',NULL,'60'),(93,62,'attr','parent_id',NULL,'60'),(96,64,'attr','status_id','1','3'),(97,64,'attr','done_ratio','0','100'),(98,65,'attr','status_id','1','6'),(99,66,'attr','status_id','2','3'),(100,68,'attr','description','','http://127.0.0.1/nms/device/MonitoringServer/\r\nВкладка \"отправленные пакеты\"'),(101,68,'attr','done_ratio','0','20'),(102,69,'attr','status_id','2','3'),(103,69,'attr','done_ratio','0','100'),(104,70,'attr','tracker_id','2','3'),(105,70,'attr','priority_id','2','1'),(106,71,'attr','done_ratio','0','80'),(107,72,'attr','done_ratio','20','100'),(108,73,'attr','status_id','1','3'),(109,74,'attr','status_id','1','2'),(110,75,'attr','status_id','1','2'),(111,76,'attr','status_id','2','3'),(112,76,'attr','done_ratio','80','100'),(113,78,'attr','status_id','1','3'),(114,78,'attr','assigned_to_id',NULL,'3'),(115,78,'attr','done_ratio','0','100'),(116,80,'attr','priority_id','3','4'),(117,80,'attr','done_ratio','0','70'),(118,81,'attr','done_ratio','70','80'),(119,82,'attr','status_id','1','2'),(120,83,'attr','status_id','2','3'),(121,83,'attr','done_ratio','0','100'),(122,84,'attr','status_id','1','2'),(123,85,'attr','status_id','2','3'),(124,85,'attr','done_ratio','0','100'),(125,86,'attr','description','','Надо потестить!'),(126,86,'attr','done_ratio','100','80'),(127,87,'attr','status_id','2','3'),(128,87,'attr','done_ratio','0','100'),(129,88,'attr','status_id','1','2'),(130,88,'attr','done_ratio','0','10'),(131,89,'attr','status_id','1','3'),(132,89,'attr','done_ratio','0','100'),(133,90,'attr','status_id','1','2'),(134,91,'attr','status_id','1','2'),(135,92,'attr','status_id','1','2'),(136,93,'attr','status_id','1','2'),(137,94,'attr','description','','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. '),(138,94,'attr','status_id','1','2'),(139,95,'attr','status_id','2','3'),(140,95,'attr','done_ratio','60','100'),(141,96,'attr','status_id','2','3'),(142,96,'attr','done_ratio','10','100'),(143,97,'attr','status_id','2','3'),(144,98,'attr','status_id','2','3'),(145,98,'attr','done_ratio','0','100'),(146,99,'attr','description','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. ','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n\r\n\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. '),(147,100,'attr','description','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n\r\n\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. ','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n\r\n\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. захватить вим конфиг + bashrc'),(148,101,'attr','description','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n\r\n\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. захватить вим конфиг + bashrc','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n\r\n\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. захватить вим конфиг + bashrc\r\n10. узнать, можно ли вообще что-то повключать, повыключать (например чтобы узнать где какая розетка)'),(149,102,'attr','status_id','2','1'),(150,103,'attr','status_id','2','1'),(151,104,'attr','status_id','2','1'),(152,105,'attr','status_id','2','1'),(153,106,'attr','status_id','2','1'),(154,107,'attr','status_id','2','1'),(155,108,'attr','description','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n\r\n\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. захватить вим конфиг + bashrc\r\n10. узнать, можно ли вообще что-то повключать, повыключать (например чтобы узнать где какая розетка)','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n\r\n\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. захватить вим конфиг + bashrc\r\n10. узнать, можно ли вообще что-то повключать, повыключать (например чтобы узнать где какая розетка)\r\n11. составить план адресации.\r\nпока понятно, что \r\n130.144.17.55 - control (csu)\r\n25.2.0.2 (csm)\r\n25.1.0.2 (csm)\r\n130.144.17.62 - (csm)\r\n\r\n12. взять с собой тетрадку и ручку'),(156,109,'attr','description','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку\r\n2. Забрать hosts\r\n3. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n\r\n\r\n4. Протестировать по списку всю новую функциональность.\r\n5. Взять бекап базы данных\r\n6. Напомнить СВ про пропуск\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. захватить вим конфиг + bashrc\r\n10. узнать, можно ли вообще что-то повключать, повыключать (например чтобы узнать где какая розетка)\r\n11. составить план адресации.\r\nпока понятно, что \r\n130.144.17.55 - control (csu)\r\n25.2.0.2 (csm)\r\n25.1.0.2 (csm)\r\n130.144.17.62 - (csm)\r\n\r\n12. взять с собой тетрадку и ручку','1. Собрать весь дистрибутив в scp + putty + firefox и записать на болванку +\r\n2. Напомнить СВ про пропуск\r\n3. захватить вим конфиг + bashrc\r\n4. взять с собой тетрадку и ручку\r\n\r\n1. Забрать hosts\r\n2. Взять бекап базы данных\r\n3. составить план адресации.\r\nпока понятно, что \r\n130.144.17.55 - control (csu)\r\n25.2.0.2 (csm)\r\n25.1.0.2 (csm)\r\n130.144.17.62 - (csm)\r\n4. Протестировать по списку всю новую функциональность.\r\n5. логотип, база, создать список параметров\r\n6. Посмотреть, что происходит со свитчем 1910.\r\nsnmpget -On -v 2c -Cf -c public 127.0.0.1\r\nIF-MIB\r\n.1.3.6.1.2.1.2.2 \r\n.1.3.6.1.2.1.2.1 - The number of network interfaces (regardless of their\r\ncurrent state) present on this system.\r\n7. Исправить - в базе 29_04 - есть значек алертов у 2 модуля, но алертов нет.\r\n8. Проверить все параметры один за другим по snmp (особенно сетевые).\r\n9. узнать, можно ли вообще что-то повключать, повыключать (например чтобы узнать где какая розетка)\r\n10. диагностика розеток\r\n12. план розеток\r\n13. проверить скрипт деплоя'),(157,110,'attr','status_id','2','3'),(158,110,'attr','done_ratio','0','100'),(159,111,'attr','status_id','1','2'),(160,112,'attr','status_id','1','2'),(161,113,'attr','status_id','1','3'),(162,114,'attr','status_id','1','2'),(163,115,'attr','status_id','3','2'),(164,116,'attr','status_id','1','2'),(165,117,'attr','subject','Сортировать в доступностьи по сети во вью тест выч. модули по имени.','Сортировать в доступности по сети в онлайн тесте выч. модули по имени.'),(166,118,'attr','status_id','2','3'),(167,118,'attr','done_ratio','0','100'),(168,119,'attr','status_id','2','3'),(169,119,'attr','done_ratio','0','100'),(170,120,'attr','status_id','2','3'),(171,120,'attr','done_ratio','10','100'),(172,121,'attr','status_id','2','3'),(173,121,'attr','done_ratio','0','100'),(174,122,'attr','status_id','2','3'),(175,122,'attr','done_ratio','0','100'),(176,123,'attr','status_id','2','3'),(177,123,'attr','done_ratio','0','100'),(178,124,'attr','status_id','1','2'),(179,124,'attr','done_ratio','0','10'),(180,125,'attr','status_id','1','2'),(181,125,'attr','done_ratio','0','10'),(182,126,'attr','status_id','1','2'),(183,126,'attr','done_ratio','0','10'),(184,127,'attr','category_id',NULL,'4'),(185,127,'attr','assigned_to_id',NULL,'3'),(186,127,'attr','done_ratio','0','10'),(187,128,'attr','status_id','2','3'),(188,129,'attr','status_id','2','3'),(189,129,'attr','done_ratio','10','100'),(190,130,'attr','status_id','1','2'),(191,131,'attr','due_date',NULL,'2014-11-18'),(192,131,'attr','estimated_hours',NULL,'1.0'),(193,132,'attr','status_id','2','3'),(194,132,'attr','done_ratio','10','100'),(195,133,'attr','due_date',NULL,'2014-11-19'),(196,133,'attr','status_id','1','2'),(197,134,'attr','due_date',NULL,'2014-11-18'),(198,134,'attr','status_id','2','3'),(199,134,'attr','done_ratio','0','100'),(200,135,'attr','status_id','2','3'),(201,135,'attr','done_ratio','0','100'),(202,135,'attr','estimated_hours',NULL,'1.0'),(203,136,'attr','due_date',NULL,'2014-11-19'),(204,136,'attr','status_id','1','2'),(205,136,'attr','done_ratio','0','10'),(206,136,'attr','estimated_hours',NULL,'3.0'),(207,137,'attr','priority_id','2','1'),(208,138,'attr','due_date',NULL,'2014-12-10'),(209,138,'attr','category_id',NULL,'8'),(210,138,'attr','done_ratio','0','60'),(211,138,'attr','estimated_hours',NULL,'40.0'),(212,139,'attr','status_id','1','2'),(213,140,'attr','estimated_hours',NULL,'0.5'),(214,141,'attr','status_id','2','3'),(215,142,'attr','done_ratio','0','100'),(216,143,'attr','status_id','2','3'),(217,144,'attr','due_date',NULL,'2014-12-17'),(218,144,'attr','done_ratio','0','80'),(219,144,'attr','estimated_hours',NULL,'8.0'),(220,145,'attr','due_date',NULL,'2014-11-27'),(221,145,'attr','done_ratio','10','100'),(222,146,'attr','done_ratio','100','80'),(223,147,'attr','status_id','2','3'),(224,147,'attr','done_ratio','60','100'),(225,148,'attr','status_id','2','3'),(226,149,'attr','description','# Настроить доступ с АРМ мониторинга на все интерфейсы.\r\n# Разобраться, какому свитчу назначен какой ip.\r\n# Прощелкать все ссылки в устройствах.','# Настроить доступ с АРМ мониторинга на все интерфейсы.\r\n# Разобраться, какому свитчу назначен какой ip.\r\n# Прощелкать все ссылки в устройствах.\r\n# Возникает ошибка о том, что устройство недоступно на 1 минуту. И на графике этого не видно'),(227,150,'attr','estimated_hours',NULL,'0.5'),(228,151,'attr','status_id','2','3'),(229,151,'attr','done_ratio','10','100'),(230,152,'attr','status_id','1','2'),(231,153,'attr','status_id','1','2'),(232,154,'attr','status_id','1','3'),(233,155,'attr','status_id','1','2'),(234,156,'attr','status_id','3','2'),(235,158,'attr','status_id','1','2'),(236,159,'attr','subject','Задачи проставленные во второй визит к заказчику','Задачи проставленные в визит к заказчику 02.12.2014'),(237,161,'attr','status_id','1','3'),(238,161,'attr','done_ratio','0','100'),(239,162,'attr','done_ratio','0','70'),(240,163,'attr','category_id',NULL,'6'),(241,163,'attr','status_id','1','4'),(242,163,'attr','assigned_to_id',NULL,'3'),(243,163,'attr','done_ratio','0','80'),(244,164,'attr','status_id','1','2'),(245,164,'attr','done_ratio','0','80'),(246,165,'attr','status_id','1','2'),(247,165,'attr','done_ratio','0','60'),(248,166,'attr','category_id',NULL,'1'),(249,166,'attr','assigned_to_id',NULL,'3'),(250,167,'attr','parent_id',NULL,'130'),(251,168,'attr','parent_id',NULL,'131'),(252,169,'attr','done_ratio','0','10'),(253,169,'attr','parent_id','90','131'),(254,170,'attr','done_ratio','0','10'),(255,170,'attr','parent_id','90','131'),(256,171,'attr','status_id','2','3'),(257,171,'attr','done_ratio','0','100'),(258,172,'attr','status_id','1','3'),(259,172,'attr','done_ratio','0','100'),(260,173,'attr','status_id','1','3'),(261,173,'attr','done_ratio','0','100'),(262,174,'attr','status_id','1','3'),(263,175,'attr','done_ratio','0','100'),(264,176,'attr','parent_id','90','131'),(265,177,'attr','parent_id','90','131'),(266,178,'attr','parent_id','90','131'),(267,179,'attr','status_id','2','3'),(268,179,'attr','done_ratio','80','100'),(269,180,'attr','category_id','1','12'),(270,181,'attr','category_id','4','12'),(271,182,'attr','status_id','2','3'),(272,183,'attr','status_id','4','3'),(273,183,'attr','done_ratio','80','100'),(274,184,'attr','parent_id','122','131'),(275,185,'attr','parent_id','122','131'),(276,186,'attr','parent_id','132','133'),(277,187,'attr','parent_id','122','133'),(278,188,'attr','parent_id','122','133'),(279,189,'attr','subject','Проблемы с железом','Настройка оборудования у заказчика'),(280,189,'attr','status_id','1','2'),(281,190,'attr','status_id','2','3'),(282,191,'attr','status_id','2','6'),(283,191,'attr','done_ratio','10','0'),(284,192,'attr','status_id','1','3'),(285,192,'attr','done_ratio','0','100'),(286,193,'attr','parent_id',NULL,'135'),(287,194,'attr','parent_id',NULL,'135'),(288,195,'attr','parent_id','70','131'),(289,196,'attr','status_id','1','3'),(290,196,'attr','done_ratio','0','100'),(291,197,'attr','status_id','1','3'),(292,197,'attr','done_ratio','0','100'),(293,198,'attr','status_id','1','3'),(294,198,'attr','done_ratio','0','100'),(295,199,'attr','done_ratio','80','100'),(296,200,'attr','status_id','1','2'),(297,200,'attr','done_ratio','0','30'),(298,200,'attr','parent_id','70','135'),(299,202,'attr','assigned_to_id',NULL,'3'),(300,202,'attr','done_ratio','0','10'),(301,202,'attr','parent_id','70','135'),(302,203,'attr','status_id','1','3'),(303,203,'attr','done_ratio','0','100'),(304,204,'attr','status_id','1','3'),(305,205,'attr','subject','ntp','Не забыть проверить работу NTP в будущей системе'),(306,205,'attr','parent_id',NULL,'133'),(307,206,'attr','parent_id',NULL,'131'),(308,207,'attr','status_id','2','6'),(309,208,'attr','done_ratio','0','100'),(310,209,'attr','subject','Посмотреть джамперты на серверах','Посмотреть джамперы на серверах'),(311,209,'attr','parent_id',NULL,'133'),(312,210,'attr','done_ratio','0','100'),(313,211,'attr','parent_id',NULL,'136'),(314,212,'attr','status_id','1','3'),(315,212,'attr','done_ratio','0','100'),(317,214,'attr','parent_id',NULL,'131'),(320,216,'attr','parent_id',NULL,'131'),(321,217,'attr','status_id','1','3'),(322,217,'attr','done_ratio','0','100'),(323,218,'attr','parent_id',NULL,'135'),(324,219,'attr','status_id','1','3'),(325,219,'attr','done_ratio','0','100'),(326,220,'attr','subject','веб - не передается время в случае просмотра и изменения параметров','Не отображается текущее время, когда находишься в админке.'),(327,220,'attr','description','http://127.0.0.1/admin/nms_app/parametermodel/\r\nБлин, сам не понял, что написал. Надо вспомнить в чем тут дело.','http://127.0.0.1/admin/nms_app/parametermodel/'),(328,221,'attr','parent_id',NULL,'131'),(329,222,'attr','status_id','1','3'),(330,222,'attr','done_ratio','0','100'),(331,223,'attr','subject','База данных - убрать при создании опции. Операция чек занимает ОЧЕНЬ много времени ()','База данных - убрать опции в конструкторе'),(332,223,'attr','parent_id',NULL,'135'),(333,224,'attr','parent_id',NULL,'135'),(334,225,'attr','status_id','1','3'),(335,225,'attr','done_ratio','0','100'),(336,226,'attr','status_id','1','3'),(337,226,'attr','done_ratio','0','100'),(338,227,'attr','parent_id',NULL,'131'),(339,228,'attr','parent_id',NULL,'135'),(340,229,'attr','status_id','1','3'),(341,229,'attr','done_ratio','0','100'),(342,230,'attr','category_id','4','12'),(343,231,'attr','category_id','4','12'),(344,232,'attr','parent_id',NULL,'131'),(345,233,'attr','status_id','1','3'),(346,233,'attr','done_ratio','0','100'),(347,234,'attr','status_id','5','3'),(348,235,'attr','category_id',NULL,'12'),(349,236,'attr','status_id','6','3'),(350,237,'attr','parent_id',NULL,'135'),(351,238,'attr','parent_id',NULL,'131'),(352,239,'attr','priority_id','2','1'),(353,239,'attr','parent_id',NULL,'131'),(354,240,'attr','status_id','1','3'),(355,240,'attr','done_ratio','0','100'),(356,240,'attr','parent_id',NULL,'131'),(357,241,'attr','parent_id',NULL,'131'),(358,242,'attr','priority_id','2','3'),(359,242,'attr','parent_id',NULL,'131'),(360,243,'attr','subject','Проверка хэш суммы исполняемого файла','Проверка хэш суммы исполняемого файла (???)'),(361,243,'attr','priority_id','2','1'),(362,243,'attr','parent_id',NULL,'135'),(363,244,'attr','status_id','6','3'),(365,246,'attr','subject','Число поров в мониторинге? что-то с параметром','Что-то с параметром число портов в мониторинге '),(366,246,'attr','fixed_version_id',NULL,'1'),(367,247,'attr','fixed_version_id',NULL,'1'),(368,248,'attr','status_id','6','3'),(369,248,'attr','done_ratio','0','100'),(370,249,'attr','status_id','6','3'),(371,250,'attr','priority_id','3','2'),(372,251,'attr','priority_id','3','2'),(373,252,'attr','priority_id','3','2'),(374,253,'attr','fixed_version_id',NULL,'1'),(375,254,'attr','fixed_version_id',NULL,'1'),(376,255,'attr','description','','# cpu - linpack + \r\n# gpu - ati AMD-APP-SDK benchmark +\r\n# disk - dd test +\r\n# storage - dd test -\r\n# ram - memtester -\r\n# network - ping -'),(377,256,'attr','assigned_to_id','4','3'),(378,257,'attr','category_id',NULL,'2'),(379,257,'attr','assigned_to_id',NULL,'5'),(380,257,'attr','fixed_version_id',NULL,'1'),(381,258,'attr','subject','Выключение устройств через розетки (осталось допрограммировать)','Выключение устройств через розетки'),(382,258,'attr','description','','# В управлении питанием добавить кнопки выключения устройств\r\n# Сделать вью, на котором можно будет привязать номера розеток к устройству.'),(383,259,'attr','status_id','2','3'),(384,259,'attr','done_ratio','80','100'),(385,260,'attr','subject','Отправленные пакеты - удобство использования','Изменить отображение информации о сетевых интерфейсах'),(386,261,'attr','assigned_to_id',NULL,'3'),(387,262,'attr','assigned_to_id',NULL,'5'),(388,263,'attr','subject','сохранять в праметре точность (знаки)','Сохранять в параметре точность (знаки)'),(389,263,'attr','category_id',NULL,'1'),(390,263,'attr','assigned_to_id','3','5'),(391,263,'attr','fixed_version_id',NULL,'1'),(392,264,'attr','priority_id','2','3'),(393,264,'attr','parent_id','132','27'),(394,265,'attr','parent_id','136','27'),(397,267,'attr','description','','# Посмотреть, в каком состоянии отчет\r\n# Добавить ссылки на литературу\r\n# Уточнить, можно ли LaTeX\r\n# Есть ли ГОСТ на отчет\r\n# Включить таблицу с поддержкой видеокарт тайан http://tyan.com/tech/GPU/TYAN_GPU_Supporting_Lists.html ?\r\n# Написать про SSD\r\n# Вычитать самому\r\n# Дать вычитать СВ'),(399,269,'attr','assigned_to_id',NULL,'5'),(400,270,'attr','assigned_to_id','5','3'),(401,271,'attr','start_date','2015-01-12','2014-12-01'),(402,272,'attr','description','-1. отображать версию программы в вебе-\r\n-2. переход к веб интерфейсу устройств не по хостнейму-\r\n-3. обновить документацию - пароли-\r\n-4. писать секунды во времени окончания-\r\n5. кнопки перехода между страницами\r\n6. ','-1. отображать версию программы в вебе-\r\n-2. переход к веб интерфейсу устройств не по хостнейму-\r\n-3. обновить документацию - пароли-\r\n-4. писать секунды во времени окончания-\r\n-5. кнопки перехода между страницами-'),(403,272,'attr','status_id','2','3'),(404,272,'attr','assigned_to_id','3',NULL),(405,272,'attr','fixed_version_id',NULL,'1'),(406,272,'attr','done_ratio','70','100'),(407,273,'attr','assigned_to_id',NULL,'3'),(408,274,'attr','subject','Оформить отчет','Отчет о НИР'),(409,275,'attr','subject','Написать полную спецификацию настройки для нового комплекса','Написать спецификацию настройки для нового комплекса'),(410,276,'attr','subject','неправильный цпу тайм','Неправильный цпу тайм'),(411,277,'attr','subject','веб - поле у параметра, которое отключает сбор','Добавить поле у параметра, которое отключает сбор'),(412,278,'attr','subject','веб - руссификация полей модели','Руссификация полей модели'),(413,279,'attr','subject','веб - режим слежения на графике','Добавить режим слежения на графике'),(414,280,'attr','subject','Не отображается текущее время, когда находишься в админке.','Не отображается текущее время, когда находишься в админке'),(415,281,'attr','subject','рефакторинг view с классами','Рефакторинг view с классами'),(416,282,'attr','subject','Группировать алерты по устройствам, типу отказа.','Группировать алерты по устройствам, типу отказа'),(417,283,'attr','subject','switch 1910 - поставить правильный ip','Поставить правильный ip у switch hp 1910'),(418,284,'attr','subject','при добавлении парам. группы значение копируется из словаря','При добавлении парам. группы значение копируется из словаря'),(419,285,'attr','subject','включить сжатие логов','Включить сжатие логов'),(420,286,'attr','tracker_id','1','2'),(421,286,'attr','subject','автоматизация: написать скрипт настройки сервера','Написать скрипт настройки сервера'),(422,286,'attr','category_id',NULL,'4'),(423,286,'attr','assigned_to_id',NULL,'3'),(424,287,'attr','subject','Настройка оборудования у заказчика','*Настройка оборудования у заказчика*'),(425,288,'attr','subject','*Настройка оборудования у заказчика*','Настройка оборудования у заказчика'),(426,289,'attr','subject','аккуратный shutdown','Аккуратный shutdown'),(427,290,'attr','status_id','2','1'),(428,291,'attr','status_id','1','2'),(429,292,'attr','status_id','1','2'),(430,293,'attr','status_id','1','2'),(431,294,'attr','status_id','1','2'),(432,295,'attr','status_id','1','2'),(433,296,'attr','status_id','1','2'),(434,297,'attr','status_id','2','1'),(435,298,'attr','status_id','1','4'),(436,299,'attr','status_id','2','4'),(437,300,'attr','status_id','2','4'),(438,301,'attr','status_id','2','4'),(439,302,'attr','status_id','2','1'),(440,303,'attr','status_id','2','1'),(441,304,'attr','status_id','2','1'),(442,305,'attr','status_id','2','1'),(443,306,'attr','status_id','2','1'),(444,307,'attr','status_id','2','4'),(445,308,'attr','subject','Дописать SNMP агент для мониторинга Windows машин','SNMP агент для мониторинга Windows машин'),(446,309,'attr','status_id','2','3'),(447,309,'attr','done_ratio','0','100');
/*!40000 ALTER TABLE `journal_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `journalized_id` int(11) NOT NULL DEFAULT '0',
  `journalized_type` varchar(30) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `notes` text,
  `created_on` datetime NOT NULL,
  `private_notes` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `journals_journalized_id` (`journalized_id`,`journalized_type`),
  KEY `index_journals_on_user_id` (`user_id`),
  KEY `index_journals_on_journalized_id` (`journalized_id`),
  KEY `index_journals_on_created_on` (`created_on`)
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES (1,16,'Issue',3,'модуль paginator https://docs.djangoproject.com/en/1.5/topics/pagination/','2014-09-04 01:50:40',0),(2,9,'Issue',3,'','2014-09-05 01:07:47',0),(3,8,'Issue',3,'','2014-09-05 02:11:59',0),(4,33,'Issue',3,'delete database','2014-09-10 03:47:54',0),(5,34,'Issue',3,'','2014-09-24 02:29:54',0),(6,34,'Issue',3,'','2014-09-24 02:30:02',0),(7,31,'Issue',3,'','2014-09-24 03:17:35',0),(8,35,'Issue',3,'','2014-09-24 07:07:25',0),(9,30,'Issue',3,'','2014-09-28 23:40:56',0),(10,40,'Issue',3,'','2014-10-01 01:27:23',0),(11,29,'Issue',3,'','2014-10-01 01:28:07',0),(12,28,'Issue',3,'','2014-10-01 01:28:41',0),(13,26,'Issue',3,'','2014-10-01 01:28:49',0),(14,25,'Issue',3,'','2014-10-01 01:28:56',0),(15,19,'Issue',3,'','2014-10-01 01:29:02',0),(16,15,'Issue',3,'','2014-10-01 01:29:08',0),(17,12,'Issue',3,'','2014-10-01 01:29:14',0),(18,11,'Issue',3,'','2014-10-01 01:29:21',0),(19,40,'Issue',3,'','2014-10-01 03:44:14',0),(20,29,'Issue',3,'','2014-10-01 04:21:32',0),(21,26,'Issue',3,'','2014-10-06 03:30:00',0),(22,25,'Issue',3,'','2014-10-06 03:35:42',0),(23,19,'Issue',3,'','2014-10-06 04:15:13',0),(24,19,'Issue',3,'','2014-10-06 04:15:20',0),(25,44,'Issue',3,'','2014-10-06 04:30:30',0),(26,11,'Issue',3,'','2014-10-06 04:30:51',0),(27,15,'Issue',3,'','2014-10-07 04:27:47',0),(28,45,'Issue',3,'','2014-10-07 04:36:10',0),(29,23,'Issue',3,'','2014-10-20 11:08:38',0),(30,49,'Issue',3,'Надо ли делать конфиг в xml файле?\r\nплюс - просто изменять программно\r\nминус - без хмл проще доступ к переменным','2014-10-21 09:44:23',0),(31,49,'Issue',3,'','2014-10-21 09:44:41',0),(32,48,'Issue',3,'Должна быть опция - очистить журнал от старых алертов.\r\n','2014-10-21 09:48:49',0),(33,51,'Issue',3,'','2014-10-21 09:52:06',0),(34,37,'Issue',3,'','2014-10-21 09:54:50',0),(35,37,'Issue',3,'','2014-10-21 09:55:12',0),(36,48,'Issue',3,'','2014-10-21 09:57:22',0),(37,48,'Issue',3,'','2014-10-21 10:02:09',0),(38,48,'Issue',3,'','2014-10-21 10:02:37',0),(39,49,'Issue',3,'','2014-10-21 10:02:50',0),(40,49,'Issue',3,'','2014-10-21 10:03:08',0),(41,47,'Issue',3,'','2014-10-21 10:03:36',0),(42,46,'Issue',3,'','2014-10-21 10:04:23',0),(43,33,'Issue',3,'','2014-10-21 10:04:50',0),(44,43,'Issue',3,'','2014-10-21 11:31:17',0),(45,22,'Issue',3,'','2014-10-21 11:44:40',0),(46,22,'Issue',3,'CurrentPowerUsed - name','2014-10-21 11:46:29',0),(47,22,'Issue',3,'','2014-10-21 14:20:34',0),(48,47,'Issue',3,'','2014-10-21 14:30:06',0),(49,55,'Issue',3,'','2014-10-21 15:12:06',0),(50,53,'Issue',3,'','2014-10-21 15:12:32',0),(51,55,'Issue',3,'','2014-10-21 15:41:27',0),(52,20,'Issue',3,'','2014-10-22 10:57:14',0),(53,52,'Issue',3,'','2014-10-22 10:57:47',0),(54,48,'Issue',3,'','2014-10-22 10:57:55',0),(55,48,'Issue',3,'','2014-10-22 11:07:22',0),(56,52,'Issue',3,'','2014-10-23 07:14:54',0),(57,59,'Issue',3,'','2014-10-23 08:28:23',0),(58,48,'Issue',3,'','2014-10-23 09:34:22',0),(59,58,'Issue',3,'','2014-10-23 10:24:54',0),(60,58,'Issue',3,'','2014-10-23 10:24:59',0),(61,58,'Issue',3,'','2014-10-23 11:35:25',0),(62,57,'Issue',3,'','2014-10-23 11:35:39',0),(64,61,'Issue',3,'','2014-10-23 13:25:17',0),(65,63,'Issue',3,'','2014-10-23 13:28:11',0),(66,57,'Issue',3,'','2014-10-23 13:28:29',0),(67,65,'Issue',3,'small fix added','2014-10-23 13:42:56',0),(68,14,'Issue',3,'','2014-10-23 13:44:28',0),(69,12,'Issue',3,'','2014-10-23 14:10:51',0),(70,67,'Issue',3,'','2014-10-23 15:00:40',0),(71,65,'Issue',3,'nosetests -v test_core:TestParameter.test_calculated_parameter - Осталось','2014-10-23 15:13:40',0),(72,14,'Issue',3,'','2014-10-23 15:25:26',0),(73,14,'Issue',3,'','2014-10-23 15:25:32',0),(74,65,'Issue',3,'','2014-10-24 07:18:44',0),(75,62,'Issue',3,'','2014-10-24 07:18:51',0),(76,65,'Issue',3,'','2014-10-24 08:32:32',0),(77,80,'Issue',3,'Рабочая гипотеза: должно пускать только по первым в списке','2014-10-29 08:28:24',0),(78,78,'Issue',3,'','2014-10-29 09:35:45',0),(79,83,'Issue',3,'Запилил вынесение параметров в отдельную сущность','2014-10-29 17:03:19',0),(80,83,'Issue',3,'','2014-10-29 19:33:32',0),(81,83,'Issue',3,'','2014-10-30 11:58:28',0),(82,73,'Issue',3,'','2014-10-30 11:59:34',0),(83,73,'Issue',3,'','2014-10-30 12:33:36',0),(84,76,'Issue',3,'','2014-10-30 12:51:47',0),(85,76,'Issue',3,'','2014-10-30 13:49:13',0),(86,76,'Issue',3,'','2014-10-30 13:54:09',0),(87,86,'Issue',3,'','2014-10-31 13:17:10',0),(88,87,'Issue',3,'','2014-10-31 13:17:35',0),(89,37,'Issue',3,'','2014-11-10 08:47:09',0),(90,74,'Issue',3,'','2014-11-10 08:50:21',0),(91,75,'Issue',3,'','2014-11-10 08:50:30',0),(92,72,'Issue',3,'','2014-11-10 08:50:37',0),(93,71,'Issue',3,'','2014-11-10 08:50:46',0),(94,88,'Issue',3,'','2014-11-10 08:51:52',0),(95,52,'Issue',3,'','2014-11-10 10:13:57',0),(96,87,'Issue',3,'','2014-11-10 10:43:58',0),(97,83,'Issue',3,'','2014-11-10 10:44:16',0),(98,72,'Issue',3,'','2014-11-10 10:55:36',0),(99,88,'Issue',3,'','2014-11-10 12:07:18',0),(100,88,'Issue',3,'','2014-11-10 12:16:14',0),(101,88,'Issue',3,'','2014-11-10 12:23:33',0),(102,74,'Issue',3,'','2014-11-10 12:58:58',0),(103,71,'Issue',3,'','2014-11-10 12:59:29',0),(104,75,'Issue',3,'','2014-11-10 12:59:54',0),(105,51,'Issue',3,'','2014-11-10 13:00:39',0),(106,70,'Issue',3,'','2014-11-10 13:00:57',0),(107,20,'Issue',3,'','2014-11-10 13:01:01',0),(108,88,'Issue',3,'','2014-11-10 13:22:35',0),(109,88,'Issue',3,'','2014-11-10 17:04:31',0),(110,88,'Issue',3,'','2014-11-10 17:04:42',0),(111,93,'Issue',3,'','2014-11-14 09:24:41',0),(112,100,'Issue',3,'','2014-11-14 09:24:51',0),(113,108,'Issue',3,'','2014-11-14 09:24:57',0),(114,111,'Issue',3,'','2014-11-14 09:25:03',0),(115,108,'Issue',3,'','2014-11-14 09:25:09',0),(116,112,'Issue',3,'','2014-11-14 09:25:16',0),(117,111,'Issue',3,'','2014-11-14 09:31:59',0),(118,93,'Issue',3,'','2014-11-14 09:42:36',0),(119,114,'Issue',3,'','2014-11-14 12:15:43',0),(120,98,'Issue',3,'','2014-11-14 14:32:59',0),(121,100,'Issue',3,'','2014-11-14 14:47:55',0),(122,108,'Issue',3,'','2014-11-14 14:55:27',0),(123,111,'Issue',3,'','2014-11-14 15:58:30',0),(124,109,'Issue',3,'','2014-11-14 16:00:34',0),(125,113,'Issue',3,'','2014-11-14 16:00:42',0),(126,99,'Issue',3,'','2014-11-14 16:00:50',0),(127,91,'Issue',3,'','2014-11-14 16:00:59',0),(128,99,'Issue',3,'','2014-11-17 08:58:37',0),(129,113,'Issue',3,'','2014-11-17 09:15:35',0),(130,91,'Issue',3,'','2014-11-17 11:22:25',0),(131,91,'Issue',3,'','2014-11-17 11:22:40',0),(132,91,'Issue',3,'','2014-11-17 14:28:04',0),(133,101,'Issue',3,'','2014-11-18 08:19:01',0),(134,112,'Issue',3,'','2014-11-18 10:48:07',0),(135,101,'Issue',3,'','2014-11-18 11:33:12',0),(136,104,'Issue',3,'','2014-11-18 11:33:52',0),(137,28,'Issue',3,'','2014-11-18 11:43:17',0),(138,28,'Issue',3,'','2014-11-18 11:44:01',0),(139,64,'Issue',3,'','2014-11-18 11:44:55',0),(140,64,'Issue',3,'','2014-11-18 11:46:50',0),(141,64,'Issue',3,'','2014-11-18 12:05:17',0),(142,64,'Issue',3,'','2014-11-18 12:05:24',0),(143,60,'Issue',3,'','2014-11-18 12:05:47',0),(144,62,'Issue',3,'','2014-11-18 12:06:57',0),(145,109,'Issue',3,'','2014-11-18 12:07:31',0),(146,109,'Issue',3,'','2014-11-18 12:07:40',0),(147,97,'Issue',3,'','2014-11-18 12:10:16',0),(148,109,'Issue',3,'','2014-11-18 12:11:11',0),(149,117,'Issue',3,'','2014-11-18 12:14:17',0),(150,116,'Issue',3,'','2014-11-18 12:15:06',0),(151,116,'Issue',3,'','2014-11-18 14:20:16',0),(152,105,'Issue',3,'','2014-11-18 14:21:12',0),(153,106,'Issue',3,'','2014-11-18 14:21:19',0),(154,107,'Issue',3,'','2014-11-18 14:21:24',0),(155,110,'Issue',3,'','2014-11-18 14:21:31',0),(156,107,'Issue',3,'','2014-11-18 14:31:36',0),(157,120,'Issue',3,'psutil.cpu_percent а не psutil.cpu_times','2014-11-27 10:56:49',0),(158,122,'Issue',3,'','2014-12-03 16:46:10',0),(159,122,'Issue',3,'','2014-12-03 16:46:29',0),(160,124,'Issue',3,'wrong type should be integere host resource mib','2014-12-03 16:54:06',0),(161,124,'Issue',3,'/usr/share/snmp/mibs','2014-12-03 17:21:51',0),(162,129,'Issue',3,'','2014-12-03 18:32:47',0),(163,123,'Issue',3,'','2015-01-12 08:08:16',0),(164,126,'Issue',3,'','2015-01-12 08:08:44',0),(165,125,'Issue',3,'','2015-01-12 08:14:13',0),(166,125,'Issue',3,'','2015-01-12 08:14:24',0),(167,120,'Issue',3,'','2015-01-12 08:16:59',0),(168,118,'Issue',3,'','2015-01-12 08:18:54',0),(169,107,'Issue',3,'','2015-01-12 08:19:27',0),(170,110,'Issue',3,'','2015-01-12 08:19:38',0),(171,105,'Issue',3,'','2015-01-12 08:19:53',0),(172,94,'Issue',3,'Потому что коммутатор имел неправильный ip адрес (из другой сетки)','2015-01-12 08:20:29',0),(173,102,'Issue',3,'Теперь работают','2015-01-12 08:21:01',0),(174,103,'Issue',3,'Кабель питания модуля был выдернут, теперь исправлено.','2015-01-12 08:21:57',0),(175,103,'Issue',3,'','2015-01-12 08:22:04',0),(176,104,'Issue',3,'','2015-01-12 08:22:18',0),(177,109,'Issue',3,'','2015-01-12 08:22:41',0),(178,106,'Issue',3,'','2015-01-12 08:22:54',0),(179,126,'Issue',3,'','2015-01-12 08:24:43',0),(180,131,'Issue',3,'','2015-01-12 08:26:08',0),(181,130,'Issue',3,'','2015-01-12 08:26:22',0),(182,90,'Issue',3,'','2015-01-12 08:26:56',0),(183,123,'Issue',3,'','2015-01-12 08:27:49',0),(184,125,'Issue',3,'','2015-01-12 08:28:52',0),(185,129,'Issue',3,'','2015-01-12 08:29:10',0),(186,134,'Issue',3,'','2015-01-12 08:29:47',0),(187,128,'Issue',3,'','2015-01-12 08:29:55',0),(188,127,'Issue',3,'','2015-01-12 08:30:06',0),(189,133,'Issue',3,'','2015-01-12 08:30:35',0),(190,122,'Issue',3,'','2015-01-12 08:31:24',0),(191,104,'Issue',3,'','2015-01-12 08:32:20',0),(192,89,'Issue',3,'неверный ip','2015-01-12 08:32:48',0),(193,85,'Issue',3,'','2015-01-12 08:33:44',0),(194,84,'Issue',3,'','2015-01-12 08:34:02',0),(195,81,'Issue',3,'','2015-01-12 08:34:49',0),(196,71,'Issue',3,'done','2015-01-12 08:35:08',0),(197,74,'Issue',3,'done','2015-01-12 08:35:27',0),(198,75,'Issue',3,'done','2015-01-12 08:35:43',0),(199,76,'Issue',3,'done','2015-01-12 08:36:09',0),(200,77,'Issue',3,'','2015-01-12 08:36:27',0),(201,77,'Issue',3,'Скрипт практически есть у Антона, надо протестирвать.','2015-01-12 08:36:43',0),(202,79,'Issue',3,'','2015-01-12 08:37:05',0),(203,80,'Issue',3,'не релевантно','2015-01-12 08:37:24',0),(204,70,'Issue',3,'','2015-01-12 08:37:38',0),(205,69,'Issue',3,'','2015-01-12 08:38:53',0),(206,68,'Issue',3,'','2015-01-12 08:39:12',0),(207,106,'Issue',3,'копия','2015-01-12 08:39:44',0),(208,106,'Issue',3,'','2015-01-12 08:39:50',0),(209,67,'Issue',3,'','2015-01-12 08:40:42',0),(210,63,'Issue',3,'не релевантно','2015-01-12 08:41:12',0),(211,119,'Issue',3,'','2015-01-12 08:44:57',0),(212,117,'Issue',3,'','2015-01-12 08:45:15',0),(214,62,'Issue',3,'','2015-01-12 08:46:05',0),(216,53,'Issue',3,'','2015-01-12 08:47:01',0),(217,51,'Issue',3,'','2015-01-12 08:47:14',0),(218,50,'Issue',3,'','2015-01-12 08:47:30',0),(219,49,'Issue',3,'не нужен','2015-01-12 08:47:48',0),(220,46,'Issue',3,'','2015-01-12 08:54:31',0),(221,36,'Issue',3,'','2015-01-12 08:54:51',0),(222,38,'Issue',3,'','2015-01-12 08:55:05',0),(223,33,'Issue',3,'','2015-01-12 08:55:43',0),(224,24,'Issue',3,'','2015-01-12 08:55:59',0),(225,21,'Issue',3,'','2015-01-12 08:56:11',0),(226,20,'Issue',3,'дубликат','2015-01-12 08:56:28',0),(227,18,'Issue',3,'','2015-01-12 08:56:41',0),(228,10,'Issue',3,'','2015-01-12 08:56:50',0),(229,2,'Issue',3,'не нужно','2015-01-12 08:57:09',0),(230,135,'Issue',3,'','2015-01-12 08:57:32',0),(231,132,'Issue',3,'','2015-01-12 08:57:54',0),(232,46,'Issue',3,'','2015-01-12 08:58:42',0),(233,32,'Issue',3,'','2015-01-12 08:58:53',0),(234,31,'Issue',3,'','2015-01-12 08:58:59',0),(235,27,'Issue',3,'','2015-01-12 08:59:19',0),(236,25,'Issue',3,'','2015-01-12 08:59:38',0),(237,17,'Issue',3,'','2015-01-12 08:59:53',0),(238,13,'Issue',3,'','2015-01-12 09:00:15',0),(239,7,'Issue',3,'','2015-01-12 09:00:30',0),(240,6,'Issue',3,'','2015-01-12 09:00:43',0),(241,5,'Issue',3,'','2015-01-12 09:00:56',0),(242,4,'Issue',3,'','2015-01-12 09:01:07',0),(243,3,'Issue',3,'','2015-01-12 09:01:34',0),(244,63,'Issue',3,'','2015-01-12 09:17:49',0),(246,84,'Issue',3,'','2015-01-12 09:23:07',0),(247,85,'Issue',3,'','2015-01-12 09:23:15',0),(248,104,'Issue',3,'','2015-01-12 09:24:46',0),(249,106,'Issue',3,'','2015-01-12 09:24:55',0),(250,62,'Issue',3,'','2015-01-12 09:25:17',0),(251,53,'Issue',3,'','2015-01-12 09:25:25',0),(252,4,'Issue',3,'','2015-01-12 09:25:37',0),(253,130,'Issue',3,'','2015-01-12 09:28:49',0),(254,132,'Issue',3,'','2015-01-12 09:29:18',0),(255,132,'Issue',3,'','2015-01-12 09:37:48',0),(256,50,'Issue',3,'','2015-01-12 09:39:48',0),(257,120,'Issue',3,'','2015-01-12 10:52:50',0),(258,125,'Issue',3,'','2015-01-12 10:55:41',0),(259,62,'Issue',3,'дубликат','2015-01-12 10:56:11',0),(260,118,'Issue',3,'','2015-01-12 10:56:54',0),(261,129,'Issue',3,'','2015-01-12 10:58:14',0),(262,81,'Issue',3,'','2015-01-12 10:58:19',0),(263,18,'Issue',3,'','2015-01-12 10:58:52',0),(264,140,'Issue',3,'','2015-01-12 11:00:41',0),(265,119,'Issue',3,'','2015-01-12 11:01:15',0),(267,28,'Issue',3,'','2015-01-12 11:04:13',0),(269,139,'Issue',3,'','2015-01-12 11:08:19',0),(270,139,'Issue',3,'','2015-01-12 11:08:25',0),(271,141,'Issue',3,'','2015-01-12 11:10:21',0),(272,129,'Issue',3,'','2015-01-12 11:36:59',0),(273,129,'Issue',3,'','2015-01-12 11:37:09',0),(274,28,'Issue',3,'','2015-01-12 13:43:55',0),(275,140,'Issue',3,'','2015-01-12 13:44:31',0),(276,120,'Issue',3,'','2015-01-12 13:44:44',0),(277,5,'Issue',3,'','2015-01-12 13:45:25',0),(278,7,'Issue',3,'','2015-01-12 13:45:32',0),(279,13,'Issue',3,'','2015-01-12 13:45:44',0),(280,46,'Issue',3,'','2015-01-12 13:45:50',0),(281,36,'Issue',3,'','2015-01-12 13:45:57',0),(282,107,'Issue',3,'','2015-01-12 13:46:03',0),(283,134,'Issue',3,'','2015-01-12 13:46:22',0),(284,17,'Issue',3,'','2015-01-12 13:46:33',0),(285,79,'Issue',3,'','2015-01-12 13:46:39',0),(286,77,'Issue',3,'','2015-01-12 13:47:08',0),(287,133,'Issue',3,'','2015-01-12 13:47:28',0),(288,133,'Issue',3,'','2015-01-12 13:47:40',0),(289,24,'Issue',3,'','2015-01-12 14:21:24',0),(290,107,'Issue',3,'','2015-01-12 14:22:20',0),(291,67,'Issue',3,'','2015-01-12 14:22:27',0),(292,139,'Issue',3,'','2015-01-12 14:22:36',0),(293,138,'Issue',3,'','2015-01-12 14:22:42',0),(294,137,'Issue',3,'','2015-01-12 14:22:48',0),(295,79,'Issue',3,'','2015-01-12 14:22:54',0),(296,85,'Issue',3,'','2015-01-12 14:23:00',0),(297,135,'Issue',3,'','2015-01-12 14:23:29',0),(298,135,'Issue',3,'','2015-01-12 14:23:47',0),(299,133,'Issue',3,'','2015-01-12 14:23:54',0),(300,132,'Issue',3,'','2015-01-12 14:24:00',0),(301,131,'Issue',3,'','2015-01-12 14:24:06',0),(302,125,'Issue',3,'','2015-01-12 14:24:20',0),(303,110,'Issue',3,'','2015-01-12 14:24:29',0),(304,28,'Issue',3,'','2015-01-12 14:24:41',0),(305,119,'Issue',3,'','2015-01-12 14:25:03',0),(306,120,'Issue',3,'','2015-01-12 14:25:09',0),(307,130,'Issue',3,'','2015-01-12 14:25:32',0),(308,130,'Issue',3,'','2015-01-12 14:25:39',0),(309,67,'Issue',3,'ipmitool -I lan -H 10.0.0.55 -U root -P superuser sensor получает все','2015-01-12 14:30:23',0);
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_roles`
--

DROP TABLE IF EXISTS `member_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `inherited_from` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_member_roles_on_member_id` (`member_id`),
  KEY `index_member_roles_on_role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_roles`
--

LOCK TABLES `member_roles` WRITE;
/*!40000 ALTER TABLE `member_roles` DISABLE KEYS */;
INSERT INTO `member_roles` VALUES (1,1,3,NULL),(2,1,4,NULL),(3,1,5,NULL),(7,3,4,NULL),(8,3,5,NULL);
/*!40000 ALTER TABLE `member_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `mail_notification` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_members_on_user_id_and_project_id` (`user_id`,`project_id`),
  KEY `index_members_on_user_id` (`user_id`),
  KEY `index_members_on_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (1,3,2,'2014-08-27 04:17:17',0),(3,5,2,'2015-01-12 10:52:07',0);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `board_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `author_id` int(11) DEFAULT NULL,
  `replies_count` int(11) NOT NULL DEFAULT '0',
  `last_reply_id` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `locked` tinyint(1) DEFAULT '0',
  `sticky` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `messages_board_id` (`board_id`),
  KEY `messages_parent_id` (`parent_id`),
  KEY `index_messages_on_last_reply_id` (`last_reply_id`),
  KEY `index_messages_on_author_id` (`author_id`),
  KEY `index_messages_on_created_on` (`created_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `title` varchar(60) NOT NULL DEFAULT '',
  `summary` varchar(255) DEFAULT '',
  `description` text,
  `author_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `comments_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `news_project_id` (`project_id`),
  KEY `index_news_on_author_id` (`author_id`),
  KEY `index_news_on_created_on` (`created_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `open_id_authentication_associations`
--

DROP TABLE IF EXISTS `open_id_authentication_associations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_id_authentication_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issued` int(11) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `assoc_type` varchar(255) DEFAULT NULL,
  `server_url` blob,
  `secret` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_id_authentication_associations`
--

LOCK TABLES `open_id_authentication_associations` WRITE;
/*!40000 ALTER TABLE `open_id_authentication_associations` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_id_authentication_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `open_id_authentication_nonces`
--

DROP TABLE IF EXISTS `open_id_authentication_nonces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_id_authentication_nonces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL,
  `server_url` varchar(255) DEFAULT NULL,
  `salt` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_id_authentication_nonces`
--

LOCK TABLES `open_id_authentication_nonces` WRITE;
/*!40000 ALTER TABLE `open_id_authentication_nonces` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_id_authentication_nonces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `homepage` varchar(255) DEFAULT '',
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `parent_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `inherit_members` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_projects_on_lft` (`lft`),
  KEY `index_projects_on_rgt` (`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'dummy','','',0,NULL,'2014-08-26 07:09:56','2014-08-26 07:09:56','dummy',1,1,2,0),(2,'Network Monitoring System','','',0,NULL,'2014-08-27 04:15:02','2015-01-12 11:10:56','nms',1,3,4,0),(3,'Personal','','',1,NULL,'2014-09-25 01:09:32','2014-09-25 01:09:32','personal',1,5,6,0);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_trackers`
--

DROP TABLE IF EXISTS `projects_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects_trackers` (
  `project_id` int(11) NOT NULL DEFAULT '0',
  `tracker_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `projects_trackers_unique` (`project_id`,`tracker_id`),
  KEY `projects_trackers_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_trackers`
--

LOCK TABLES `projects_trackers` WRITE;
/*!40000 ALTER TABLE `projects_trackers` DISABLE KEYS */;
INSERT INTO `projects_trackers` VALUES (1,1),(1,2),(1,3),(2,1),(2,2),(2,3),(3,3);
/*!40000 ALTER TABLE `projects_trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries`
--

DROP TABLE IF EXISTS `queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `filters` text,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `column_names` text,
  `sort_criteria` text,
  `group_by` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `visibility` int(11) DEFAULT '0',
  `options` text,
  `tt_query_type` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_queries_on_project_id` (`project_id`),
  KEY `index_queries_on_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries`
--

LOCK TABLES `queries` WRITE;
/*!40000 ALTER TABLE `queries` DISABLE KEYS */;
/*!40000 ALTER TABLE `queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries_roles`
--

DROP TABLE IF EXISTS `queries_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queries_roles` (
  `query_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  UNIQUE KEY `queries_roles_ids` (`query_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries_roles`
--

LOCK TABLES `queries_roles` WRITE;
/*!40000 ALTER TABLE `queries_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `queries_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repositories`
--

DROP TABLE IF EXISTS `repositories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repositories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `login` varchar(60) DEFAULT '',
  `password` varchar(255) DEFAULT '',
  `root_url` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT NULL,
  `path_encoding` varchar(64) DEFAULT NULL,
  `log_encoding` varchar(64) DEFAULT NULL,
  `extra_info` text,
  `identifier` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_repositories_on_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repositories`
--

LOCK TABLES `repositories` WRITE;
/*!40000 ALTER TABLE `repositories` DISABLE KEYS */;
/*!40000 ALTER TABLE `repositories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `position` int(11) DEFAULT '1',
  `assignable` tinyint(1) DEFAULT '1',
  `builtin` int(11) NOT NULL DEFAULT '0',
  `permissions` text,
  `issues_visibility` varchar(30) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Non member',1,1,1,'---\n- :view_issues\n- :add_issues\n- :add_issue_notes\n- :save_queries\n- :view_gantt\n- :view_calendar\n- :view_time_entries\n- :comment_news\n- :view_documents\n- :view_wiki_pages\n- :view_wiki_edits\n- :add_messages\n- :view_files\n- :browse_repository\n- :view_changesets\n','default'),(2,'Anonymous',2,1,2,'---\n- :view_issues\n- :view_gantt\n- :view_calendar\n- :view_time_entries\n- :view_documents\n- :view_wiki_pages\n- :view_wiki_edits\n- :view_files\n- :browse_repository\n- :view_changesets\n','default'),(3,'Manager',3,1,0,'---\n- :add_project\n- :edit_project\n- :close_project\n- :select_project_modules\n- :manage_members\n- :manage_versions\n- :add_subprojects\n- :manage_categories\n- :view_issues\n- :add_issues\n- :edit_issues\n- :manage_issue_relations\n- :manage_subtasks\n- :set_issues_private\n- :set_own_issues_private\n- :add_issue_notes\n- :edit_issue_notes\n- :edit_own_issue_notes\n- :view_private_notes\n- :set_notes_private\n- :move_issues\n- :delete_issues\n- :manage_public_queries\n- :save_queries\n- :view_issue_watchers\n- :add_issue_watchers\n- :delete_issue_watchers\n- :log_time\n- :view_time_entries\n- :edit_time_entries\n- :edit_own_time_entries\n- :manage_project_activities\n- :manage_news\n- :comment_news\n- :add_documents\n- :edit_documents\n- :delete_documents\n- :view_documents\n- :manage_files\n- :view_files\n- :manage_wiki\n- :rename_wiki_pages\n- :delete_wiki_pages\n- :view_wiki_pages\n- :export_wiki_pages\n- :view_wiki_edits\n- :edit_wiki_pages\n- :delete_wiki_pages_attachments\n- :protect_wiki_pages\n- :manage_repository\n- :browse_repository\n- :view_changesets\n- :commit_access\n- :manage_related_issues\n- :manage_boards\n- :add_messages\n- :edit_messages\n- :edit_own_messages\n- :delete_messages\n- :delete_own_messages\n- :view_calendar\n- :view_gantt\n','all'),(4,'Developer',4,1,0,'---\n- :manage_versions\n- :manage_categories\n- :view_issues\n- :add_issues\n- :edit_issues\n- :view_private_notes\n- :set_notes_private\n- :manage_issue_relations\n- :manage_subtasks\n- :add_issue_notes\n- :save_queries\n- :view_gantt\n- :view_calendar\n- :log_time\n- :view_time_entries\n- :comment_news\n- :view_documents\n- :view_wiki_pages\n- :view_wiki_edits\n- :edit_wiki_pages\n- :delete_wiki_pages\n- :add_messages\n- :edit_own_messages\n- :view_files\n- :manage_files\n- :browse_repository\n- :view_changesets\n- :commit_access\n- :manage_related_issues\n','default'),(5,'Reporter',5,1,0,'---\n- :view_issues\n- :add_issues\n- :add_issue_notes\n- :save_queries\n- :view_gantt\n- :view_calendar\n- :log_time\n- :view_time_entries\n- :comment_news\n- :view_documents\n- :view_wiki_pages\n- :view_wiki_edits\n- :add_messages\n- :edit_own_messages\n- :view_files\n- :browse_repository\n- :view_changesets\n','default');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('1'),('1-redmine_time_tracker'),('10'),('10-redmine_time_tracker'),('100'),('101'),('102'),('103'),('104'),('105'),('106'),('107'),('108'),('11'),('11-redmine_time_tracker'),('12'),('12-redmine_time_tracker'),('13'),('13-redmine_time_tracker'),('14'),('14-redmine_time_tracker'),('15'),('15-redmine_time_tracker'),('16'),('16-redmine_time_tracker'),('17'),('17-redmine_time_tracker'),('18'),('18-redmine_time_tracker'),('19'),('2'),('2-redmine_time_tracker'),('20'),('20090214190337'),('20090312172426'),('20090312194159'),('20090318181151'),('20090323224724'),('20090401221305'),('20090401231134'),('20090403001910'),('20090406161854'),('20090425161243'),('20090503121501'),('20090503121505'),('20090503121510'),('20090614091200'),('20090704172350'),('20090704172355'),('20090704172358'),('20091010093521'),('20091017212227'),('20091017212457'),('20091017212644'),('20091017212938'),('20091017213027'),('20091017213113'),('20091017213151'),('20091017213228'),('20091017213257'),('20091017213332'),('20091017213444'),('20091017213536'),('20091017213642'),('20091017213716'),('20091017213757'),('20091017213835'),('20091017213910'),('20091017214015'),('20091017214107'),('20091017214136'),('20091017214236'),('20091017214308'),('20091017214336'),('20091017214406'),('20091017214440'),('20091017214519'),('20091017214611'),('20091017214644'),('20091017214720'),('20091017214750'),('20091025163651'),('20091108092559'),('20091114105931'),('20091123212029'),('20091205124427'),('20091220183509'),('20091220183727'),('20091220184736'),('20091225164732'),('20091227112908'),('20100129193402'),('20100129193813'),('20100221100219'),('20100313132032'),('20100313171051'),('20100705164950'),('20100819172912'),('20101104182107'),('20101107130441'),('20101114115114'),('20101114115359'),('20110220160626'),('20110223180944'),('20110223180953'),('20110224000000'),('20110226120112'),('20110226120132'),('20110227125750'),('20110228000000'),('20110228000100'),('20110401192910'),('20110408103312'),('20110412065600'),('20110511000000'),('20110902000000'),('20111201201315'),('20120115143024'),('20120115143100'),('20120115143126'),('20120127174243'),('20120205111326'),('20120223110929'),('20120301153455'),('20120422150750'),('20120705074331'),('20120707064544'),('20120714122000'),('20120714122100'),('20120714122200'),('20120731164049'),('20120930112914'),('20121026002032'),('20121026003537'),('20121209123234'),('20121209123358'),('20121213084931'),('20130110122628'),('20130201184705'),('20130202090625'),('20130207175206'),('20130207181455'),('20130215073721'),('20130215111127'),('20130215111141'),('20130217094251'),('20130602092539'),('20130710182539'),('20130713104233'),('20130713111657'),('20130729070143'),('20130911193200'),('20131004113137'),('20131005100610'),('20131124175346'),('20131210180802'),('20131214094309'),('20131215104612'),('20131218183023'),('20140228130325'),('21'),('22'),('23'),('24'),('25'),('26'),('27'),('28'),('29'),('3'),('3-redmine_time_tracker'),('30'),('31'),('32'),('33'),('34'),('35'),('36'),('37'),('38'),('39'),('4'),('4-redmine_time_tracker'),('40'),('41'),('42'),('43'),('44'),('45'),('46'),('47'),('48'),('49'),('5'),('5-redmine_time_tracker'),('50'),('51'),('52'),('53'),('54'),('55'),('56'),('57'),('58'),('59'),('6'),('6-redmine_time_tracker'),('60'),('61'),('62'),('63'),('64'),('65'),('66'),('67'),('68'),('69'),('7'),('7-redmine_time_tracker'),('70'),('71'),('72'),('73'),('74'),('75'),('76'),('77'),('78'),('79'),('8'),('8-redmine_time_tracker'),('80'),('81'),('82'),('83'),('84'),('85'),('86'),('87'),('88'),('89'),('9'),('9-redmine_time_tracker'),('90'),('91'),('92'),('93'),('94'),('95'),('96'),('97'),('98'),('99');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_settings_on_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'ui_theme','alternate','2014-10-21 15:04:00'),(2,'default_language','en','2014-10-21 15:04:00'),(3,'force_default_language_for_anonymous','0','2014-10-21 15:04:00'),(4,'force_default_language_for_loggedin','0','2014-10-21 15:04:00'),(5,'start_of_week','','2014-10-21 15:04:00'),(6,'date_format','','2014-10-21 15:04:00'),(7,'time_format','','2014-10-21 15:04:00'),(8,'user_format','firstname_lastname','2014-10-21 15:04:00'),(9,'gravatar_enabled','0','2014-10-21 15:04:00'),(10,'gravatar_default','','2014-10-21 15:04:00'),(11,'thumbnails_enabled','0','2014-10-21 15:04:00'),(12,'thumbnails_size','100','2014-10-21 15:04:00'),(13,'app_title','Redmine','2014-10-21 15:05:14'),(14,'welcome_text','','2014-10-21 15:05:14'),(15,'attachment_max_size','45120','2014-10-21 15:05:14'),(16,'per_page_options','25,50,100','2014-10-21 15:05:14'),(17,'activity_days_default','30','2014-10-21 15:05:14'),(18,'host_name','localhost:3000','2014-10-21 15:05:14'),(19,'protocol','http','2014-10-21 15:05:14'),(20,'text_formatting','textile','2014-10-21 15:05:14'),(21,'cache_formatted_text','0','2014-10-21 15:05:14'),(22,'wiki_compression','','2014-10-21 15:05:14'),(23,'feeds_limit','15','2014-10-21 15:05:14'),(24,'file_max_size_displayed','512','2014-10-21 15:05:14'),(25,'diff_max_lines_displayed','1500','2014-10-21 15:05:14'),(26,'repositories_encodings','','2014-10-21 15:05:14'),(27,'cross_project_issue_relations','0','2014-11-18 14:25:21'),(28,'cross_project_subtasks','tree','2014-11-18 14:25:21'),(29,'issue_group_assignment','0','2014-11-18 14:25:21'),(30,'default_issue_start_date_to_creation_date','1','2014-11-18 14:25:21'),(31,'display_subprojects_issues','1','2014-11-18 14:25:21'),(32,'issue_done_ratio','issue_field','2014-11-18 14:25:21'),(33,'non_working_week_days','---\n- \'6\'\n- \'7\'\n','2014-11-18 14:25:21'),(34,'issues_export_limit','500','2014-11-18 14:25:21'),(35,'gantt_items_limit','500','2014-11-18 14:25:21'),(36,'issue_list_default_columns','---\n- tracker\n- status\n- priority\n- subject\n- assigned_to\n- updated_on\n- category\n- estimated_hours\n- spent_hours\n- due_date\n','2014-11-18 14:25:21');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_bookings`
--

DROP TABLE IF EXISTS `time_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_log_id` int(11) DEFAULT NULL,
  `time_entry_id` int(11) DEFAULT NULL,
  `started_on` datetime DEFAULT NULL,
  `stopped_at` datetime DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_bookings`
--

LOCK TABLES `time_bookings` WRITE;
/*!40000 ALTER TABLE `time_bookings` DISABLE KEYS */;
INSERT INTO `time_bookings` VALUES (1,2,1,'2014-08-26 07:10:00','2014-08-26 07:11:00',1),(2,3,2,'2014-09-04 02:12:00','2014-09-04 23:59:00',2),(3,4,4,'2014-09-09 23:26:00','2014-09-09 23:37:00',2),(4,5,8,'2014-09-12 02:27:00','2014-09-12 03:55:00',2),(5,6,12,'2014-09-24 23:58:00','2014-09-25 00:19:00',2),(6,7,13,'2014-09-25 00:19:00','2014-09-25 00:26:00',2),(7,8,14,'2014-09-25 00:26:00','2014-09-25 00:49:00',2),(8,9,15,'2014-09-25 01:09:00','2014-09-25 02:57:00',3),(9,10,16,'2014-09-25 02:57:00','2014-09-26 00:31:00',2),(10,11,17,'2014-09-26 00:31:00','2014-09-26 01:23:00',2),(11,12,19,'2014-09-26 03:07:00','2014-09-26 03:43:00',2),(12,13,20,'2014-09-28 23:40:00','2014-09-28 23:46:00',3),(13,14,21,'2014-09-28 23:46:00','2014-09-29 03:15:00',3),(14,15,22,'2014-09-29 03:15:00','2014-09-29 03:41:00',3),(15,16,23,'2014-09-29 03:41:00','2014-09-29 03:51:00',2),(16,17,24,'2014-10-06 02:48:00','2014-10-06 03:30:00',2),(17,18,25,'2014-10-06 03:33:00','2014-10-06 03:34:00',2),(18,19,26,'2014-10-06 03:34:00','2014-10-06 03:36:00',2),(19,20,28,'2014-10-07 00:31:00','2014-10-07 03:59:00',2),(20,21,30,'2014-10-21 09:52:00','2014-10-21 09:58:00',2),(21,23,31,'2014-10-21 10:00:00','2014-10-21 10:10:00',2),(22,24,32,'2014-10-21 10:17:00','2014-10-21 10:18:00',2),(23,25,33,'2014-10-21 10:18:00','2014-10-21 10:55:00',2),(24,26,34,'2014-10-21 10:55:00','2014-10-21 11:31:00',2),(25,27,35,'2014-10-21 11:44:00','2014-10-21 14:12:00',2),(26,28,38,'2014-10-23 07:42:00','2014-10-23 08:29:00',2),(27,29,39,'2014-10-23 08:29:00','2014-10-23 08:30:00',2),(28,30,40,'2014-10-23 08:30:00','2014-10-23 09:34:59',2),(29,31,41,'2014-10-23 09:35:00','2014-10-23 10:25:00',2),(30,32,42,'2014-10-23 10:25:00','2014-10-23 10:26:00',2),(31,33,43,'2014-10-23 10:26:00','2014-10-23 11:27:00',2),(32,34,44,'2014-10-23 11:27:00','2014-10-23 11:51:00',2),(33,35,45,'2014-10-23 12:03:00','2014-10-23 13:26:00',2),(34,36,49,'2014-10-24 10:18:00','2014-10-24 14:36:00',2),(35,37,50,'2014-10-29 08:28:00','2014-10-29 08:30:00',2),(36,38,51,'2014-10-29 09:21:00','2014-10-29 09:36:00',2),(37,39,52,'2014-10-29 09:42:00','2014-10-29 17:03:00',2),(38,40,53,'2014-10-29 17:03:00','2014-10-29 19:32:00',2),(39,41,54,'2014-10-30 08:23:00','2014-10-30 11:59:00',2),(40,42,55,'2014-10-30 11:59:00','2014-10-30 12:34:00',2),(41,43,56,'2014-10-30 12:51:00','2014-10-30 13:50:00',2),(42,44,57,'2014-10-31 10:24:00','2014-10-31 13:17:00',2),(44,46,59,'2014-11-07 13:15:00','2014-11-07 15:51:00',2),(45,48,62,'2014-11-17 08:41:00','2014-11-17 08:58:00',2),(46,49,63,'2014-11-17 08:59:00','2014-11-17 09:16:00',2),(47,50,64,'2014-11-17 11:22:00','2014-11-17 13:01:00',2),(48,51,65,'2014-11-18 08:32:00','2014-11-18 10:48:00',2),(49,52,66,'2014-11-18 10:51:00','2014-11-18 11:34:00',2),(50,53,67,'2014-11-18 11:45:00','2014-11-18 12:06:00',2),(51,54,68,'2014-11-18 12:15:00','2014-11-18 14:20:00',2);
/*!40000 ALTER TABLE `time_bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_entries`
--

DROP TABLE IF EXISTS `time_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `hours` float NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `activity_id` int(11) NOT NULL,
  `spent_on` date NOT NULL,
  `tyear` int(11) NOT NULL,
  `tmonth` int(11) NOT NULL,
  `tweek` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time_entries_project_id` (`project_id`),
  KEY `time_entries_issue_id` (`issue_id`),
  KEY `index_time_entries_on_activity_id` (`activity_id`),
  KEY `index_time_entries_on_user_id` (`user_id`),
  KEY `index_time_entries_on_created_on` (`created_on`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_entries`
--

LOCK TABLES `time_entries` WRITE;
/*!40000 ALTER TABLE `time_entries` DISABLE KEYS */;
INSERT INTO `time_entries` VALUES (1,1,1,1,0.0166667,'sss',8,'2014-08-26',2014,8,35,'2014-08-26 07:10:29','2014-08-26 07:10:29'),(2,2,3,28,21.7833,'',11,'2014-09-04',2014,9,36,'2014-09-04 23:58:46','2014-09-04 23:58:46'),(3,2,3,28,0.5,'',11,'2014-09-08',2014,9,37,'2014-09-08 06:33:09','2014-09-08 06:33:09'),(4,2,3,30,0.183333,NULL,11,'2014-09-10',2014,9,37,'2014-09-09 23:36:59','2014-09-09 23:36:59'),(5,2,3,32,0.2,'',11,'2014-09-10',2014,9,37,'2014-09-09 23:38:09','2014-09-09 23:38:09'),(6,2,3,32,0.3,'',11,'2014-09-12',2014,9,37,'2014-09-12 01:26:17','2014-09-12 01:26:17'),(7,2,3,31,0.1,'',10,'2014-09-12',2014,9,37,'2014-09-12 01:26:31','2014-09-12 01:26:31'),(8,2,3,28,1.46667,NULL,11,'2014-09-12',2014,9,37,'2014-09-12 03:54:51','2014-09-12 03:54:51'),(9,2,3,34,2,'',11,'2014-09-24',2014,9,39,'2014-09-24 02:29:54','2014-09-24 02:29:54'),(10,2,3,35,1,'',11,'2014-09-24',2014,9,39,'2014-09-24 03:09:37','2014-09-24 03:09:37'),(11,2,3,35,1,'',11,'2014-09-24',2014,9,39,'2014-09-24 07:07:15','2014-09-24 07:07:15'),(12,2,3,37,0.35,NULL,11,'2014-09-25',2014,9,39,'2014-09-25 00:18:57','2014-09-25 00:18:57'),(13,2,3,38,0.116667,NULL,11,'2014-09-25',2014,9,39,'2014-09-25 00:25:46','2014-09-25 00:25:46'),(14,2,3,36,0.383333,NULL,11,'2014-09-25',2014,9,39,'2014-09-25 00:48:07','2014-09-25 00:48:07'),(15,3,3,39,1.8,NULL,8,'2014-09-25',2014,9,39,'2014-09-25 02:56:22','2014-09-25 02:56:22'),(16,2,3,36,21.5667,NULL,11,'2014-09-25',2014,9,39,'2014-09-26 00:30:09','2014-09-26 00:30:09'),(17,2,3,32,0.866667,NULL,11,'2014-09-26',2014,9,39,'2014-09-26 01:22:58','2014-09-26 01:22:58'),(18,2,3,36,1,'simple test added',11,'2014-09-26',2014,9,39,'2014-09-26 03:07:14','2014-09-26 03:07:14'),(19,2,3,36,0.6,NULL,11,'2014-09-26',2014,9,39,'2014-09-26 03:42:25','2014-09-26 03:42:25'),(20,3,3,41,0.1,NULL,8,'2014-09-29',2014,9,40,'2014-09-28 23:45:10','2014-09-28 23:45:10'),(21,3,3,39,3.48333,NULL,9,'2014-09-29',2014,9,40,'2014-09-29 03:14:21','2014-09-29 03:14:21'),(22,3,3,42,0.433333,NULL,8,'2014-09-29',2014,9,40,'2014-09-29 03:40:15','2014-09-29 03:40:15'),(23,2,3,32,0.166667,NULL,11,'2014-09-29',2014,9,40,'2014-09-29 03:50:43','2014-09-29 03:50:43'),(24,2,3,26,0.7,NULL,11,'2014-10-06',2014,10,41,'2014-10-06 03:29:46','2014-10-06 03:29:46'),(25,2,3,25,0.0166667,NULL,11,'2014-10-06',2014,10,41,'2014-10-06 03:33:56','2014-10-06 03:33:56'),(26,2,3,25,0.0333333,NULL,11,'2014-10-06',2014,10,41,'2014-10-06 03:35:25','2014-10-06 03:35:25'),(27,2,3,44,1,'',11,'2014-10-06',2014,10,41,'2014-10-06 04:30:30','2014-10-06 04:30:30'),(28,2,3,15,3.46667,NULL,11,'2014-10-07',2014,10,41,'2014-10-07 03:58:12','2014-10-07 03:58:12'),(29,2,3,15,1,'',11,'2014-10-07',2014,10,41,'2014-10-07 04:27:47','2014-10-07 04:27:47'),(30,2,3,51,0.1,NULL,11,'2014-10-21',2014,10,43,'2014-10-21 09:57:44','2014-10-21 09:57:44'),(31,2,3,51,0.166667,NULL,11,'2014-10-21',2014,10,43,'2014-10-21 10:09:01','2014-10-21 10:09:01'),(32,2,3,43,0.0166667,NULL,11,'2014-10-21',2014,10,43,'2014-10-21 10:17:37','2014-10-21 10:17:37'),(33,2,3,43,0.616667,NULL,11,'2014-10-21',2014,10,43,'2014-10-21 10:54:30','2014-10-21 10:54:30'),(34,2,3,43,0.6,NULL,11,'2014-10-21',2014,10,43,'2014-10-21 11:30:58','2014-10-21 11:30:58'),(35,2,3,22,2.46667,NULL,11,'2014-10-21',2014,10,43,'2014-10-21 14:11:35','2014-10-21 14:11:35'),(36,2,3,55,1,'',11,'2014-10-21',2014,10,43,'2014-10-21 15:41:17','2014-10-21 15:41:17'),(37,2,3,51,4,'',11,'2014-10-23',2014,10,43,'2014-10-23 07:15:24','2014-10-23 07:15:24'),(38,2,3,59,0.783333,NULL,11,'2014-10-23',2014,10,43,'2014-10-23 08:28:12','2014-10-23 08:28:12'),(39,2,3,58,0.0166667,NULL,11,'2014-10-23',2014,10,43,'2014-10-23 08:29:19','2014-10-23 08:29:19'),(40,2,3,58,1.08333,NULL,11,'2014-10-23',2014,10,43,'2014-10-23 09:34:33','2014-10-23 09:34:33'),(41,2,3,57,0.833333,NULL,11,'2014-10-23',2014,10,43,'2014-10-23 10:24:47','2014-10-23 10:24:47'),(42,2,3,57,0.0166667,NULL,11,'2014-10-23',2014,10,43,'2014-10-23 10:25:20','2014-10-23 10:25:20'),(43,2,3,57,1.01667,NULL,11,'2014-10-23',2014,10,43,'2014-10-23 11:26:47','2014-10-23 11:26:47'),(44,2,3,57,0.4,NULL,11,'2014-10-23',2014,10,43,'2014-10-23 11:50:02','2014-10-23 11:50:02'),(45,2,3,61,1.38333,NULL,11,'2014-10-23',2014,10,43,'2014-10-23 13:25:07','2014-10-23 13:25:07'),(46,2,3,65,1,'',11,'2014-10-23',2014,10,43,'2014-10-23 15:13:40','2014-10-23 15:13:40'),(47,2,3,14,0.3,'',11,'2014-10-23',2014,10,43,'2014-10-23 15:25:26','2014-10-23 15:25:26'),(48,2,3,65,1,'',11,'2014-10-24',2014,10,43,'2014-10-24 08:32:32','2014-10-24 08:32:32'),(49,2,3,62,4.3,NULL,11,'2014-10-24',2014,10,43,'2014-10-24 14:35:41','2014-10-24 14:35:41'),(50,2,3,80,0.0333333,NULL,11,'2014-10-29',2014,10,44,'2014-10-29 08:29:02','2014-10-29 08:29:02'),(51,2,3,78,0.25,NULL,11,'2014-10-29',2014,10,44,'2014-10-29 09:35:35','2014-10-29 09:35:35'),(52,2,3,83,7.35,NULL,11,'2014-10-29',2014,10,44,'2014-10-29 17:02:41','2014-10-29 17:02:41'),(53,2,3,83,2.48333,NULL,11,'2014-10-29',2014,10,44,'2014-10-29 19:31:20','2014-10-29 19:31:20'),(54,2,3,83,3.6,NULL,11,'2014-10-30',2014,10,44,'2014-10-30 11:58:22','2014-10-30 11:58:22'),(55,2,3,73,0.583333,NULL,11,'2014-10-30',2014,10,44,'2014-10-30 12:33:25','2014-10-30 12:33:25'),(56,2,3,76,0.983333,NULL,11,'2014-10-30',2014,10,44,'2014-10-30 13:49:00','2014-10-30 13:49:00'),(57,2,3,86,2.88333,NULL,11,'2014-10-31',2014,10,44,'2014-10-31 13:16:42','2014-10-31 13:16:42'),(59,2,3,83,2.6,NULL,11,'2014-11-07',2014,11,45,'2014-11-07 15:50:19','2014-11-07 15:50:19'),(60,2,3,37,8,'',11,'2014-11-10',2014,11,46,'2014-11-10 08:47:09','2014-11-10 08:47:09'),(61,2,3,114,2,'',11,'2014-11-14',2014,11,46,'2014-11-14 12:15:43','2014-11-14 12:15:43'),(62,2,3,99,0.283333,NULL,11,'2014-11-17',2014,11,47,'2014-11-17 08:57:40','2014-11-17 08:57:40'),(63,2,3,113,0.283333,NULL,11,'2014-11-17',2014,11,47,'2014-11-17 09:15:27','2014-11-17 09:15:27'),(64,2,3,91,1.65,NULL,11,'2014-11-17',2014,11,47,'2014-11-17 13:00:55','2014-11-17 13:00:55'),(65,2,3,112,2.26667,NULL,11,'2014-11-18',2014,11,47,'2014-11-18 10:47:49','2014-11-18 10:47:49'),(66,2,3,101,0.716667,NULL,11,'2014-11-18',2014,11,47,'2014-11-18 11:33:00','2014-11-18 11:33:00'),(67,2,3,64,0.35,NULL,11,'2014-11-18',2014,11,47,'2014-11-18 12:05:07','2014-11-18 12:05:07'),(68,2,3,116,0.3,'',11,'2014-11-18',2014,11,47,'2014-11-18 14:19:48','2014-11-18 14:20:05');
/*!40000 ALTER TABLE `time_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_logs`
--

DROP TABLE IF EXISTS `time_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `started_on` datetime DEFAULT NULL,
  `stopped_at` datetime DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `bookable` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_logs`
--

LOCK TABLES `time_logs` WRITE;
/*!40000 ALTER TABLE `time_logs` DISABLE KEYS */;
INSERT INTO `time_logs` VALUES (1,1,'2014-08-26 07:09:00','2014-08-26 07:10:00',NULL,NULL,1),(2,1,'2014-08-26 07:10:00','2014-08-26 07:11:00',NULL,'sss',0),(3,3,'2014-09-04 02:12:00','2014-09-04 23:59:00',NULL,'',0),(4,3,'2014-09-09 23:26:00','2014-09-09 23:37:00',NULL,NULL,0),(5,3,'2014-09-12 02:27:00','2014-09-12 03:55:00',NULL,NULL,0),(6,3,'2014-09-24 23:58:00','2014-09-25 00:19:00',NULL,NULL,0),(7,3,'2014-09-25 00:19:00','2014-09-25 00:26:00',NULL,NULL,0),(8,3,'2014-09-25 00:26:00','2014-09-25 00:49:00',NULL,NULL,0),(9,3,'2014-09-25 01:09:00','2014-09-25 02:57:00',NULL,NULL,0),(10,3,'2014-09-25 02:57:00','2014-09-26 00:31:00',NULL,NULL,0),(11,3,'2014-09-26 00:31:00','2014-09-26 01:23:00',NULL,NULL,0),(12,3,'2014-09-26 03:07:00','2014-09-26 03:43:00',NULL,NULL,0),(13,3,'2014-09-28 23:40:00','2014-09-28 23:46:00',NULL,NULL,0),(14,3,'2014-09-28 23:46:00','2014-09-29 03:15:00',NULL,NULL,0),(15,3,'2014-09-29 03:15:00','2014-09-29 03:41:00',NULL,NULL,0),(16,3,'2014-09-29 03:41:00','2014-09-29 03:51:00',NULL,NULL,0),(17,3,'2014-10-06 02:48:00','2014-10-06 03:30:00',NULL,NULL,0),(18,3,'2014-10-06 03:33:00','2014-10-06 03:34:00',NULL,NULL,0),(19,3,'2014-10-06 03:34:00','2014-10-06 03:36:00',NULL,NULL,0),(20,3,'2014-10-07 00:31:00','2014-10-07 03:59:00',NULL,NULL,0),(21,3,'2014-10-21 09:52:00','2014-10-21 09:58:00',NULL,NULL,0),(23,3,'2014-10-21 10:00:00','2014-10-21 10:10:00',NULL,NULL,0),(24,3,'2014-10-21 10:17:00','2014-10-21 10:18:00',NULL,NULL,0),(25,3,'2014-10-21 10:18:00','2014-10-21 10:55:00',NULL,NULL,0),(26,3,'2014-10-21 10:55:00','2014-10-21 11:31:00',NULL,NULL,0),(27,3,'2014-10-21 11:44:00','2014-10-21 14:12:00',NULL,NULL,0),(28,3,'2014-10-23 07:42:00','2014-10-23 08:29:00',NULL,NULL,0),(29,3,'2014-10-23 08:29:00','2014-10-23 08:30:00',NULL,NULL,0),(30,3,'2014-10-23 08:30:00','2014-10-23 09:35:00',NULL,NULL,1),(31,3,'2014-10-23 09:35:00','2014-10-23 10:25:00',NULL,NULL,0),(32,3,'2014-10-23 10:25:00','2014-10-23 10:26:00',NULL,NULL,0),(33,3,'2014-10-23 10:26:00','2014-10-23 11:27:00',NULL,NULL,0),(34,3,'2014-10-23 11:27:00','2014-10-23 11:51:00',NULL,NULL,0),(35,3,'2014-10-23 12:03:00','2014-10-23 13:26:00',NULL,NULL,0),(36,3,'2014-10-24 10:18:00','2014-10-24 14:36:00',NULL,NULL,0),(37,3,'2014-10-29 08:28:00','2014-10-29 08:30:00',NULL,NULL,0),(38,3,'2014-10-29 09:21:00','2014-10-29 09:36:00',NULL,NULL,0),(39,3,'2014-10-29 09:42:00','2014-10-29 17:03:00',NULL,NULL,0),(40,3,'2014-10-29 17:03:00','2014-10-29 19:32:00',NULL,NULL,0),(41,3,'2014-10-30 08:23:00','2014-10-30 11:59:00',NULL,NULL,0),(42,3,'2014-10-30 11:59:00','2014-10-30 12:34:00',NULL,NULL,0),(43,3,'2014-10-30 12:51:00','2014-10-30 13:50:00',NULL,NULL,0),(44,3,'2014-10-31 10:24:00','2014-10-31 13:17:00',NULL,NULL,0),(45,3,'2014-10-31 13:17:00','2014-11-05 13:32:00',NULL,NULL,1),(46,3,'2014-11-07 13:15:00','2014-11-07 15:51:00',NULL,NULL,0),(47,3,'2014-11-10 13:01:00','2014-11-14 16:02:00',NULL,NULL,1),(48,3,'2014-11-17 08:41:00','2014-11-17 08:58:00',NULL,NULL,0),(49,3,'2014-11-17 08:59:00','2014-11-17 09:16:00',NULL,NULL,0),(50,3,'2014-11-17 11:22:00','2014-11-17 13:01:00',NULL,NULL,0),(51,3,'2014-11-18 08:32:00','2014-11-18 10:48:00',NULL,NULL,0),(52,3,'2014-11-18 10:51:00','2014-11-18 11:34:00',NULL,NULL,0),(53,3,'2014-11-18 11:45:00','2014-11-18 12:06:00',NULL,NULL,0),(54,3,'2014-11-18 12:15:00','2014-11-18 14:20:00',NULL,NULL,0);
/*!40000 ALTER TABLE `time_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_trackers`
--

DROP TABLE IF EXISTS `time_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_trackers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `started_on` datetime DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `round` tinyint(1) DEFAULT '0',
  `activity_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_trackers`
--

LOCK TABLES `time_trackers` WRITE;
/*!40000 ALTER TABLE `time_trackers` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `action` varchar(30) NOT NULL DEFAULT '',
  `value` varchar(40) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_value` (`value`),
  KEY `index_tokens_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,1,'feeds','727b6ecc5d488f11dcb6158acadbddfbebe0e4f4','2014-08-26 07:03:36'),(2,1,'api','d9b1b0e10bbf518aba7658a4c575178392c9a66e','2014-08-26 07:09:38'),(3,3,'feeds','688d36ecfcde1eae23bce6884d804826167732c7','2014-08-27 04:17:29'),(4,3,'api','fd5d8eddfe7263738c0def71e51145e0cc658ce8','2014-08-27 04:17:48'),(5,4,'feeds','e7fc00be03c3590c63d25cd1234eccd50db7a718','2014-10-20 15:23:28');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trackers`
--

DROP TABLE IF EXISTS `trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trackers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `is_in_chlog` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT '1',
  `is_in_roadmap` tinyint(1) NOT NULL DEFAULT '1',
  `fields_bits` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trackers`
--

LOCK TABLES `trackers` WRITE;
/*!40000 ALTER TABLE `trackers` DISABLE KEYS */;
INSERT INTO `trackers` VALUES (1,'Bug',1,1,0,0),(2,'Feature',1,2,1,0),(3,'Support',0,3,0,0);
/*!40000 ALTER TABLE `trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `others` text,
  `hide_mail` tinyint(1) DEFAULT '0',
  `time_zone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_user_preferences_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
INSERT INTO `user_preferences` VALUES (1,1,'--- {}\n',0,NULL),(2,3,'---\n:no_self_notified: \'0\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n:gantt_zoom: 4\n:gantt_months: 2\n',1,'Moscow'),(3,4,'---\n:no_self_notified: \'0\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',0,'Moscow'),(4,5,'---\n:no_self_notified: \'1\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',1,'Minsk');
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL DEFAULT '',
  `hashed_password` varchar(40) NOT NULL DEFAULT '',
  `firstname` varchar(30) NOT NULL DEFAULT '',
  `lastname` varchar(255) NOT NULL DEFAULT '',
  `mail` varchar(60) NOT NULL DEFAULT '',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `last_login_on` datetime DEFAULT NULL,
  `language` varchar(5) DEFAULT '',
  `auth_source_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `identity_url` varchar(255) DEFAULT NULL,
  `mail_notification` varchar(255) NOT NULL DEFAULT '',
  `salt` varchar(64) DEFAULT NULL,
  `must_change_passwd` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_users_on_id_and_type` (`id`,`type`),
  KEY `index_users_on_auth_source_id` (`auth_source_id`),
  KEY `index_users_on_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','d0120928f363cc8715e474eed203932e1f801b27','Redmine','Admin','admin@example.net',1,1,'2014-08-26 07:03:36','',NULL,'2014-08-26 07:00:42','2014-08-26 07:00:42','User',NULL,'all','dd5645832aaf59e198bd9157cf5fc41e',0),(2,'','','','Anonymous','',0,0,NULL,'',NULL,'2014-08-26 07:03:14','2014-08-26 07:03:14','AnonymousUser',NULL,'only_my_events',NULL,0),(3,'dmitryhd','70a682c8a383a8040d8ead6803938a6701ddc1af','Dmitriy','Khodakov','dmitryhd@gmail.com',1,1,'2015-01-12 14:20:18','en',NULL,'2014-08-27 04:16:57','2014-08-27 04:16:57','User',NULL,'only_my_events','c0642e8e1a4a72e4aee64a43dc0bcd8c',0),(4,'malchun','385c6b9c21d842e5a9b01117a904dce6c9091acb','Anton','Zverev','zmalchunz@gmail.com',0,3,'2014-11-12 03:47:38','en',NULL,'2014-10-20 15:20:17','2015-01-12 10:49:54','User',NULL,'only_my_events','34e277f60189de45964a5b080526848e',0),(5,'apilkevich','abe8bbbc7f40fafe9e860fb2c8029e15d03c7eb8','Artem','Pilkevich','xx@gmail.com',0,1,NULL,'en',NULL,'2015-01-12 10:51:37','2015-01-12 10:51:37','User',NULL,'none','a60b519a0d6066faba95a5f3667d2b11',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `effective_date` date DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `wiki_page_title` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'open',
  `sharing` varchar(255) NOT NULL DEFAULT 'none',
  PRIMARY KEY (`id`),
  KEY `versions_project_id` (`project_id`),
  KEY `index_versions_on_sharing` (`sharing`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
INSERT INTO `versions` VALUES (1,2,'v1.4','Финальная версия первого проекта',NULL,'2015-01-12 09:22:09','2015-01-12 09:22:09','','open','hierarchy');
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watchers`
--

DROP TABLE IF EXISTS `watchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `watchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `watchable_type` varchar(255) NOT NULL DEFAULT '',
  `watchable_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `watchers_user_id_type` (`user_id`,`watchable_type`),
  KEY `index_watchers_on_user_id` (`user_id`),
  KEY `index_watchers_on_watchable_id_and_watchable_type` (`watchable_id`,`watchable_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watchers`
--

LOCK TABLES `watchers` WRITE;
/*!40000 ALTER TABLE `watchers` DISABLE KEYS */;
INSERT INTO `watchers` VALUES (1,'Issue',141,3);
/*!40000 ALTER TABLE `watchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_content_versions`
--

DROP TABLE IF EXISTS `wiki_content_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_content_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wiki_content_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `data` longblob,
  `compression` varchar(6) DEFAULT '',
  `comments` varchar(255) DEFAULT '',
  `updated_on` datetime NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_content_versions_wcid` (`wiki_content_id`),
  KEY `index_wiki_content_versions_on_updated_on` (`updated_on`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_content_versions`
--

LOCK TABLES `wiki_content_versions` WRITE;
/*!40000 ALTER TABLE `wiki_content_versions` DISABLE KEYS */;
INSERT INTO `wiki_content_versions` VALUES (1,1,1,3,'h1. Wiki\r\n\r\n[[План тестирования]]\r\n\r\n[[План рефакторинга]]','','','2014-08-27 04:18:36',1),(2,2,2,3,'h1. План тестирования\r\n\r\nСм Тесты\r\nАлерты\r\n\r\nМодуль представления\r\nЭкспорт в бд\r\n\r\n','','','2014-08-27 04:20:42',1),(3,3,3,3,'h1. План рефакторинга\r\n\r\n# Тесты\r\n# Алерты\r\n# Группы параметров\r\n# Пересмотреть сохранение в бд\r\n\r\n','','','2014-08-27 04:35:55',1),(4,2,2,3,'h1. План тестирования\r\n\r\n# См Тесты\r\n# Алерты\r\n# Модуль представления\r\n# Экспорт в бд\r\n\r\n','','','2014-08-27 04:36:08',2),(5,1,1,3,'h1. Wiki\r\n\r\n[[План тестирования]]\r\n\r\n[[План рефакторинга]]\r\n\r\n[[Спецификация - Оборудование]]\r\n\r\n[[Спецификация - Технологии]]\r\n\r\nh2. [[Техническое задание]]\r\n\r\nh2. [[Текущий список проблем]]\r\n\r\nh2. [[Загрузка по сети]]','','','2014-10-21 14:35:33',2),(6,4,4,3,'h1. Спецификация - Оборудование\r\n\r\nh2. hp-5800\r\n\r\ninitial setup:\r\nplug console cable in special SVK notebook and run putty:\r\nsystem-view\r\nvlan 10\r\ndescription Test VLAN\r\nprotocol-vlan 0 ipv4\r\nip-subnet-vlan 0 ip 192.168.0.0 255.255.0.0\r\n\r\ninterface Vlan-interface10\r\nip address 192.168.7.2 255.255.0.0\r\n\r\ninterface GigabitEthernet1/0/1\r\nport access vlan 10\r\n\r\n[Sysname] local-user admin\r\n[Sysname-luser-admin] service-type telnet\r\n[Sysname-luser-admin] authorization-attribute level 3\r\n[Sysname-luser-admin] password simple admin\r\n\r\nsave\r\n\r\n[end]\r\n\r\n\r\nip: 192.168.7.2 (port 1 only!)\r\nusername: admin\r\npassword: 111111\r\n\r\nreference:\r\nhttp://ixnfo.com/nastroyka-hp-5800.html\r\n\r\nh2. hp-1910-8g\r\n\r\ndefault ip: 169.254.150.62\r\ndon\'t forget your ip: 169.254.150.62/16\r\nhttp://www.petenetlive.com/KB/Article/0000495.htm\r\nDefault access is user name admin with a blank password.\r\n\r\ncurrent ip: 192.168.7.1\r\n\r\nh2. PDU\r\n\r\nip 192.168.20.1\r\nip 192.168.20.2\r\nip 192.168.20.3\r\nip 192.168.20.4\r\n\r\nAPC 8981\r\n\r\nlogin: apc\r\npass: apc\r\n\r\nMIB - смотри приложение, rPDU.\r\n\r\nOverload Alarm: 	kW 16.0\r\nNear Overload Warning: 	kW 8.8\r\nLow Load Warning: 	kW 0.0\r\n\r\nh2. UPS\r\n\r\n*powerware 9130 3kva*\r\n\r\nip интерфейса станции 192.168.0.1\r\nip интерфейса UPS 192.168.7.18\r\n\r\nmib - http://support.ipmonitor.com/mibs/XUPS-MIB/raw.aspx\r\n\r\nSNMP параметры\r\nprivate iso.3.6.1.4.1.534 \r\n# \"Battery run time in seconds before UPS turns off due to low battery\" : \"1.2.1\",\r\n# \"Battery percent charge\" : \"1.2.4\"\r\n\r\nh2. RAID\r\n\r\ndothill 3730\r\nweb login: manage\r\nweb password: !manage\r\nPower 436W\r\n\r\n|_. Raid |_. Serial Number |_. FileServer01 |_. FileServer02 |\r\n| Raid01 | a2a | sdc | sdb |\r\n| Raid01 | a52 | sdb | sde |\r\n\r\nh2. KVM\r\n\r\n192.168.0.60 \r\n\r\nlogin: administrator\r\npass: password\r\n\r\n6EA0D-L0X7B-SCJE0-06272\r\n\r\n\r\nh2. остальные сервера\r\n\r\nuser - 111111\r\nroot - 111111\r\n\r\nh2. Как разметить Raid на 20Тб\r\nparted /dev/sdb\r\n>mklabel\r\n>gpt\r\n\r\ngit clone git://git.kernel.org/pub/scm/fs/ext2/e2fsprogs.git\r\ncd e2fsprogs\r\nmkdir build ; cd build/\r\n../configure\r\nmake\r\nmake install\r\n./mke2fs -O 64bit,has_journal,extents,huge_file,flex_bg, uninit_bg,dir_nlink,extra_isize -i 4194304 /dev/sdb\r\n\r\n\r\nh2. NetBootz 200\r\n\r\narp -s 192.168.11.2 00:c0:b7:9b:91:c0\r\nping 192.168.11.2 -s 113\r\n\r\nhttp://www.apc.com/products/resource/include/techspec_index.cfm?base_sku=NBRK0201\r\n\r\nhttp://www.irrexpr.com/2012/06/accessing-snmp-temperature-information.html\r\n\r\nlogin apc\r\npassw apc\r\n\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.3.0.1  - Sensor Name\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.4.0.1  - Sensor Location\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.5.0.1  - Temperature\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.6.0.1  - Humid\r\n\r\n\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.1.0.2 = INTEGER: 0\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.2.0.2 = INTEGER: 2\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.3.0.2 = STRING: \"Sensor MM:2\"\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.4.0.2 = STRING: \"Unknown\"\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.5.0.2 = INTEGER: 1 -> 2 при open\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.7.0.2 = INTEGER: 2 -> 1 при open\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.8.0.2 = INTEGER: 2 -\r\n\r\nh2. Расчётные серверы\r\n\r\n1) 192.168.10.11 - BMC','','','2014-10-21 14:36:04',1),(7,5,5,3,'h1. Спецификация - Технологии\r\n\r\nh1. SNMP\r\n\r\nпримеры команд os linux:\r\n<pre>\r\nsnmpwalk -Os -c public -v 1 192.168.7.18\r\nsnmpget -v 1 -Cf -c public 192.168.7.18 iso.3.6.1.4.1.534.1.2.4\r\n</pre>\r\n\r\nSNMP работает на прикладном уровне TCP/IP (седьмой уровень модели OSI). Агент SNMP получает запросы по UDP-порту 161. Менеджер может посылать запросы с любого доступного порта источника на порт агента. Ответ агента будет отправлен назад на порт источника на менеджере. Менеджер получает уведомления (Traps и InformRequests) по порту 162. Агент может генерировать уведомления с любого доступного порта. При использовании TLS или DTLS запросы получаются по порту 10161, а ловушки отправляются на порт 10162.\r\n\r\nsnmp v2 - Добавлен bulkrequest и криптозащита, улучшена производительность, несовместим с v1\r\nsnmp v3 - Улучшена криптозащита.\r\n\r\nh2. Зачем нужны коммьюнити (скрипт sudo snmpconf -i -g basic_setup)\r\n\r\nThe community name to add read-only access for: public\r\nThe hostname or network address to accept this community name from [RETURN for all]: \r\nThe OID that this community should be restricted to [RETURN for no-restriction]: \r\n\r\nпо конфигурированию:\r\ninformsink  127.0.0.1 - A host name that should receive the trap\r\n\r\n\"Net-SNMP_and_lm-sensors\":http://www.net-snmp.org/wiki/index.php/Net-SNMP_and_lm-sensors_on_Ubuntu_10.04\r\n\r\nОчень непросто оказывается настраивать snmpd\r\n\r\nh1. Telnet\r\n\r\nHow to change screen size in telnet:\r\nhttp://stackoverflow.com/questions/11575558/is-it-possible-to-send-resize-pty-command-with-telnetlib\r\n\r\nh1. WEB\r\n\r\nh2. WSGI\r\n\r\n1) /etc/apache2/sites-available/default заменить на прикрепленный файл\r\n2) установить libapache2-mod-wsgi-py3\r\n3) export PYTHONPATH=path_to_nms_app\r\n4) база данных генерится командой python3 collector.py -f nms_random_10_09_2013_100_val -g 1 -t 0.1\r\n5) переписать везде абсолютные пути\r\n\r\nh2. Django\r\n\r\n1) Установка Timezone - settings.py TIMEZONE=None, USE_TZ=True\r\n\r\nh1. MySQL\r\n\r\nУзнать размер всех баз данных в мегабайтах\r\nSELECT table_schema \"DB Name\", Round(Sum(data_length + index_length) / 1024 / 1024, 1) \"DB Size in MB\"  FROM  information_schema.tables  GROUP  BY table_schema;\r\n\r\nПолный бекап данных:\r\n@\r\nmysqldump -u root -p111111 06_12_db > 06_12_db.sql\r\ntar czf 06_12_db.sql.tgz 06_12_db.sql\r\nscp user@192.168.1.1:/home/user/06_12_db.sql.tgz .\r\ntar xzf 06_12_db.sql.tgz\r\nmysql -u root -p111111\r\ncreate database 06_12_db_new;\r\nmysql -u root -p111111 06_12_db_new < 06_12_db.sql\r\n@\r\nsudo /etc/init.d/mysqld start\r\n\r\nh1. DHCP\r\n\r\nExample tested on ubuntu\r\n\r\nsudo apt-get install dhcp3-server\r\nsudo vi /etc/default/dhcp3-server\r\nINTERFACES=\"eth0″\r\nsudo vi /etc/dhcp/dhcpd.conf\r\nsubnet 192.168.0.0 netmask 255.255.255.0 {\r\n   range 192.168.0.1 192.168.0.200;\r\n   option routers 127.0.0.1;\r\n}\r\n\r\nhost pdu0 {\r\n   hardware ethernet 00:c0:b7:9b:2c:b4;\r\n   fixed-address 192.168.0.68;\r\n }\r\n\r\nsudo dhcpd\r\n\r\nh1. Other\r\n\r\nPing all devices in a subnet:\r\n\r\nsudo arp-scan --interface=eth0 192.168.0.0/24\r\n\r\nh1. Root on NFS\r\n\r\nhttp://rags.wordpress.com/2012/03/20/using-nfsroot-to-boot-diskless-clients-on-rhel/\r\n\r\nh1. nvidia-smi\r\n\r\n1) add lines from configs/server_snmpd.conf to snmpd.conf\r\n2) run run_nvsmi.sh\r\n3) place parse_nvsmi_xml.py into /root folder\r\n\r\n\r\nh1. intel mpi\r\n\r\n1) make mpd.hosts file in format \r\nhost:number of processes\r\nplace .mpd.conf with secret phrase (see ics tutorial)\r\n\r\nmpirun -r ssh -f ~/mpd.hosts -perhost [number_of_processes_per_jost] -np [total_number_of_processes] [program + parameters]\r\n\r\nmpd.hosts contains lists of hosts in the format:\r\nip(or hostname):max_number_of_processes_for_this_host\r\n\r\nна всякий случай\r\nhttps://help.ubuntu.com/community/MpichCluster\r\n\r\nh1. увеличение количества тредов и открытых файлов в rhel\r\n\r\nhttp://ithubinfo.blogspot.ru/2013/07/how-to-increase-ulimit-open-file-and.html\r\n2. Step : vi /etc/security/limits.conf  and add below the mentioned\r\n\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\nvi /etc/security/limits.conf  and add below the menstioed\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\nand  vi /etc/security/limits.d/90-nproc.conf\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\n\r\n\r\nh1. GlusterFS\r\n\r\nУстановка\r\nhttp://gluster.org/community/documentation/index.php/Gluster_3.2:_Installing_GlusterFS_on_Red_Hat_Package_Manager_%28RPM%29_Distributions\r\n\r\nРекомендуется версия 3.2\r\n\r\nНастройка\r\nhttp://www.prolinux.org/node/200\r\n\r\nЕсли после удаления тома, не дает создать новы и ругается на то, что brick всё ещё в томе:\r\nhttp://joejulian.name/blog/glusterfs-path-or-a-prefix-of-it-is-already-part-of-a-volume/\r\n\r\nНастроить /etc/fstab не вышло, монтируется автоматически в /common/autofs','','','2014-10-21 14:36:33',1),(8,6,6,3,'h1. Техническое задание\r\n\r\nh1. Техническое задание\r\n\r\n\r\nh2. Для серверов и вычислительных модулей\r\n\r\n# доступность по сети интерфейса серверов *[Знаем]* *[В явном виде не собирается]* \r\n@ping 192.168.4.2@\r\n# доступность оп сети bmc *[Знаем]* *[В явном виде не собирается]* \r\n@ping 192.168.10.5@\r\n# уровни напряжений (уточнить) *[Знаем]* *[получаем]* \r\n@ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep Volts@\r\n# состояние БП *[Знаем]* *[Получаем]*\r\n# температура внутри системного блока *[Знаем]* *[cобирается]* \r\n@ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"TR\"@\r\n# терморежим процессоров и ускорителей *[Знаем]* *[получаем]* \r\n @ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"CPU*. Temp\"@\r\n# скорости вращения внутрикорпусных вентиляторов *[Знаем]* *[получаем]* \r\n  @ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"FAN\"@\r\n# объем доступной оперативной памяти *[Знаем]* *[получаем]* \r\n@snmpget -v 1 -c public 192.168.1.2 .1.3.6.1.4.1.2021.4.6.0@ (INTEGER: 64676796 kB)\r\n@snmpget -v 1 -c public 192.168.1.2 .1.3.6.1.4.1.2021.4.5.0@ (INTEGER: 64676796 kB)\r\n# объем корневой файловой системы *[Знаем]* *[получаем]* \r\n@\r\n.1.3.6.1.2.1.25.2.3.1.4.31 = INTEGER: 4096 Bytes\r\n.1.3.6.1.2.1.25.2.3.1.5.31 = INTEGER: 227469483\r\n.1.3.6.1.2.1.25.2.3.1.6.31 = INTEGER: 818696\r\n.1.3.6.1.2.1.25.2.3.1.3.31 = STRING: /\r\n@\r\n# степень загруженности центральных процессоров *[Знаем]* *[cобирается]* \r\n@\r\n\"ssCpuUser\": \".1.3.6.1.4.1.2021.11.9.0\"\r\n@\r\n# объем сетевого трафика *[Знаем]*  *[получаем]* \r\n@\r\nin  .1.3.6.1.2.1.2.2.1.10.1 = Counter32: 7204416\r\nout 1.3.6.1.2.1.2.2.1.16.1 = Counter32: 7204416\r\n@\r\n# число доступных ускорителей и степень их загруженности [???]\r\n\r\nh2. Для дисковых массивов\r\n\r\n# доступность по сети ping 192.168.4.2 \r\n# температура встроенных датчиков *[знаем]* *[получаем]*\r\n# уровни напряжений с БП *[не знаем]* \r\n# количество и тип установленных физических дисков, их состояние *[не знаем]* \r\n# информация о логических дисках *[не знаем]* \r\n# объем трафика *[не знаем]* \r\n\r\nh2. Для коммутаторов Ethernet\r\n\r\n# состояние коммутатора *[Знаем]* *[не получаем]*\r\n@ping 192.168.4.2@ \r\n# состояние каждого порта *[Знаем]* *[получаем]* \r\n@snmpget -v 2c -c public 192.168.4.2 -On 1.3.6.1.2.1.2.2.1.8.4@\r\n# загрузка каждого порта октет/сек *[Частично знаем]* *[получаем]* \r\n@in .1.3.6.1.2.1.2.2.1.10.* \r\nout .1.3.6.1.2.1.2.2.1.16.*\r\nsnmpget -v 2c -c public 192.168.4.2 -On .1.3.6.1.2.1.2.2.1.10.1\r\nsnmpget -v 2c -c public 192.168.4.2 -On .1.3.6.1.2.1.2.2.1.16.1@\r\n# температура внутри корпуса *[Не знаем]*\r\n# состояние вентиляторов и БП *[Не знаем]* \r\n\r\nh2. для PDU\r\n\r\n# состояние каждой из розеток\r\n# токи потребления\r\n\r\nh2. для ТС мониторинга стоет (RMU)\r\n\r\n# температура и влажность\r\n# состояние дверей стойки','','','2014-10-21 14:42:24',1),(9,6,6,3,'h1. Техническое задание\r\n\r\n\r\nh2. Для серверов и вычислительных модулей\r\n\r\n# доступность по сети интерфейса серверов *[Знаем]* *[В явном виде не собирается]* \r\n@ping 192.168.4.2@\r\n# доступность оп сети bmc *[Знаем]* *[В явном виде не собирается]* \r\n@ping 192.168.10.5@\r\n# уровни напряжений (уточнить) *[Знаем]* *[получаем]* \r\n@ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep Volts@\r\n# состояние БП *[Знаем]* *[Получаем]*\r\n# температура внутри системного блока *[Знаем]* *[cобирается]* \r\n@ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"TR\"@\r\n# терморежим процессоров и ускорителей *[Знаем]* *[получаем]* \r\n @ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"CPU*. Temp\"@\r\n# скорости вращения внутрикорпусных вентиляторов *[Знаем]* *[получаем]* \r\n  @ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"FAN\"@\r\n# объем доступной оперативной памяти *[Знаем]* *[получаем]* \r\n@snmpget -v 1 -c public 192.168.1.2 .1.3.6.1.4.1.2021.4.6.0@ (INTEGER: 64676796 kB)\r\n@snmpget -v 1 -c public 192.168.1.2 .1.3.6.1.4.1.2021.4.5.0@ (INTEGER: 64676796 kB)\r\n# объем корневой файловой системы *[Знаем]* *[получаем]* \r\n@\r\n.1.3.6.1.2.1.25.2.3.1.4.31 = INTEGER: 4096 Bytes\r\n.1.3.6.1.2.1.25.2.3.1.5.31 = INTEGER: 227469483\r\n.1.3.6.1.2.1.25.2.3.1.6.31 = INTEGER: 818696\r\n.1.3.6.1.2.1.25.2.3.1.3.31 = STRING: /\r\n@\r\n# степень загруженности центральных процессоров *[Знаем]* *[cобирается]* \r\n@\r\n\"ssCpuUser\": \".1.3.6.1.4.1.2021.11.9.0\"\r\n@\r\n# объем сетевого трафика *[Знаем]*  *[получаем]* \r\n@\r\nin  .1.3.6.1.2.1.2.2.1.10.1 = Counter32: 7204416\r\nout 1.3.6.1.2.1.2.2.1.16.1 = Counter32: 7204416\r\n@\r\n# число доступных ускорителей и степень их загруженности [???]\r\n\r\nh2. Для дисковых массивов\r\n\r\n# доступность по сети ping 192.168.4.2 \r\n# температура встроенных датчиков *[знаем]* *[получаем]*\r\n# уровни напряжений с БП *[не знаем]* \r\n# количество и тип установленных физических дисков, их состояние *[не знаем]* \r\n# информация о логических дисках *[не знаем]* \r\n# объем трафика *[не знаем]* \r\n\r\nh2. Для коммутаторов Ethernet\r\n\r\n# состояние коммутатора *[Знаем]* *[не получаем]*\r\n@ping 192.168.4.2@ \r\n# состояние каждого порта *[Знаем]* *[получаем]* \r\n@snmpget -v 2c -c public 192.168.4.2 -On 1.3.6.1.2.1.2.2.1.8.4@\r\n# загрузка каждого порта октет/сек *[Частично знаем]* *[получаем]* \r\n@in .1.3.6.1.2.1.2.2.1.10.* \r\nout .1.3.6.1.2.1.2.2.1.16.*\r\nsnmpget -v 2c -c public 192.168.4.2 -On .1.3.6.1.2.1.2.2.1.10.1\r\nsnmpget -v 2c -c public 192.168.4.2 -On .1.3.6.1.2.1.2.2.1.16.1@\r\n# температура внутри корпуса *[Не знаем]*\r\n# состояние вентиляторов и БП *[Не знаем]* \r\n\r\nh2. для PDU\r\n\r\n# состояние каждой из розеток\r\n# токи потребления\r\n\r\nh2. для ТС мониторинга стоет (RMU)\r\n\r\n# температура и влажность\r\n# состояние дверей стойки','','','2014-10-21 14:42:58',2),(10,6,6,3,'h1. Техническое задание\r\n\r\n\r\nh2. Для серверов и вычислительных модулей\r\n\r\n# доступность по сети интерфейса серверов\r\n@ping 192.168.4.2@\r\n# доступность оп сети bmc\r\n@ping 192.168.10.5@\r\n# уровни напряжений\r\n@ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep Volts@\r\n# состояние БП\r\n# температура внутри системного блока\r\n@ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"TR\"@\r\n# терморежим процессоров и ускорителей\r\n @ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"CPU*. Temp\"@\r\n# скорости вращения внутрикорпусных вентиляторов\r\n  @ipmitool -I lan -H 192.168.10.5 -U admin -P admin sensor | grep \"FAN\"@\r\n# объем доступной оперативной памяти\r\n@snmpget -v 1 -c public 192.168.1.2 .1.3.6.1.4.1.2021.4.6.0@ (INTEGER: 64676796 kB)\r\n@snmpget -v 1 -c public 192.168.1.2 .1.3.6.1.4.1.2021.4.5.0@ (INTEGER: 64676796 kB)\r\n# объем корневой файловой системы\r\n@\r\n.1.3.6.1.2.1.25.2.3.1.4.31 = INTEGER: 4096 Bytes\r\n.1.3.6.1.2.1.25.2.3.1.5.31 = INTEGER: 227469483\r\n.1.3.6.1.2.1.25.2.3.1.6.31 = INTEGER: 818696\r\n.1.3.6.1.2.1.25.2.3.1.3.31 = STRING: /\r\n@\r\n# степень загруженности центральных процессоров\r\n@\r\n\"ssCpuUser\": \".1.3.6.1.4.1.2021.11.9.0\"\r\n@\r\n# объем сетевого трафика\r\n@\r\nin  .1.3.6.1.2.1.2.2.1.10.1 = Counter32: 7204416\r\nout 1.3.6.1.2.1.2.2.1.16.1 = Counter32: 7204416\r\n@\r\n# число доступных ускорителей и степень их загруженности\r\n\r\nh2. Для дисковых массивов\r\n\r\n# доступность по сети ping 192.168.4.2 \r\n# температура встроенных датчиков \r\n# уровни напряжений с БП \r\n# количество и тип установленных физических дисков, их состояние \r\n# информация о логических дисках \r\n# объем трафика \r\n\r\nh2. Для коммутаторов Ethernet\r\n\r\n# состояние коммутатора \r\n@ping 192.168.4.2@ \r\n# состояние каждого порта \r\n@snmpget -v 2c -c public 192.168.4.2 -On 1.3.6.1.2.1.2.2.1.8.4@\r\n# загрузка каждого порта октет/сек\r\n@in .1.3.6.1.2.1.2.2.1.10.* \r\nout .1.3.6.1.2.1.2.2.1.16.*\r\nsnmpget -v 2c -c public 192.168.4.2 -On .1.3.6.1.2.1.2.2.1.10.1\r\nsnmpget -v 2c -c public 192.168.4.2 -On .1.3.6.1.2.1.2.2.1.16.1@\r\n# температура внутри корпуса \r\n# состояние вентиляторов и БП\r\n\r\nh2. для PDU\r\n\r\n# состояние каждой из розеток\r\n# токи потребления\r\n\r\nh2. для ТС мониторинга стоет (RMU)\r\n\r\n# температура и влажность\r\n# состояние дверей стойки','','','2014-10-21 14:44:01',3),(11,5,5,3,'h1. Спецификация - Технологии\r\n\r\nh1. SNMP\r\n\r\nпримеры команд os linux:\r\n<pre>\r\nsnmpwalk -Os -c public -v 1 192.168.7.18\r\nsnmpget -v 1 -Cf -c public 192.168.7.18 iso.3.6.1.4.1.534.1.2.4\r\n</pre>\r\n\r\nSNMP работает на прикладном уровне TCP/IP (седьмой уровень модели OSI). Агент SNMP получает запросы по UDP-порту 161. Менеджер может посылать запросы с любого доступного порта источника на порт агента. Ответ агента будет отправлен назад на порт источника на менеджере. Менеджер получает уведомления (Traps и InformRequests) по порту 162. Агент может генерировать уведомления с любого доступного порта. При использовании TLS или DTLS запросы получаются по порту 10161, а ловушки отправляются на порт 10162.\r\n\r\nsnmp v2 - Добавлен bulkrequest и криптозащита, улучшена производительность, несовместим с v1\r\nsnmp v3 - Улучшена криптозащита.\r\n\r\nh2. Зачем нужны коммьюнити (скрипт sudo snmpconf -i -g basic_setup)\r\n\r\nThe community name to add read-only access for: public\r\nThe hostname or network address to accept this community name from [RETURN for all]: \r\nThe OID that this community should be restricted to [RETURN for no-restriction]: \r\n\r\nпо конфигурированию:\r\ninformsink  127.0.0.1 - A host name that should receive the trap\r\n\r\n\"Net-SNMP_and_lm-sensors\":http://www.net-snmp.org/wiki/index.php/Net-SNMP_and_lm-sensors_on_Ubuntu_10.04\r\n\r\nОчень непросто оказывается настраивать snmpd\r\n\r\nh1. Telnet\r\n\r\nHow to change screen size in telnet:\r\nhttp://stackoverflow.com/questions/11575558/is-it-possible-to-send-resize-pty-command-with-telnetlib\r\n\r\nh1. WEB\r\n\r\nh2. WSGI\r\n\r\n1) /etc/apache2/sites-available/default заменить на прикрепленный файл\r\n2) установить libapache2-mod-wsgi-py3\r\n3) export PYTHONPATH=path_to_nms_app\r\n4) база данных генерится командой python3 collector.py -f nms_random_10_09_2013_100_val -g 1 -t 0.1\r\n5) переписать везде абсолютные пути\r\n\r\nh2. Django\r\n\r\n1) Установка Timezone - settings.py TIMEZONE=None, USE_TZ=True\n\nh1. MySQL\r\n\r\nУзнать размер всех баз данных в мегабайтах\r\nSELECT table_schema \"DB Name\", Round(Sum(data_length + index_length) / 1024 / 1024, 1) \"DB Size in MB\"  FROM  information_schema.tables  GROUP  BY table_schema;\r\n\r\nПолный бекап данных:\r\n@\r\nmysqldump -u root -p111111 06_12_db > 06_12_db.sql\r\ntar czf 06_12_db.sql.tgz 06_12_db.sql\r\nscp user@192.168.1.1:/home/user/06_12_db.sql.tgz .\r\ntar xzf 06_12_db.sql.tgz\r\nmysql -u root -p111111\r\ncreate database 06_12_db_new;\r\nmysql -u root -p111111 06_12_db_new < 06_12_db.sql\r\n@\r\nsudo /etc/init.d/mysqld start\r\n\r\nСм. последний дамп базы данных в source:03_04_db.sql.tgz\n\nh1. DHCP\r\n\r\nExample tested on ubuntu\r\n\r\nsudo apt-get install dhcp3-server\r\nsudo vi /etc/default/dhcp3-server\r\nINTERFACES=\"eth0″\r\nsudo vi /etc/dhcp/dhcpd.conf\r\nsubnet 192.168.0.0 netmask 255.255.255.0 {\r\n   range 192.168.0.1 192.168.0.200;\r\n   option routers 127.0.0.1;\r\n}\r\n\r\nhost pdu0 {\r\n   hardware ethernet 00:c0:b7:9b:2c:b4;\r\n   fixed-address 192.168.0.68;\r\n }\r\n\r\nsudo dhcpd\r\n\r\nh1. Other\r\n\r\nPing all devices in a subnet:\r\n\r\nsudo arp-scan --interface=eth0 192.168.0.0/24\r\n\r\nh1. Root on NFS\r\n\r\nhttp://rags.wordpress.com/2012/03/20/using-nfsroot-to-boot-diskless-clients-on-rhel/\r\n\r\nh1. nvidia-smi\r\n\r\n1) add lines from configs/server_snmpd.conf to snmpd.conf\r\n2) run run_nvsmi.sh\r\n3) place parse_nvsmi_xml.py into /root folder\r\n\r\n\r\nh1. intel mpi\r\n\r\n1) make mpd.hosts file in format \r\nhost:number of processes\r\nplace .mpd.conf with secret phrase (see ics tutorial)\r\n\r\nmpirun -r ssh -f ~/mpd.hosts -perhost [number_of_processes_per_jost] -np [total_number_of_processes] [program + parameters]\r\n\r\nmpd.hosts contains lists of hosts in the format:\r\nip(or hostname):max_number_of_processes_for_this_host\r\n\r\nна всякий случай\r\nhttps://help.ubuntu.com/community/MpichCluster\r\n\r\nh1. увеличение количества тредов и открытых файлов в rhel\r\n\r\nhttp://ithubinfo.blogspot.ru/2013/07/how-to-increase-ulimit-open-file-and.html\r\n2. Step : vi /etc/security/limits.conf  and add below the mentioned\r\n\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\nvi /etc/security/limits.conf  and add below the menstioed\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\nand  vi /etc/security/limits.d/90-nproc.conf\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\n\r\n\r\nh1. GlusterFS\r\n\r\nУстановка\r\nhttp://gluster.org/community/documentation/index.php/Gluster_3.2:_Installing_GlusterFS_on_Red_Hat_Package_Manager_%28RPM%29_Distributions\r\n\r\nРекомендуется версия 3.2\r\n\r\nНастройка\r\nhttp://www.prolinux.org/node/200\r\n\r\nЕсли после удаления тома, не дает создать новы и ругается на то, что brick всё ещё в томе:\r\nhttp://joejulian.name/blog/glusterfs-path-or-a-prefix-of-it-is-already-part-of-a-volume/\r\n\r\nНастроить /etc/fstab не вышло, монтируется автоматически в /common/autofs','','','2014-10-21 14:48:04',2),(12,7,7,3,'h1. Загрузка по сети\r\n\r\nКак заставить RHEL 6.4 загружаться по сети.\r\n\r\nh1. Установка системы и компиляция ядра.\r\n\r\nh2. Установка системы\r\n\r\n# Установить rhel на сервер, аналогичный тому, с которого вы будете загружаться.\r\n# в нем должны быть пакеты kernel-xxx.\r\n# sudo /sbin/service iptables stop\r\n\r\nh2. Компиляция ядра\r\n\r\n# устанавливаем *не от root* пакет: rpm -i kernel-2.6.32-358.el6.src.rpm\r\n# cd ~/rpmbuild/SPECS\r\n# rpmbuild -bp --target=$(uname -m) kernel.spec\r\n# cd ~/rpmbuild/BUILD?\r\n# скомпилируйте ядро\r\nдолжны быть включены\r\n@\r\nCONFIG_E1000=y\r\nCONFIG_IP_PNP=y \r\nCONFIG_IP_PNP_DHCP=y\r\nCONFIG_NFS_FS=y\r\nCONFIG_ROOT_NFS=y\r\n@\r\n# Компиляция\r\n@\r\nmake clean\r\nmake oldconfig\r\nmake menuconfig\r\nmake -j32 bzImage\r\nmake -j32 modules\r\nmake modules_install # /lib/modules/<KERNELVERSION>/kernel/drivers\r\nmake install # /boot\r\n@\r\n# cp /boot/YOUKERNEL /var/lib/tftpboot/images/rhel_6/\r\n\r\nh2. Создание образа initrd через dracut\r\n\r\n# dracut -f -v --modules \'nfs dash network ifcfg plymouth multipath  debug fstab-sys nfs  resume znet  insmodpost  syslog  kdumpbase kernel-modules base fs-lib img-lib shutdown\' /root/netboot6.img `uname -r` root=192.168.1.1:/var/nfs/server01 ip=eth0:on ip=192.168.30.1:192.168.1.1:255.255.0.0:bussol:eth0: rdinfo rdshell rdinitdebug rdbreak rdudevinfon\r\n# cp /root/netboot6.img /var/lib/tftpboot/images/rhel_6/netboot6.img\r\n\r\nh2. Tftp\r\n\r\nh3. Redhat\r\n\r\nкраткий ман: http://lonesysadmin.net/2007/10/29/how-to-install-a-tftp-server-on-red-hat-enterprise-linux/\r\nпакеты: \r\nlibwrap0-7.6-882.5.i586.rpm\r\ntftp-server-0.32-4.i386.rpm\r\n\r\nsudo vim /etc/xinetd.d/tftp\r\nservice tftp\r\n{\r\n        disable = no\r\n        socket_type             = dgram\r\n        protocol                = udp\r\n        wait                    = yes\r\n        user                    = root\r\n        server                  = /usr/sbin/in.tftpd\r\n        server_args             = -s /var/lib/tftpboot\r\n        per_source              = 11\r\n        cps                     = 100 2\r\n        flags                   = IPv4\r\n}\r\n\r\nsudo chkconfig tftp on\r\nsudo service xinetd reload\r\n\r\nh3. Ubuntu\r\n\r\n# ман https://linuxlink.timesys.com/docs/linux_tftp\r\n\r\ncreate\r\n# /etc/default/tftpd-hpa\r\n@\r\nTFTP_USERNAME=\"tftp\" \r\nTFTP_DIRECTORY=\"/tftpboot\" \r\nTFTP_ADDRESS=\"0.0.0.0:69\" \r\nTFTP_OPTIONS=\"--secure\r\n@\r\n# sudo /sbin/service xinetd restart\r\n\r\ndhcp v2\r\n\r\nh2. NFS\r\n\r\n# rsync -avP --numeric-ids --exclude=\'/dev\' --exclude=\'/proc\' --exclude=\'/sys\' root@192.168.30.1:/ /var/nfs/server01/\r\n# mkdir /var/nfs/server01/tmp/\r\n# mkdir /var/nfs/server01/sys/\r\n# mkdir /var/nfs/server01/dev/\r\n# mkdir /var/nfs/server01/proc/\r\n#/etc/exports\r\n@\r\n/var/nfs/server01 *(rw,async,no_root_squash)\r\n@\r\n# sudo service nfs restart\r\n# sudo exportfs -a\r\n\r\nh2. DHCP\r\n\r\n# /etc/dhcpd.conf\r\n@\r\nallow booting;\r\nallow bootp;\r\nsubnet 192.168.0.0 netmask 255.255.0.0 {\r\n	range 192.168.50.1 192.168.50.100;\r\n	filename \"pxelinux.0\";\r\n	#option root-path \"192.168.1.1:/var/nfs/server01,rw,nolock\";\r\n}\r\nhost pdu0{\r\n	hardware ethernet 00:c0:b7:9b:2c:b4;\r\n	fixed-address 192.168.0.68;\r\n	option routers 127.0.0.1;\r\n}\r\nhost hp_1910{\r\n        hardware ethernet d0:7e:28:1d:96:3f;\r\n        fixed-address 192.168.7.1;\r\n        option routers 127.0.0.1;\r\n}\r\nhost gpu_serv01{\r\n	hardware ethernet 00:e0:81:e4:83:e2;\r\n	#option root-path \"192.168.1.1:/var/nfs/server01,rw,nolock\";\r\n	fixed-address 192.168.30.1;\r\n	option routers 127.0.0.1;\r\n}\r\n@\r\n# sudo service dhcpd restart\r\n\r\nh2. PXE config\r\n\r\n# /tftpboot/pxelinux.cfg/default\r\n@\r\ndefault menu.c32\r\nprompt 0\r\nmenu title Bussol complex boot menu\r\nMENU AUTOBOOT Starting Local System in # seconds\r\nlabel local\r\n    menu label rhel6-local\r\n    kernel images/rhel_6/vmlinuz-2.6.32_nfs_custom root=UUID=3a30c143-8229-48b2-8d10-bdcf567f644a\r\n    append initrd=images/rhel_6/initramfs-2.6.32_nfs_custom.img rdshell vga=773\r\nlabel rhel6_nfs\r\n    menu label rhel6 with nfs\r\n    menu default\r\n    timeout 100\r\n    kernel images/rhel_6/vmlinuz-2.6.32_nfs_custom\r\n    append root=/dev/nfs nfsroot=192.168.1.1:/var/nfs/server01,vers=3,nolock,nfsvers=3 ip=dhcp rw nfsrootdebug initrd=images/rhel_6/netboot6.img lang=us keymap=us noipv6 rdshell vga=773\r\n@\r\n\r\nh1. enjoy!\r\n!https://hostedredmine.s3.amazonaws.com/131220230518_download.jpg?AWSAccessKeyId=AKIAJLVUOXB2KSUPTRFQ&Expires=1387543201&Signature=k7XmTfHOvIT6oQZONx%2BHihTG1HA%3D!\r\n\r\nh1. TFTP UBUNTU\r\n\r\n\r\nhttp://thestorey.ca/wordpress/?p=26\r\n\r\nhttp://www.cyberciti.biz/faq/install-configure-tftp-server-ubuntu-debian-howto/','','','2014-10-21 14:50:30',1),(13,4,4,3,'h1. Спецификация - Оборудование\r\n\r\nh2. hp-5800\r\n\r\ninitial setup:\r\nplug console cable in special SVK notebook and run putty:\r\nsystem-view\r\nvlan 10\r\ndescription Test VLAN\r\nprotocol-vlan 0 ipv4\r\nip-subnet-vlan 0 ip 192.168.0.0 255.255.0.0\r\n\r\ninterface Vlan-interface10\r\nip address 192.168.7.2 255.255.0.0\r\n\r\ninterface GigabitEthernet1/0/1\r\nport access vlan 10\r\n\r\n[Sysname] local-user admin\r\n[Sysname-luser-admin] service-type telnet\r\n[Sysname-luser-admin] authorization-attribute level 3\r\n[Sysname-luser-admin] password simple admin\r\n\r\nsave\r\n\r\n[end]\r\n\r\n\r\nip: 192.168.7.2 (port 1 only!)\r\nusername: admin\r\npassword: 111111\r\n\r\nreference:\r\nhttp://ixnfo.com/nastroyka-hp-5800.html\r\n\r\nh2. hp-1910-8g\r\n\r\ndefault ip: 169.254.150.62\r\ndon\'t forget your ip: 169.254.150.62/16\r\nhttp://www.petenetlive.com/KB/Article/0000495.htm\r\nDefault access is user name admin with a blank password.\r\n\r\ncurrent ip: 192.168.7.1\r\n\r\nh2. PDU\r\n\r\nip 192.168.20.1\r\nip 192.168.20.2\r\nip 192.168.20.3\r\nip 192.168.20.4\r\n\r\nAPC 8981\r\n\r\nlogin: apc\r\npass: apc\r\n\r\nMIB - смотри приложение, rPDU.\r\n\r\nOverload Alarm: 	kW 16.0\r\nNear Overload Warning: 	kW 8.8\r\nLow Load Warning: 	kW 0.0\r\n\r\nh2. UPS\r\n\r\n*powerware 9130 3kva*\r\n\r\nip интерфейса станции 192.168.0.1\r\nip интерфейса UPS 192.168.7.18\r\n\r\nmib - http://support.ipmonitor.com/mibs/XUPS-MIB/raw.aspx\r\n\r\nSNMP параметры\r\nprivate iso.3.6.1.4.1.534 \r\n# \"Battery run time in seconds before UPS turns off due to low battery\" : \"1.2.1\",\r\n# \"Battery percent charge\" : \"1.2.4\"\r\n\r\nh2. RAID\r\n\r\ndothill 3730\r\nweb login: manage\r\nweb password: !manage\r\nPower 436W\r\n\r\n|_. Raid |_. Serial Number |_. FileServer01 |_. FileServer02 |\r\n| Raid01 | a2a | sdc | sdb |\r\n| Raid01 | a52 | sdb | sde |\n\nh2. KVM\r\n\r\n192.168.0.60 \r\n\r\nlogin: administrator\r\npass: password\r\n\r\n6EA0D-L0X7B-SCJE0-06272\r\n\r\nДжава-приложение для использования нашего kvm: attachment:JavaClient.jar\n\nh2. остальные сервера\r\n\r\nuser - 111111\r\nroot - 111111\r\n\r\nh2. Как разметить Raid на 20Тб\r\nparted /dev/sdb\r\n>mklabel\r\n>gpt\r\n\r\ngit clone git://git.kernel.org/pub/scm/fs/ext2/e2fsprogs.git\r\ncd e2fsprogs\r\nmkdir build ; cd build/\r\n../configure\r\nmake\r\nmake install\r\n./mke2fs -O 64bit,has_journal,extents,huge_file,flex_bg, uninit_bg,dir_nlink,extra_isize -i 4194304 /dev/sdb\r\n\r\n\r\nh2. NetBootz 200\r\n\r\narp -s 192.168.11.2 00:c0:b7:9b:91:c0\r\nping 192.168.11.2 -s 113\r\n\r\nhttp://www.apc.com/products/resource/include/techspec_index.cfm?base_sku=NBRK0201\r\n\r\nhttp://www.irrexpr.com/2012/06/accessing-snmp-temperature-information.html\r\n\r\nlogin apc\r\npassw apc\r\n\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.3.0.1  - Sensor Name\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.4.0.1  - Sensor Location\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.5.0.1  - Temperature\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.6.0.1  - Humid\r\n\r\n\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.1.0.2 = INTEGER: 0\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.2.0.2 = INTEGER: 2\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.3.0.2 = STRING: \"Sensor MM:2\"\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.4.0.2 = STRING: \"Unknown\"\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.5.0.2 = INTEGER: 1 -> 2 при open\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.7.0.2 = INTEGER: 2 -> 1 при open\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.8.0.2 = INTEGER: 2 -\r\n\r\nh2. Расчётные серверы\r\n\r\n1) 192.168.10.11 - BMC','','','2014-10-21 14:52:07',2),(14,1,1,3,'h1. Wiki\r\n\r\n[[План тестирования]]\r\n\r\n[[План рефакторинга]]\r\n\r\n[[Спецификация - Оборудование]]\r\n\r\n[[Спецификация - Технологии]]\r\n\r\nh2. [[Техническое задание]]\r\n\r\nh2. [[Загрузка по сети]]','','','2014-10-21 14:54:40',3),(15,1,1,3,'h1. Wiki\r\n\r\n[[План тестирования]]\r\n\r\n[[План рефакторинга]]\r\n\r\n[[Спецификация - Оборудование]]\r\n\r\n[[Спецификация - Технологии]]\r\n\r\nh2. [[Техническое задание]]\r\n\r\nh2. [[Загрузка по сети]]\r\n\r\nh2. [[Установка системы на Ubuntu]]\r\n','','','2014-10-21 15:06:03',4),(16,8,8,3,'h1. Установка системы на Ubuntu\r\n\r\n# sudo apt-get install git\r\n# git clone https://dkhodakov@bitbucket.org/orionservermonitoring/bussol.git\r\n# git fetch && git checkout server\r\n# sudo apt-get install python3-pip\r\n# sudo pip3 install nose\r\n# PYTHONPATH=/home/dimert/NMS/nms_app; export PYTHONPATH\r\n# cd ~/NMS/nms_app; cp server_local_settings.py local_settings.py\r\n# edit local settings, change username in paths\r\n# sudo mkdir /var/log/nms; sudo chmod a+rwx /var/log/nms\r\n# sudo pip3 install -I django==1.5.1\r\n# sudo apt-get install mysql-server mysql-client (pass 111111)\r\n# sudo pip3 install pymysql\r\n# sudo apt-get install ipmitool snmp snmpd\r\n# edit /etc/snmp/snmpd : view systemonly included .1\r\n# nosetests -v --processes=25 --process-timeout=300 --process-restartworker\r\n# sudo apt-get install apache2 libapache2-mod-wsgi-py3\r\n# cp 000-default to sites-available with changed username\r\n# sudo a2enmod wsgi\r\n# sudo apt-get install apache2-dev\r\n# sudo chmod a+rwx /home/dimert/\r\n# cd ~/; mkdir build; cd build/; wget https://github.com/GrahamDumpleton/mod_wsgi/archive/4.2.8.tar.gz; tar xzf 4.2.8.tar.gz; cd mod_wsgi-4.2.8/; ./configure -with-python=`which python3`; make; sudo make install; sudo service apache2 restart\r\n# sudo chmod a+rw /var/log/nms/*.log\r\n# cd database_backup/\r\n# tar xzf 03_04_db.sql.tgz\r\n# mysql -u root -p111111 -e \'Create database 03_04_db;\'\r\n# mysql -u root -p111111 03_04_db < 03_04_db.sql\r\n# rm database_backup/03_04_db.sql\r\n# sudo service apache2 restart','','','2014-10-21 15:06:19',1),(17,1,1,3,'h1. [[Спецификация - Оборудование]]\r\n\r\nh1. [[Спецификация - Технологии]]\r\n\r\nh1. [[Техническое задание]]\r\n\r\nh1. [[Загрузка по сети]]\r\n\r\nh1. [[Установка системы на Ubuntu]]\r\n\r\n\r\n[[План тестирования]]\r\n\r\n[[План рефакторинга]]','','','2014-10-21 15:07:37',5),(18,7,7,3,'h1. Загрузка по сети\r\n\r\nКак заставить RHEL 6.4 загружаться по сети.\r\n\r\nh1. Установка системы и компиляция ядра.\r\n\r\nh2. Установка системы\r\n\r\n# Установить rhel на сервер, аналогичный тому, с которого вы будете загружаться.\r\n# в нем должны быть пакеты kernel-xxx.\r\n# sudo /sbin/service iptables stop\r\n\r\nh2. Компиляция ядра\r\n\r\n# устанавливаем *не от root* пакет: rpm -i kernel-2.6.32-358.el6.src.rpm\r\n# cd ~/rpmbuild/SPECS\r\n# rpmbuild -bp --target=$(uname -m) kernel.spec\r\n# cd ~/rpmbuild/BUILD?\r\n# скомпилируйте ядро\r\nдолжны быть включены\r\n@\r\nCONFIG_E1000=y\r\nCONFIG_IP_PNP=y \r\nCONFIG_IP_PNP_DHCP=y\r\nCONFIG_NFS_FS=y\r\nCONFIG_ROOT_NFS=y\r\n@\r\n# Компиляция\r\n@\r\nmake clean\r\nmake oldconfig\r\nmake menuconfig\r\nmake -j32 bzImage\r\nmake -j32 modules\r\nmake modules_install # /lib/modules/<KERNELVERSION>/kernel/drivers\r\nmake install # /boot\r\n@\r\n# cp /boot/YOUKERNEL /var/lib/tftpboot/images/rhel_6/\r\n\r\nh2. Создание образа initrd через dracut\r\n\r\n# dracut -f -v --modules \'nfs dash network ifcfg plymouth multipath  debug fstab-sys nfs  resume znet  insmodpost  syslog  kdumpbase kernel-modules base fs-lib img-lib shutdown\' /root/netboot6.img `uname -r` root=192.168.1.1:/var/nfs/server01 ip=eth0:on ip=192.168.30.1:192.168.1.1:255.255.0.0:bussol:eth0: rdinfo rdshell rdinitdebug rdbreak rdudevinfon\r\n# cp /root/netboot6.img /var/lib/tftpboot/images/rhel_6/netboot6.img\r\n\r\nh2. Tftp\r\n\r\nh3. Redhat\r\n\r\nкраткий ман: http://lonesysadmin.net/2007/10/29/how-to-install-a-tftp-server-on-red-hat-enterprise-linux/\r\nпакеты: \r\nlibwrap0-7.6-882.5.i586.rpm\r\ntftp-server-0.32-4.i386.rpm\r\n\r\nsudo vim /etc/xinetd.d/tftp\r\nservice tftp\r\n{\r\n        disable = no\r\n        socket_type             = dgram\r\n        protocol                = udp\r\n        wait                    = yes\r\n        user                    = root\r\n        server                  = /usr/sbin/in.tftpd\r\n        server_args             = -s /var/lib/tftpboot\r\n        per_source              = 11\r\n        cps                     = 100 2\r\n        flags                   = IPv4\r\n}\r\n\r\nsudo chkconfig tftp on\r\nsudo service xinetd reload\r\n\r\nh3. Ubuntu\r\n\r\n# ман https://linuxlink.timesys.com/docs/linux_tftp\r\n\r\ncreate\r\n# /etc/default/tftpd-hpa\r\n@\r\nTFTP_USERNAME=\"tftp\" \r\nTFTP_DIRECTORY=\"/tftpboot\" \r\nTFTP_ADDRESS=\"0.0.0.0:69\" \r\nTFTP_OPTIONS=\"--secure\r\n@\r\n# sudo /sbin/service xinetd restart\r\n\r\ndhcp v2\r\n\r\nh2. NFS\r\n\r\n# rsync -avP --numeric-ids --exclude=\'/dev\' --exclude=\'/proc\' --exclude=\'/sys\' root@192.168.30.1:/ /var/nfs/server01/\r\n# mkdir /var/nfs/server01/tmp/\r\n# mkdir /var/nfs/server01/sys/\r\n# mkdir /var/nfs/server01/dev/\r\n# mkdir /var/nfs/server01/proc/\r\n#/etc/exports\r\n@\r\n/var/nfs/server01 *(rw,async,no_root_squash)\r\n@\r\n# sudo service nfs restart\r\n# sudo exportfs -a\r\n\r\nh2. DHCP\r\n\r\n# /etc/dhcpd.conf\r\n@\r\nallow booting;\r\nallow bootp;\r\nsubnet 192.168.0.0 netmask 255.255.0.0 {\r\n	range 192.168.50.1 192.168.50.100;\r\n	filename \"pxelinux.0\";\r\n	#option root-path \"192.168.1.1:/var/nfs/server01,rw,nolock\";\r\n}\r\nhost pdu0{\r\n	hardware ethernet 00:c0:b7:9b:2c:b4;\r\n	fixed-address 192.168.0.68;\r\n	option routers 127.0.0.1;\r\n}\r\nhost hp_1910{\r\n        hardware ethernet d0:7e:28:1d:96:3f;\r\n        fixed-address 192.168.7.1;\r\n        option routers 127.0.0.1;\r\n}\r\nhost gpu_serv01{\r\n	hardware ethernet 00:e0:81:e4:83:e2;\r\n	#option root-path \"192.168.1.1:/var/nfs/server01,rw,nolock\";\r\n	fixed-address 192.168.30.1;\r\n	option routers 127.0.0.1;\r\n}\r\n@\r\n# sudo service dhcpd restart\r\n\r\nh2. PXE config\r\n\r\n# /tftpboot/pxelinux.cfg/default\r\n@\r\ndefault menu.c32\r\nprompt 0\r\nmenu title Bussol complex boot menu\r\nMENU AUTOBOOT Starting Local System in # seconds\r\nlabel local\r\n    menu label rhel6-local\r\n    kernel images/rhel_6/vmlinuz-2.6.32_nfs_custom root=UUID=3a30c143-8229-48b2-8d10-bdcf567f644a\r\n    append initrd=images/rhel_6/initramfs-2.6.32_nfs_custom.img rdshell vga=773\r\nlabel rhel6_nfs\r\n    menu label rhel6 with nfs\r\n    menu default\r\n    timeout 100\r\n    kernel images/rhel_6/vmlinuz-2.6.32_nfs_custom\r\n    append root=/dev/nfs nfsroot=192.168.1.1:/var/nfs/server01,vers=3,nolock,nfsvers=3 ip=dhcp rw nfsrootdebug initrd=images/rhel_6/netboot6.img lang=us keymap=us noipv6 rdshell vga=773\r\n@\r\n\r\nh1. enjoy!\r\n!https://hostedredmine.s3.amazonaws.com/131220230518_download.jpg?AWSAccessKeyId=AKIAJLVUOXB2KSUPTRFQ&Expires=1387543201&Signature=k7XmTfHOvIT6oQZONx%2BHihTG1HA%3D!\r\n\r\nh1. TFTP UBUNTU\r\n\r\n\r\nhttp://thestorey.ca/wordpress/?p=26\r\n\r\nhttp://www.cyberciti.biz/faq/install-configure-tftp-server-ubuntu-debian-howto\r\n\r\nh1. Установочные пакеты\r\n\r\nattachment:libwrap0-7.6-882.5.i586.rpm \r\nattachment:tftp-server-0.32-4.i386.rpm ','','','2014-10-21 15:09:31',2),(19,1,1,3,'h1. [[Спецификация - Оборудование]]\r\n\r\nh1. [[Спецификация - Технологии]]\r\n\r\nh1. [[Техническое задание]]\r\n\r\nh1. [[Загрузка по сети]]\r\n\r\nh1. [[Установка системы на Ubuntu]]\r\n\r\nh2. [[Артем]]\r\n\r\n[[План тестирования]]\r\n\r\n[[План рефакторинга]]','','','2014-11-24 11:06:06',6),(20,9,9,3,'h1. Артем\r\n\r\nh2. Обучение:\r\n\r\nh2. Неделя 17-24:\r\n\r\n# Погружение в питон, несколько глав\r\n# Скрипт 1 - \r\n# Начало гит, pep8, pycharm\r\n\r\nh2. неделя 24-30:\r\n\r\n# Скрипт 2 - simple_monitoring\r\n\r\n\r\nВсе что нужно\r\n# Git\r\n# Ревью\r\n# python\r\n','','','2014-11-24 11:32:41',1),(21,9,9,3,'h1. Артем\r\n\r\nh2. Обучение:\r\n\r\nh2. Неделя 17-24:\r\n\r\n# Погружение в питон, несколько глав\r\n# Скрипт 1 - \r\n# Начало гит, pep8, pycharm\r\n\r\nh2. неделя 24-30:\r\n\r\n# Скрипт 2 - simple_monitoring (вторник - уже готова сеть и пересылаются данные, рефакторинг)\r\n# артему - конверсия (1, 3, 6, 1, 4, 1, 2021, 11, 9, 0)) в строчку (готово через час)\r\n\r\nВсе что нужно\r\n# Git\r\n# Ревью\r\n# python\r\n','','','2014-11-26 08:21:01',2),(22,1,1,3,'h1. [[Спецификация - Оборудование]]\r\n\r\nh1. [[Спецификация - Технологии]]\r\n\r\nh1. [[Техническое задание]]\r\n\r\nh1. [[Загрузка по сети]]\r\n\r\nh1. [[Установка системы на Ubuntu]]\r\n\r\nh2. [[Артем]]\r\n\r\nh2. [[Установка snmp-agent на win2014]]\r\n\r\n[[План тестирования]]\r\n\r\n[[План рефакторинга]]','','','2014-11-26 11:50:56',7),(23,10,10,3,'h1. Установка snmp-agent на win2014\r\n\r\n1. распаковать Python34.zip в C:\\\\Python34\r\n2. ','','','2014-11-26 11:51:52',1),(24,10,10,3,'h1. Установка snmp-agent на win2014\r\n\r\n1. распаковать Python34.zip в C:\\Python34\r\n2. переместить памку nms_snmp_agent в C:\\\r\n2. использовать nssm.exe чтобы создать сервис. C:\\Python34\\python.exe C:\\nms_snmp_agent\\nms_snmp_agent.py','','','2014-11-27 09:11:48',2),(25,1,1,3,'h1. [[Спецификация - Оборудование]]\r\n\r\nh1. [[Спецификация - Технологии]]\r\n\r\nh1. [[Техническое задание]]\r\n\r\nh1. [[Загрузка по сети]]\r\n\r\nh1. [[Установка системы на Ubuntu]]\r\n\r\nh2. [[Артем]]\r\n\r\nh2. [[Установка snmp-agent на win2014]]\r\n\r\nh1. [[GPU install]]\r\n\r\n[[План тестирования]]\r\n\r\n[[План рефакторинга]]','','','2014-11-27 11:52:40',8),(26,11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop','','','2014-11-27 11:52:44',1),(27,11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop\r\n\r\nhttp://support.amd.com/en-us/kb-articles/Pages/AMDSystemMonitor.aspx','','','2014-11-27 11:54:37',2),(28,11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop\r\n\r\nhttp://support.amd.com/en-us/kb-articles/Pages/AMDSystemMonitor.aspx\r\n\r\nshow cards:\r\nsudo aticonfig --lsa\r\nshow data:\r\ntemp\r\nDISPLAY=:0 sudo aticonfig --odgt --adapter=all\r\nload\r\nDISPLAY=:0 sudo aticonfig --odgc --adapter=all\r\n\r\nнастройка:\r\nexport DISPLAY=:0\r\naticonfig --initial --adapter=all\r\n\r\n\r\nПодготовка к запуску:\r\ninstall 14.301.1010-linux-firepro-retail.zip\r\ninstall AMD-APP-SDK-linux-v2.9-1.599.381-GA-x64.tar.bz2\r\n# export COMPUTE=:0\r\n# export DISPLAY=:0\r\n# xhost +local:\r\ncopy gpu_benchmark','','','2015-01-12 10:27:05',3),(29,9,9,3,'h1. Артем\r\n\r\nh2. Обучение:\r\n\r\nh2. Неделя 17-24:\r\n\r\n# Погружение в питон, несколько глав\r\n# Скрипт 1 - \r\n# Начало гит, pep8, pycharm\r\n\r\nh2. неделя 24-30:\r\n\r\n# Скрипт 2 - simple_monitoring (вторник - уже готова сеть и пересылаются данные, рефакторинг)\r\n# артему - конверсия (1, 3, 6, 1, 4, 1, 2021, 11, 9, 0)) в строчку (готово через час)\r\n\r\nh2. декабрь\r\n\r\n# Рефакторинг database - хорошо справляется\r\n\r\nВсе что нужно\r\n# Git\r\n# Ревью\r\n# python\r\n','','','2015-01-12 10:49:08',3),(30,9,9,3,'h1. Артем\r\n\r\nh2. Обучение:\r\n\r\nh2. Неделя 17-24:\r\n\r\n# Погружение в питон, несколько глав\r\n# Скрипт 1 - \r\n# Начало гит, pep8, pycharm\r\n\r\nh2. неделя 24-30:\r\n\r\n# Скрипт 2 - simple_monitoring (вторник - уже готова сеть и пересылаются данные, рефакторинг)\r\n# артему - конверсия (1, 3, 6, 1, 4, 1, 2021, 11, 9, 0)) в строчку (готово через час)\r\n\r\nh2. декабрь 2014\r\n\r\n# Рефакторинг database - хорошо справляется\r\n\r\nh2. январь 2015\r\n\r\n# Рефакторинг database продолжаем\r\n# Рефакторинг \r\n\r\nВсе что нужно\r\n# Git\r\n# Ревью\r\n# python\r\n','','','2015-01-12 11:00:23',4),(31,9,9,3,'h1. Артем\r\n\r\nh2. Неделя 17-24:\r\n\r\n# Погружение в питон, несколько глав\r\n# Скрипт 1 - \r\n# Начало гит, pep8, pycharm\r\n\r\nh2. неделя 24-30:\r\n\r\n# Скрипт 2 - simple_monitoring (вторник - уже готова сеть и пересылаются данные, рефакторинг)\r\n# артему - конверсия (1, 3, 6, 1, 4, 1, 2021, 11, 9, 0)) в строчку (готово через час)\r\n\r\nh2. декабрь 2014\r\n\r\n# Рефакторинг database - хорошо справляется\r\n\r\nh2. январь 2015\r\n\r\n# Рефакторинг database продолжаем #141\r\n\r\n','','','2015-01-12 11:09:55',5),(32,6,6,3,'h1. Техническое задание\r\n\r\n\r\nh2. Для серверов и вычислительных модулей\r\n\r\n# доступность по сети интерфейса серверов *+*\r\n# доступность оп сети bmc *+*\r\n# уровни напряжений *+*\r\n# состояние БП *+* \r\n# температура внутри системного блока *+*\r\n# терморежим процессоров и ускорителей *+*\r\n# скорости вращения внутрикорпусных вентиляторов *+*\r\n# объем доступной оперативной памяти *+*\r\n# объем корневой файловой системы *+*\r\n# степень загруженности центральных процессоров *+*\r\n# объем сетевого трафика *+*\r\n# число доступных ускорителей и степень их загруженности *+*\r\n\r\nh2. Для дисковых массивов\r\n\r\n# доступность по сети *+*\r\n# температура встроенных датчиков *+*\r\n# уровни напряжений с БП *-*\r\n# количество и тип установленных физических дисков, их состояние -\r\n# информация о логических дисках -\r\n# объем трафика -\r\n\r\nh2. Для коммутаторов Ethernet\r\n\r\n# состояние коммутатора *+*\r\n# состояние каждого порта *+*\r\n# загрузка каждого порта октет/сек *+*\r\n# температура внутри корпуса -\r\n# состояние вентиляторов и БП -\r\n\r\nh2. для PDU\r\n\r\n# состояние каждой из розеток *+*\r\n# токи потребления *+*\r\n\r\nh2. для ТС мониторинга стоек (RMU)\r\n\r\n# температура и влажность *+*\r\n# состояние дверей стойки *+*','','','2015-01-12 11:13:46',4),(33,6,6,3,'h1. Техническое задание\r\n\r\n\r\nh2. Для серверов и вычислительных модулей\r\n\r\n# доступность по сети интерфейса серверов * + *\r\n# доступность оп сети bmc *+*\r\n# уровни напряжений *+*\r\n# состояние БП *+* \r\n# температура внутри системного блока *+*\r\n# терморежим процессоров и ускорителей *+*\r\n# скорости вращения внутрикорпусных вентиляторов *+*\r\n# объем доступной оперативной памяти *+*\r\n# объем корневой файловой системы *+*\r\n# степень загруженности центральных процессоров *+*\r\n# объем сетевого трафика *+*\r\n# число доступных ускорителей и степень их загруженности *+*\r\n\r\nh2. Для дисковых массивов\r\n\r\n# доступность по сети *+*\r\n# температура встроенных датчиков *+*\r\n# уровни напряжений с БП *-*\r\n# количество и тип установленных физических дисков, их состояние -\r\n# информация о логических дисках -\r\n# объем трафика -\r\n\r\nh2. Для коммутаторов Ethernet\r\n\r\n# состояние коммутатора *+*\r\n# состояние каждого порта *+*\r\n# загрузка каждого порта октет/сек *+*\r\n# температура внутри корпуса -\r\n# состояние вентиляторов и БП -\r\n\r\nh2. для PDU\r\n\r\n# состояние каждой из розеток *+*\r\n# токи потребления *+*\r\n\r\nh2. для ТС мониторинга стоек (RMU)\r\n\r\n# температура и влажность *+*\r\n# состояние дверей стойки *+*','','','2015-01-12 11:13:52',5),(34,6,6,3,'h1. Техническое задание\r\n\r\n\r\nh2. Для серверов и вычислительных модулей\r\n\r\n\r\n# -доступность по сети интерфейса серверов-\r\n# -доступность оп сети bmc-\r\n# -уровни напряжений-\r\n# -состояние БП-\r\n# -температура внутри системного блока-\r\n# -терморежим процессоров и ускорителей-\r\n# -скорости вращения внутрикорпусных вентиляторов-\r\n# -объем доступной оперативной памяти-\r\n# -объем корневой файловой системы-\r\n# -степень загруженности центральных процессоров-\r\n# -объем сетевого трафика-\r\n# -число доступных ускорителей и степень их загруженности-\r\n\r\nh2. Для дисковых массивов\r\n\r\n# доступность по сети *+*\r\n# температура встроенных датчиков *+*\r\n# уровни напряжений с БП *-*\r\n# количество и тип установленных физических дисков, их состояние -\r\n# информация о логических дисках -\r\n# объем трафика -\r\n\r\nh2. Для коммутаторов Ethernet\r\n\r\n# состояние коммутатора *+*\r\n# состояние каждого порта *+*\r\n# загрузка каждого порта октет/сек *+*\r\n# температура внутри корпуса -\r\n# состояние вентиляторов и БП -\r\n\r\nh2. для PDU\r\n\r\n# состояние каждой из розеток *+*\r\n# токи потребления *+*\r\n\r\nh2. для ТС мониторинга стоек (RMU)\r\n\r\n# температура и влажность *+*\r\n# состояние дверей стойки *+*','','','2015-01-12 11:16:07',6),(35,6,6,3,'h1. Техническое задание\r\n\r\n\r\nh2. Для серверов и вычислительных модулей\r\n\r\n\r\n# -доступность по сети интерфейса серверов-\r\n# -доступность оп сети bmc-\r\n# -уровни напряжений-\r\n# -состояние БП-\r\n# -температура внутри системного блока-\r\n# -терморежим процессоров и ускорителей-\r\n# -скорости вращения внутрикорпусных вентиляторов-\r\n# -объем доступной оперативной памяти-\r\n# -объем корневой файловой системы-\r\n# -степень загруженности центральных процессоров-\r\n# -объем сетевого трафика-\r\n# -число доступных ускорителей и степень их загруженности-\r\n\r\nh2. Для дисковых массивов\r\n\r\n# доступность по сети *+*\r\n# температура встроенных датчиков *+*\r\n# *уровни напряжений с БП* *-*\r\n# *количество и тип установленных физических дисков, их состояние* -\r\n# *информация о логических дисках* -\r\n# *объем трафика* -\r\n\r\nh2. Для коммутаторов Ethernet\r\n\r\n# состояние коммутатора *+*\r\n# состояние каждого порта *+*\r\n# загрузка каждого порта октет/сек *+*\r\n# *температура внутри корпуса* -\r\n# *состояние вентиляторов и БП* -\r\n\r\nh2. для PDU\r\n\r\n# состояние каждой из розеток *+*\r\n# токи потребления *+*\r\n\r\nh2. для ТС мониторинга стоек (RMU)\r\n\r\n# температура и влажность *+*\r\n# состояние дверей стойки *+*','','','2015-01-12 11:16:49',7),(36,1,1,3,'h1. Справка по системе\r\n\r\nh2. [[Спецификация - Оборудование]]\r\n\r\nh2. [[Спецификация - Технологии]]\r\n\r\nh2. [[Техническое задание]]\r\n\r\nh1. Руководства\r\n\r\nh2. [[Загрузка по сети]]\r\n\r\nh2. [[Установка системы на Ubuntu]]\r\n\r\nh2. [[Установка snmp-agent на win2014]]\r\n\r\nh2. [[GPU install]]\r\n\r\nh1. Планы\r\n\r\nh2. [[Артем]]\r\n','','','2015-01-12 11:19:21',9),(37,5,5,3,'h1. Спецификация - Технологии\r\n\r\nh1. IPMI\r\n\r\n@ipmitool -I lan -H 10.0.0.55 -U root -P superuser sensor@\r\n\r\nh1. SNMP\r\n\r\nпримеры команд os linux:\r\n<pre>\r\nsnmpwalk -Os -c public -v 1 192.168.7.18\r\nsnmpget -v 1 -Cf -c public 192.168.7.18 iso.3.6.1.4.1.534.1.2.4\r\n</pre>\r\n\r\nSNMP работает на прикладном уровне TCP/IP (седьмой уровень модели OSI). Агент SNMP получает запросы по UDP-порту 161. Менеджер может посылать запросы с любого доступного порта источника на порт агента. Ответ агента будет отправлен назад на порт источника на менеджере. Менеджер получает уведомления (Traps и InformRequests) по порту 162. Агент может генерировать уведомления с любого доступного порта. При использовании TLS или DTLS запросы получаются по порту 10161, а ловушки отправляются на порт 10162.\r\n\r\nsnmp v2 - Добавлен bulkrequest и криптозащита, улучшена производительность, несовместим с v1\r\nsnmp v3 - Улучшена криптозащита.\r\n\r\nh2. Зачем нужны коммьюнити (скрипт sudo snmpconf -i -g basic_setup)\r\n\r\nThe community name to add read-only access for: public\r\nThe hostname or network address to accept this community name from [RETURN for all]: \r\nThe OID that this community should be restricted to [RETURN for no-restriction]: \r\n\r\nпо конфигурированию:\r\ninformsink  127.0.0.1 - A host name that should receive the trap\r\n\r\n\"Net-SNMP_and_lm-sensors\":http://www.net-snmp.org/wiki/index.php/Net-SNMP_and_lm-sensors_on_Ubuntu_10.04\r\n\r\nОчень непросто оказывается настраивать snmpd\r\n\r\nh1. Telnet\r\n\r\nHow to change screen size in telnet:\r\nhttp://stackoverflow.com/questions/11575558/is-it-possible-to-send-resize-pty-command-with-telnetlib\r\n\r\nh1. WEB\r\n\r\nh2. WSGI\r\n\r\n1) /etc/apache2/sites-available/default заменить на прикрепленный файл\r\n2) установить libapache2-mod-wsgi-py3\r\n3) export PYTHONPATH=path_to_nms_app\r\n4) база данных генерится командой python3 collector.py -f nms_random_10_09_2013_100_val -g 1 -t 0.1\r\n5) переписать везде абсолютные пути\r\n\r\nh2. Django\r\n\r\n1) Установка Timezone - settings.py TIMEZONE=None, USE_TZ=True\r\n\r\nh1. MySQL\r\n\r\nУзнать размер всех баз данных в мегабайтах\r\nSELECT table_schema \"DB Name\", Round(Sum(data_length + index_length) / 1024 / 1024, 1) \"DB Size in MB\"  FROM  information_schema.tables  GROUP  BY table_schema;\r\n\r\nПолный бекап данных:\r\n@\r\nmysqldump -u root -p111111 06_12_db > 06_12_db.sql\r\ntar czf 06_12_db.sql.tgz 06_12_db.sql\r\nscp user@192.168.1.1:/home/user/06_12_db.sql.tgz .\r\ntar xzf 06_12_db.sql.tgz\r\nmysql -u root -p111111\r\ncreate database 06_12_db_new;\r\nmysql -u root -p111111 06_12_db_new < 06_12_db.sql\r\n@\r\nsudo /etc/init.d/mysqld start\r\n\r\nСм. последний дамп базы данных в source:03_04_db.sql.tgz\r\n\r\nh1. DHCP\r\n\r\nExample tested on ubuntu\r\n\r\nsudo apt-get install dhcp3-server\r\nsudo vi /etc/default/dhcp3-server\r\nINTERFACES=\"eth0″\r\nsudo vi /etc/dhcp/dhcpd.conf\r\nsubnet 192.168.0.0 netmask 255.255.255.0 {\r\n   range 192.168.0.1 192.168.0.200;\r\n   option routers 127.0.0.1;\r\n}\r\n\r\nhost pdu0 {\r\n   hardware ethernet 00:c0:b7:9b:2c:b4;\r\n   fixed-address 192.168.0.68;\r\n }\r\n\r\nsudo dhcpd\r\n\r\nh1. Other\r\n\r\nPing all devices in a subnet:\r\n\r\nsudo arp-scan --interface=eth0 192.168.0.0/24\r\n\r\nh1. Root on NFS\r\n\r\nhttp://rags.wordpress.com/2012/03/20/using-nfsroot-to-boot-diskless-clients-on-rhel/\r\n\r\nh1. nvidia-smi\r\n\r\n1) add lines from configs/server_snmpd.conf to snmpd.conf\r\n2) run run_nvsmi.sh\r\n3) place parse_nvsmi_xml.py into /root folder\r\n\r\n\r\nh1. intel mpi\r\n\r\n1) make mpd.hosts file in format \r\nhost:number of processes\r\nplace .mpd.conf with secret phrase (see ics tutorial)\r\n\r\nmpirun -r ssh -f ~/mpd.hosts -perhost [number_of_processes_per_jost] -np [total_number_of_processes] [program + parameters]\r\n\r\nmpd.hosts contains lists of hosts in the format:\r\nip(or hostname):max_number_of_processes_for_this_host\r\n\r\nна всякий случай\r\nhttps://help.ubuntu.com/community/MpichCluster\r\n\r\nh1. увеличение количества тредов и открытых файлов в rhel\r\n\r\nhttp://ithubinfo.blogspot.ru/2013/07/how-to-increase-ulimit-open-file-and.html\r\n2. Step : vi /etc/security/limits.conf  and add below the mentioned\r\n\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\nvi /etc/security/limits.conf  and add below the menstioed\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\nand  vi /etc/security/limits.d/90-nproc.conf\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\n\r\n\r\nh1. GlusterFS\r\n\r\nУстановка\r\nhttp://gluster.org/community/documentation/index.php/Gluster_3.2:_Installing_GlusterFS_on_Red_Hat_Package_Manager_%28RPM%29_Distributions\r\n\r\nРекомендуется версия 3.2\r\n\r\nНастройка\r\nhttp://www.prolinux.org/node/200\r\n\r\nЕсли после удаления тома, не дает создать новы и ругается на то, что brick всё ещё в томе:\r\nhttp://joejulian.name/blog/glusterfs-path-or-a-prefix-of-it-is-already-part-of-a-volume/\r\n\r\nНастроить /etc/fstab не вышло, монтируется автоматически в /common/autofs','','','2015-01-12 14:29:45',3),(38,11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop\r\n\r\nhttp://support.amd.com/en-us/kb-articles/Pages/AMDSystemMonitor.aspx\r\n\r\nshow cards:\r\nsudo aticonfig --lsa\r\nshow data:\r\ntemp\r\nDISPLAY=:0 sudo aticonfig --odgt --adapter=all\r\nload\r\nDISPLAY=:0 sudo aticonfig --odgc --adapter=all\r\n\r\nнастройка:\r\nexport DISPLAY=:0\r\naticonfig --initial --adapter=all\r\n\r\n\r\nh2. Подготовка к запуску:\r\n\r\nh3. install 14.301.1010-linux-firepro-retail.zip :\r\n\r\n@unzip 14.301.1010-linux-firepro-retail.zip\r\ncd fglrx..\r\n./check\r\n./install.sh -> redhat package -> agree -> no install\r\nsudo yum reinstall ./fglrx64_p_i_c-14.301.1010-1.x86_64.rpm@\r\n\r\nh3. install AMD-APP-SDK-linux-v2.9-1.599.381-GA-x64.tar.bz2\r\n\r\n@sudo ./AMD-APP-SDK-v2.9-1.599.381-GA-linux64.sh@\r\n* agree = y\r\n* enter\r\n\r\nh3. relogin\r\n\r\n@export DISPLAY=:0\r\naticonfig --initial --adapter=all\r\nreboot@\r\n\r\n# export COMPUTE=:0\r\n# export DISPLAY=:0\r\n# xhost +local:\r\ncopy gpu_benchmark\r\n\r\nh2. See card driver info:\r\n\r\n/opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo','','','2015-01-12 15:33:35',4),(39,11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop\r\n\r\nhttp://support.amd.com/en-us/kb-articles/Pages/AMDSystemMonitor.aspx\r\n\r\nshow cards:\r\nsudo aticonfig --lsa\r\nshow data:\r\ntemp\r\nDISPLAY=:0 sudo aticonfig --odgt --adapter=all\r\nload\r\nDISPLAY=:0 sudo aticonfig --odgc --adapter=all\r\n\r\nнастройка:\r\nexport DISPLAY=:0\r\naticonfig --initial --adapter=all\r\n\r\n\r\nh2. Подготовка к запуску:\r\n\r\nh3. install 14.301.1010-linux-firepro-retail.zip :\r\n\r\n@unzip 14.301.1010-linux-firepro-retail.zip\r\ncd fglrx..\r\n./check\r\n./install.sh -> redhat package -> agree -> no install\r\nsudo yum reinstall ./fglrx64_p_i_c-14.301.1010-1.x86_64.rpm@\r\n\r\nh3. install AMD-APP-SDK-linux-v2.9-1.599.381-GA-x64.tar.bz2\r\n\r\n@sudo ./AMD-APP-SDK-v2.9-1.599.381-GA-linux64.sh@\r\n* agree = y\r\n* enter\r\n\r\nh3. relogin\r\n\r\n@export DISPLAY=:0\r\naticonfig --initial --adapter=all\r\nreboot@\r\n\r\n# export COMPUTE=:0\r\n# export DISPLAY=:0\r\n# xhost +local:\r\ncopy gpu_benchmark\r\n\r\nh2. See card driver info:\r\n\r\n/opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo | less','','','2015-01-12 15:34:32',5),(40,11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop\r\n\r\nhttp://support.amd.com/en-us/kb-articles/Pages/AMDSystemMonitor.aspx\r\n\r\nshow cards:\r\nsudo aticonfig --lsa\r\nshow data:\r\ntemp\r\nDISPLAY=:0 sudo aticonfig --odgt --adapter=all\r\nload\r\nDISPLAY=:0 sudo aticonfig --odgc --adapter=all\r\n\r\nнастройка:\r\nexport DISPLAY=:0\r\naticonfig --initial --adapter=all\r\n\r\n\r\nh2. Подготовка к запуску:\r\n\r\nh3. install 14.301.1010-linux-firepro-retail.zip :\r\n\r\n@unzip 14.301.1010-linux-firepro-retail.zip\r\ncd fglrx..\r\n./check\r\n./install.sh -> redhat package -> agree -> no install\r\nsudo yum reinstall ./fglrx64_p_i_c-14.301.1010-1.x86_64.rpm@\r\n\r\nh3. install AMD-APP-SDK-linux-v2.9-1.599.381-GA-x64.tar.bz2\r\n\r\n@sudo ./AMD-APP-SDK-v2.9-1.599.381-GA-linux64.sh@\r\n* agree = y\r\n* enter\r\n\r\nh3. relogin\r\n\r\n@export DISPLAY=:0\r\naticonfig --initial --adapter=all\r\nreboot@\r\n\r\n# export COMPUTE=:0\r\n# export DISPLAY=:0\r\n# xhost +local:\r\n# export COMPUTE=:0; export DISPLAY=:0; xhost +local:\r\ncopy gpu_benchmark\r\n\r\nh2. See card driver info:\r\n\r\n/opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo | less','','','2015-01-12 16:17:11',6),(41,11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop\r\n\r\nhttp://support.amd.com/en-us/kb-articles/Pages/AMDSystemMonitor.aspx\r\n\r\nshow cards:\r\nsudo aticonfig --lsa\r\nshow data:\r\ntemp\r\nDISPLAY=:0 sudo aticonfig --odgt --adapter=all\r\nload\r\nDISPLAY=:0 sudo aticonfig --odgc --adapter=all\r\n\r\nнастройка:\r\nexport DISPLAY=:0\r\naticonfig --initial --adapter=all\r\n\r\n\r\nh2. Подготовка к запуску:\r\n\r\nh3. install 14.301.1010-linux-firepro-retail.zip :\r\n\r\n@unzip 14.301.1010-linux-firepro-retail.zip\r\ncd fglrx..\r\n./check\r\n./install.sh -> redhat package -> agree -> no install\r\nsudo yum reinstall ./fglrx64_p_i_c-14.301.1010-1.x86_64.rpm@\r\n\r\nh3. install AMD-APP-SDK-linux-v2.9-1.599.381-GA-x64.tar.bz2\r\n\r\n@sudo ./AMD-APP-SDK-v2.9-1.599.381-GA-linux64.sh@\r\n* agree = y\r\n* enter\r\n\r\nh3. relogin\r\n\r\n@export DISPLAY=:0\r\naticonfig --initial --adapter=all\r\nreboot@\r\n\r\n# export COMPUTE=:0\r\n# export DISPLAY=:0\r\n# xhost +local:\r\n# export COMPUTE=:0; export DISPLAY=:0; xhost +local:\r\ncopy gpu_benchmark\r\naticonfig --initial --adapter=all\r\n\r\nh2. See card driver info:\r\n\r\n/opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo | less\r\n\r\n\r\nh2. After install or remove cards:\r\n\r\n@root\r\nsleep 10; export COMPUTE=:0; export DISPLAY=:0; xhost +local:\r\naticonfig --initial --adapter=all\r\nreboot\r\n\r\n@root\r\nexport COMPUTE=:0; export DISPLAY=:0; xhost +local:; /opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo | grep \"Number of devices\"\r\n\r\n\r\n7 w9100->4gpu\r\n6 w9100->6gpu','','','2015-01-12 16:56:28',7),(42,11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop\r\n\r\nhttp://support.amd.com/en-us/kb-articles/Pages/AMDSystemMonitor.aspx\r\n\r\nshow cards:\r\nsudo aticonfig --lsa\r\nshow data:\r\ntemp\r\nDISPLAY=:0 sudo aticonfig --odgt --adapter=all\r\nload\r\nDISPLAY=:0 sudo aticonfig --odgc --adapter=all\r\n\r\nнастройка:\r\nexport DISPLAY=:0\r\naticonfig --initial --adapter=all\r\n\r\n\r\nh2. Подготовка к запуску:\r\n\r\nh3. install 14.301.1010-linux-firepro-retail.zip :\r\n\r\n@unzip 14.301.1010-linux-firepro-retail.zip\r\ncd fglrx..\r\n./check\r\n./install.sh -> redhat package -> agree -> no install\r\nsudo yum reinstall ./fglrx64_p_i_c-14.301.1010-1.x86_64.rpm@\r\n\r\nh3. install AMD-APP-SDK-linux-v2.9-1.599.381-GA-x64.tar.bz2\r\n\r\n@sudo ./AMD-APP-SDK-v2.9-1.599.381-GA-linux64.sh@\r\n* agree = y\r\n* enter\r\n\r\nh3. relogin\r\n\r\n@export DISPLAY=:0\r\naticonfig --initial --adapter=all\r\nreboot@\r\n\r\n# export COMPUTE=:0\r\n# export DISPLAY=:0\r\n# xhost +local:\r\n# export COMPUTE=:0; export DISPLAY=:0; xhost +local:\r\ncopy gpu_benchmark\r\naticonfig --initial --adapter=all\r\n\r\nh2. See card driver info:\r\n\r\n/opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo | less\r\n\r\n\r\nh2. After install or remove cards:\r\n\r\n@root\r\nsleep 10; export COMPUTE=:0; export DISPLAY=:0; xhost +local:\r\naticonfig --initial --adapter=all\r\nreboot\r\n\r\n@root\r\nexport COMPUTE=:0; export DISPLAY=:0; xhost +local:; /opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo | grep \"Number of devices\"\r\n\r\nfglrxinfo\r\n\r\n7 w9100->4gpu\r\n6 w9100->6gpu','','','2015-01-12 17:19:10',8);
/*!40000 ALTER TABLE `wiki_content_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_contents`
--

DROP TABLE IF EXISTS `wiki_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `text` longtext,
  `comments` varchar(255) DEFAULT '',
  `updated_on` datetime NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_contents_page_id` (`page_id`),
  KEY `index_wiki_contents_on_author_id` (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_contents`
--

LOCK TABLES `wiki_contents` WRITE;
/*!40000 ALTER TABLE `wiki_contents` DISABLE KEYS */;
INSERT INTO `wiki_contents` VALUES (1,1,3,'h1. Справка по системе\r\n\r\nh2. [[Спецификация - Оборудование]]\r\n\r\nh2. [[Спецификация - Технологии]]\r\n\r\nh2. [[Техническое задание]]\r\n\r\nh1. Руководства\r\n\r\nh2. [[Загрузка по сети]]\r\n\r\nh2. [[Установка системы на Ubuntu]]\r\n\r\nh2. [[Установка snmp-agent на win2014]]\r\n\r\nh2. [[GPU install]]\r\n\r\nh1. Планы\r\n\r\nh2. [[Артем]]\r\n','','2015-01-12 11:19:21',9),(2,2,3,'h1. План тестирования\r\n\r\n# См Тесты\r\n# Алерты\r\n# Модуль представления\r\n# Экспорт в бд\r\n\r\n','','2014-08-27 04:36:08',2),(3,3,3,'h1. План рефакторинга\r\n\r\n# Тесты\r\n# Алерты\r\n# Группы параметров\r\n# Пересмотреть сохранение в бд\r\n\r\n','','2014-08-27 04:35:55',1),(4,4,3,'h1. Спецификация - Оборудование\r\n\r\nh2. hp-5800\r\n\r\ninitial setup:\r\nplug console cable in special SVK notebook and run putty:\r\nsystem-view\r\nvlan 10\r\ndescription Test VLAN\r\nprotocol-vlan 0 ipv4\r\nip-subnet-vlan 0 ip 192.168.0.0 255.255.0.0\r\n\r\ninterface Vlan-interface10\r\nip address 192.168.7.2 255.255.0.0\r\n\r\ninterface GigabitEthernet1/0/1\r\nport access vlan 10\r\n\r\n[Sysname] local-user admin\r\n[Sysname-luser-admin] service-type telnet\r\n[Sysname-luser-admin] authorization-attribute level 3\r\n[Sysname-luser-admin] password simple admin\r\n\r\nsave\r\n\r\n[end]\r\n\r\n\r\nip: 192.168.7.2 (port 1 only!)\r\nusername: admin\r\npassword: 111111\r\n\r\nreference:\r\nhttp://ixnfo.com/nastroyka-hp-5800.html\r\n\r\nh2. hp-1910-8g\r\n\r\ndefault ip: 169.254.150.62\r\ndon\'t forget your ip: 169.254.150.62/16\r\nhttp://www.petenetlive.com/KB/Article/0000495.htm\r\nDefault access is user name admin with a blank password.\r\n\r\ncurrent ip: 192.168.7.1\r\n\r\nh2. PDU\r\n\r\nip 192.168.20.1\r\nip 192.168.20.2\r\nip 192.168.20.3\r\nip 192.168.20.4\r\n\r\nAPC 8981\r\n\r\nlogin: apc\r\npass: apc\r\n\r\nMIB - смотри приложение, rPDU.\r\n\r\nOverload Alarm: 	kW 16.0\r\nNear Overload Warning: 	kW 8.8\r\nLow Load Warning: 	kW 0.0\r\n\r\nh2. UPS\r\n\r\n*powerware 9130 3kva*\r\n\r\nip интерфейса станции 192.168.0.1\r\nip интерфейса UPS 192.168.7.18\r\n\r\nmib - http://support.ipmonitor.com/mibs/XUPS-MIB/raw.aspx\r\n\r\nSNMP параметры\r\nprivate iso.3.6.1.4.1.534 \r\n# \"Battery run time in seconds before UPS turns off due to low battery\" : \"1.2.1\",\r\n# \"Battery percent charge\" : \"1.2.4\"\r\n\r\nh2. RAID\r\n\r\ndothill 3730\r\nweb login: manage\r\nweb password: !manage\r\nPower 436W\r\n\r\n|_. Raid |_. Serial Number |_. FileServer01 |_. FileServer02 |\r\n| Raid01 | a2a | sdc | sdb |\r\n| Raid01 | a52 | sdb | sde |\n\nh2. KVM\r\n\r\n192.168.0.60 \r\n\r\nlogin: administrator\r\npass: password\r\n\r\n6EA0D-L0X7B-SCJE0-06272\r\n\r\nДжава-приложение для использования нашего kvm: attachment:JavaClient.jar\n\nh2. остальные сервера\r\n\r\nuser - 111111\r\nroot - 111111\r\n\r\nh2. Как разметить Raid на 20Тб\r\nparted /dev/sdb\r\n>mklabel\r\n>gpt\r\n\r\ngit clone git://git.kernel.org/pub/scm/fs/ext2/e2fsprogs.git\r\ncd e2fsprogs\r\nmkdir build ; cd build/\r\n../configure\r\nmake\r\nmake install\r\n./mke2fs -O 64bit,has_journal,extents,huge_file,flex_bg, uninit_bg,dir_nlink,extra_isize -i 4194304 /dev/sdb\r\n\r\n\r\nh2. NetBootz 200\r\n\r\narp -s 192.168.11.2 00:c0:b7:9b:91:c0\r\nping 192.168.11.2 -s 113\r\n\r\nhttp://www.apc.com/products/resource/include/techspec_index.cfm?base_sku=NBRK0201\r\n\r\nhttp://www.irrexpr.com/2012/06/accessing-snmp-temperature-information.html\r\n\r\nlogin apc\r\npassw apc\r\n\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.3.0.1  - Sensor Name\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.4.0.1  - Sensor Location\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.5.0.1  - Temperature\r\n1.3.6.1.4.1.318.1.1.10.4.2.3.1.6.0.1  - Humid\r\n\r\n\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.1.0.2 = INTEGER: 0\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.2.0.2 = INTEGER: 2\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.3.0.2 = STRING: \"Sensor MM:2\"\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.4.0.2 = STRING: \"Unknown\"\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.5.0.2 = INTEGER: 1 -> 2 при open\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.7.0.2 = INTEGER: 2 -> 1 при open\r\nSNMPv2-SMI::enterprises.318.1.1.10.4.3.2.1.8.0.2 = INTEGER: 2 -\r\n\r\nh2. Расчётные серверы\r\n\r\n1) 192.168.10.11 - BMC','','2014-10-21 14:52:07',2),(5,5,3,'h1. Спецификация - Технологии\r\n\r\nh1. IPMI\r\n\r\n@ipmitool -I lan -H 10.0.0.55 -U root -P superuser sensor@\r\n\r\nh1. SNMP\r\n\r\nпримеры команд os linux:\r\n<pre>\r\nsnmpwalk -Os -c public -v 1 192.168.7.18\r\nsnmpget -v 1 -Cf -c public 192.168.7.18 iso.3.6.1.4.1.534.1.2.4\r\n</pre>\r\n\r\nSNMP работает на прикладном уровне TCP/IP (седьмой уровень модели OSI). Агент SNMP получает запросы по UDP-порту 161. Менеджер может посылать запросы с любого доступного порта источника на порт агента. Ответ агента будет отправлен назад на порт источника на менеджере. Менеджер получает уведомления (Traps и InformRequests) по порту 162. Агент может генерировать уведомления с любого доступного порта. При использовании TLS или DTLS запросы получаются по порту 10161, а ловушки отправляются на порт 10162.\r\n\r\nsnmp v2 - Добавлен bulkrequest и криптозащита, улучшена производительность, несовместим с v1\r\nsnmp v3 - Улучшена криптозащита.\r\n\r\nh2. Зачем нужны коммьюнити (скрипт sudo snmpconf -i -g basic_setup)\r\n\r\nThe community name to add read-only access for: public\r\nThe hostname or network address to accept this community name from [RETURN for all]: \r\nThe OID that this community should be restricted to [RETURN for no-restriction]: \r\n\r\nпо конфигурированию:\r\ninformsink  127.0.0.1 - A host name that should receive the trap\r\n\r\n\"Net-SNMP_and_lm-sensors\":http://www.net-snmp.org/wiki/index.php/Net-SNMP_and_lm-sensors_on_Ubuntu_10.04\r\n\r\nОчень непросто оказывается настраивать snmpd\r\n\r\nh1. Telnet\r\n\r\nHow to change screen size in telnet:\r\nhttp://stackoverflow.com/questions/11575558/is-it-possible-to-send-resize-pty-command-with-telnetlib\r\n\r\nh1. WEB\r\n\r\nh2. WSGI\r\n\r\n1) /etc/apache2/sites-available/default заменить на прикрепленный файл\r\n2) установить libapache2-mod-wsgi-py3\r\n3) export PYTHONPATH=path_to_nms_app\r\n4) база данных генерится командой python3 collector.py -f nms_random_10_09_2013_100_val -g 1 -t 0.1\r\n5) переписать везде абсолютные пути\r\n\r\nh2. Django\r\n\r\n1) Установка Timezone - settings.py TIMEZONE=None, USE_TZ=True\r\n\r\nh1. MySQL\r\n\r\nУзнать размер всех баз данных в мегабайтах\r\nSELECT table_schema \"DB Name\", Round(Sum(data_length + index_length) / 1024 / 1024, 1) \"DB Size in MB\"  FROM  information_schema.tables  GROUP  BY table_schema;\r\n\r\nПолный бекап данных:\r\n@\r\nmysqldump -u root -p111111 06_12_db > 06_12_db.sql\r\ntar czf 06_12_db.sql.tgz 06_12_db.sql\r\nscp user@192.168.1.1:/home/user/06_12_db.sql.tgz .\r\ntar xzf 06_12_db.sql.tgz\r\nmysql -u root -p111111\r\ncreate database 06_12_db_new;\r\nmysql -u root -p111111 06_12_db_new < 06_12_db.sql\r\n@\r\nsudo /etc/init.d/mysqld start\r\n\r\nСм. последний дамп базы данных в source:03_04_db.sql.tgz\r\n\r\nh1. DHCP\r\n\r\nExample tested on ubuntu\r\n\r\nsudo apt-get install dhcp3-server\r\nsudo vi /etc/default/dhcp3-server\r\nINTERFACES=\"eth0″\r\nsudo vi /etc/dhcp/dhcpd.conf\r\nsubnet 192.168.0.0 netmask 255.255.255.0 {\r\n   range 192.168.0.1 192.168.0.200;\r\n   option routers 127.0.0.1;\r\n}\r\n\r\nhost pdu0 {\r\n   hardware ethernet 00:c0:b7:9b:2c:b4;\r\n   fixed-address 192.168.0.68;\r\n }\r\n\r\nsudo dhcpd\r\n\r\nh1. Other\r\n\r\nPing all devices in a subnet:\r\n\r\nsudo arp-scan --interface=eth0 192.168.0.0/24\r\n\r\nh1. Root on NFS\r\n\r\nhttp://rags.wordpress.com/2012/03/20/using-nfsroot-to-boot-diskless-clients-on-rhel/\r\n\r\nh1. nvidia-smi\r\n\r\n1) add lines from configs/server_snmpd.conf to snmpd.conf\r\n2) run run_nvsmi.sh\r\n3) place parse_nvsmi_xml.py into /root folder\r\n\r\n\r\nh1. intel mpi\r\n\r\n1) make mpd.hosts file in format \r\nhost:number of processes\r\nplace .mpd.conf with secret phrase (see ics tutorial)\r\n\r\nmpirun -r ssh -f ~/mpd.hosts -perhost [number_of_processes_per_jost] -np [total_number_of_processes] [program + parameters]\r\n\r\nmpd.hosts contains lists of hosts in the format:\r\nip(or hostname):max_number_of_processes_for_this_host\r\n\r\nна всякий случай\r\nhttps://help.ubuntu.com/community/MpichCluster\r\n\r\nh1. увеличение количества тредов и открытых файлов в rhel\r\n\r\nhttp://ithubinfo.blogspot.ru/2013/07/how-to-increase-ulimit-open-file-and.html\r\n2. Step : vi /etc/security/limits.conf  and add below the mentioned\r\n\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\nvi /etc/security/limits.conf  and add below the menstioed\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\nand  vi /etc/security/limits.d/90-nproc.conf\r\n@\r\n*          soft     nproc          65535\r\n*          hard     nproc          65535\r\n*          soft     nofile         65535\r\n*          hard     nofile         65535\r\n@\r\n\r\n\r\nh1. GlusterFS\r\n\r\nУстановка\r\nhttp://gluster.org/community/documentation/index.php/Gluster_3.2:_Installing_GlusterFS_on_Red_Hat_Package_Manager_%28RPM%29_Distributions\r\n\r\nРекомендуется версия 3.2\r\n\r\nНастройка\r\nhttp://www.prolinux.org/node/200\r\n\r\nЕсли после удаления тома, не дает создать новы и ругается на то, что brick всё ещё в томе:\r\nhttp://joejulian.name/blog/glusterfs-path-or-a-prefix-of-it-is-already-part-of-a-volume/\r\n\r\nНастроить /etc/fstab не вышло, монтируется автоматически в /common/autofs','','2015-01-12 14:29:45',3),(6,6,3,'h1. Техническое задание\r\n\r\n\r\nh2. Для серверов и вычислительных модулей\r\n\r\n\r\n# -доступность по сети интерфейса серверов-\r\n# -доступность оп сети bmc-\r\n# -уровни напряжений-\r\n# -состояние БП-\r\n# -температура внутри системного блока-\r\n# -терморежим процессоров и ускорителей-\r\n# -скорости вращения внутрикорпусных вентиляторов-\r\n# -объем доступной оперативной памяти-\r\n# -объем корневой файловой системы-\r\n# -степень загруженности центральных процессоров-\r\n# -объем сетевого трафика-\r\n# -число доступных ускорителей и степень их загруженности-\r\n\r\nh2. Для дисковых массивов\r\n\r\n# доступность по сети *+*\r\n# температура встроенных датчиков *+*\r\n# *уровни напряжений с БП* *-*\r\n# *количество и тип установленных физических дисков, их состояние* -\r\n# *информация о логических дисках* -\r\n# *объем трафика* -\r\n\r\nh2. Для коммутаторов Ethernet\r\n\r\n# состояние коммутатора *+*\r\n# состояние каждого порта *+*\r\n# загрузка каждого порта октет/сек *+*\r\n# *температура внутри корпуса* -\r\n# *состояние вентиляторов и БП* -\r\n\r\nh2. для PDU\r\n\r\n# состояние каждой из розеток *+*\r\n# токи потребления *+*\r\n\r\nh2. для ТС мониторинга стоек (RMU)\r\n\r\n# температура и влажность *+*\r\n# состояние дверей стойки *+*','','2015-01-12 11:16:49',7),(7,7,3,'h1. Загрузка по сети\r\n\r\nКак заставить RHEL 6.4 загружаться по сети.\r\n\r\nh1. Установка системы и компиляция ядра.\r\n\r\nh2. Установка системы\r\n\r\n# Установить rhel на сервер, аналогичный тому, с которого вы будете загружаться.\r\n# в нем должны быть пакеты kernel-xxx.\r\n# sudo /sbin/service iptables stop\r\n\r\nh2. Компиляция ядра\r\n\r\n# устанавливаем *не от root* пакет: rpm -i kernel-2.6.32-358.el6.src.rpm\r\n# cd ~/rpmbuild/SPECS\r\n# rpmbuild -bp --target=$(uname -m) kernel.spec\r\n# cd ~/rpmbuild/BUILD?\r\n# скомпилируйте ядро\r\nдолжны быть включены\r\n@\r\nCONFIG_E1000=y\r\nCONFIG_IP_PNP=y \r\nCONFIG_IP_PNP_DHCP=y\r\nCONFIG_NFS_FS=y\r\nCONFIG_ROOT_NFS=y\r\n@\r\n# Компиляция\r\n@\r\nmake clean\r\nmake oldconfig\r\nmake menuconfig\r\nmake -j32 bzImage\r\nmake -j32 modules\r\nmake modules_install # /lib/modules/<KERNELVERSION>/kernel/drivers\r\nmake install # /boot\r\n@\r\n# cp /boot/YOUKERNEL /var/lib/tftpboot/images/rhel_6/\r\n\r\nh2. Создание образа initrd через dracut\r\n\r\n# dracut -f -v --modules \'nfs dash network ifcfg plymouth multipath  debug fstab-sys nfs  resume znet  insmodpost  syslog  kdumpbase kernel-modules base fs-lib img-lib shutdown\' /root/netboot6.img `uname -r` root=192.168.1.1:/var/nfs/server01 ip=eth0:on ip=192.168.30.1:192.168.1.1:255.255.0.0:bussol:eth0: rdinfo rdshell rdinitdebug rdbreak rdudevinfon\r\n# cp /root/netboot6.img /var/lib/tftpboot/images/rhel_6/netboot6.img\r\n\r\nh2. Tftp\r\n\r\nh3. Redhat\r\n\r\nкраткий ман: http://lonesysadmin.net/2007/10/29/how-to-install-a-tftp-server-on-red-hat-enterprise-linux/\r\nпакеты: \r\nlibwrap0-7.6-882.5.i586.rpm\r\ntftp-server-0.32-4.i386.rpm\r\n\r\nsudo vim /etc/xinetd.d/tftp\r\nservice tftp\r\n{\r\n        disable = no\r\n        socket_type             = dgram\r\n        protocol                = udp\r\n        wait                    = yes\r\n        user                    = root\r\n        server                  = /usr/sbin/in.tftpd\r\n        server_args             = -s /var/lib/tftpboot\r\n        per_source              = 11\r\n        cps                     = 100 2\r\n        flags                   = IPv4\r\n}\r\n\r\nsudo chkconfig tftp on\r\nsudo service xinetd reload\r\n\r\nh3. Ubuntu\r\n\r\n# ман https://linuxlink.timesys.com/docs/linux_tftp\r\n\r\ncreate\r\n# /etc/default/tftpd-hpa\r\n@\r\nTFTP_USERNAME=\"tftp\" \r\nTFTP_DIRECTORY=\"/tftpboot\" \r\nTFTP_ADDRESS=\"0.0.0.0:69\" \r\nTFTP_OPTIONS=\"--secure\r\n@\r\n# sudo /sbin/service xinetd restart\r\n\r\ndhcp v2\r\n\r\nh2. NFS\r\n\r\n# rsync -avP --numeric-ids --exclude=\'/dev\' --exclude=\'/proc\' --exclude=\'/sys\' root@192.168.30.1:/ /var/nfs/server01/\r\n# mkdir /var/nfs/server01/tmp/\r\n# mkdir /var/nfs/server01/sys/\r\n# mkdir /var/nfs/server01/dev/\r\n# mkdir /var/nfs/server01/proc/\r\n#/etc/exports\r\n@\r\n/var/nfs/server01 *(rw,async,no_root_squash)\r\n@\r\n# sudo service nfs restart\r\n# sudo exportfs -a\r\n\r\nh2. DHCP\r\n\r\n# /etc/dhcpd.conf\r\n@\r\nallow booting;\r\nallow bootp;\r\nsubnet 192.168.0.0 netmask 255.255.0.0 {\r\n	range 192.168.50.1 192.168.50.100;\r\n	filename \"pxelinux.0\";\r\n	#option root-path \"192.168.1.1:/var/nfs/server01,rw,nolock\";\r\n}\r\nhost pdu0{\r\n	hardware ethernet 00:c0:b7:9b:2c:b4;\r\n	fixed-address 192.168.0.68;\r\n	option routers 127.0.0.1;\r\n}\r\nhost hp_1910{\r\n        hardware ethernet d0:7e:28:1d:96:3f;\r\n        fixed-address 192.168.7.1;\r\n        option routers 127.0.0.1;\r\n}\r\nhost gpu_serv01{\r\n	hardware ethernet 00:e0:81:e4:83:e2;\r\n	#option root-path \"192.168.1.1:/var/nfs/server01,rw,nolock\";\r\n	fixed-address 192.168.30.1;\r\n	option routers 127.0.0.1;\r\n}\r\n@\r\n# sudo service dhcpd restart\r\n\r\nh2. PXE config\r\n\r\n# /tftpboot/pxelinux.cfg/default\r\n@\r\ndefault menu.c32\r\nprompt 0\r\nmenu title Bussol complex boot menu\r\nMENU AUTOBOOT Starting Local System in # seconds\r\nlabel local\r\n    menu label rhel6-local\r\n    kernel images/rhel_6/vmlinuz-2.6.32_nfs_custom root=UUID=3a30c143-8229-48b2-8d10-bdcf567f644a\r\n    append initrd=images/rhel_6/initramfs-2.6.32_nfs_custom.img rdshell vga=773\r\nlabel rhel6_nfs\r\n    menu label rhel6 with nfs\r\n    menu default\r\n    timeout 100\r\n    kernel images/rhel_6/vmlinuz-2.6.32_nfs_custom\r\n    append root=/dev/nfs nfsroot=192.168.1.1:/var/nfs/server01,vers=3,nolock,nfsvers=3 ip=dhcp rw nfsrootdebug initrd=images/rhel_6/netboot6.img lang=us keymap=us noipv6 rdshell vga=773\r\n@\r\n\r\nh1. enjoy!\r\n!https://hostedredmine.s3.amazonaws.com/131220230518_download.jpg?AWSAccessKeyId=AKIAJLVUOXB2KSUPTRFQ&Expires=1387543201&Signature=k7XmTfHOvIT6oQZONx%2BHihTG1HA%3D!\r\n\r\nh1. TFTP UBUNTU\r\n\r\n\r\nhttp://thestorey.ca/wordpress/?p=26\r\n\r\nhttp://www.cyberciti.biz/faq/install-configure-tftp-server-ubuntu-debian-howto\r\n\r\nh1. Установочные пакеты\r\n\r\nattachment:libwrap0-7.6-882.5.i586.rpm \r\nattachment:tftp-server-0.32-4.i386.rpm ','','2014-10-21 15:09:31',2),(8,8,3,'h1. Установка системы на Ubuntu\r\n\r\n# sudo apt-get install git\r\n# git clone https://dkhodakov@bitbucket.org/orionservermonitoring/bussol.git\r\n# git fetch && git checkout server\r\n# sudo apt-get install python3-pip\r\n# sudo pip3 install nose\r\n# PYTHONPATH=/home/dimert/NMS/nms_app; export PYTHONPATH\r\n# cd ~/NMS/nms_app; cp server_local_settings.py local_settings.py\r\n# edit local settings, change username in paths\r\n# sudo mkdir /var/log/nms; sudo chmod a+rwx /var/log/nms\r\n# sudo pip3 install -I django==1.5.1\r\n# sudo apt-get install mysql-server mysql-client (pass 111111)\r\n# sudo pip3 install pymysql\r\n# sudo apt-get install ipmitool snmp snmpd\r\n# edit /etc/snmp/snmpd : view systemonly included .1\r\n# nosetests -v --processes=25 --process-timeout=300 --process-restartworker\r\n# sudo apt-get install apache2 libapache2-mod-wsgi-py3\r\n# cp 000-default to sites-available with changed username\r\n# sudo a2enmod wsgi\r\n# sudo apt-get install apache2-dev\r\n# sudo chmod a+rwx /home/dimert/\r\n# cd ~/; mkdir build; cd build/; wget https://github.com/GrahamDumpleton/mod_wsgi/archive/4.2.8.tar.gz; tar xzf 4.2.8.tar.gz; cd mod_wsgi-4.2.8/; ./configure -with-python=`which python3`; make; sudo make install; sudo service apache2 restart\r\n# sudo chmod a+rw /var/log/nms/*.log\r\n# cd database_backup/\r\n# tar xzf 03_04_db.sql.tgz\r\n# mysql -u root -p111111 -e \'Create database 03_04_db;\'\r\n# mysql -u root -p111111 03_04_db < 03_04_db.sql\r\n# rm database_backup/03_04_db.sql\r\n# sudo service apache2 restart','','2014-10-21 15:06:19',1),(9,9,3,'h1. Артем\r\n\r\nh2. Неделя 17-24:\r\n\r\n# Погружение в питон, несколько глав\r\n# Скрипт 1 - \r\n# Начало гит, pep8, pycharm\r\n\r\nh2. неделя 24-30:\r\n\r\n# Скрипт 2 - simple_monitoring (вторник - уже готова сеть и пересылаются данные, рефакторинг)\r\n# артему - конверсия (1, 3, 6, 1, 4, 1, 2021, 11, 9, 0)) в строчку (готово через час)\r\n\r\nh2. декабрь 2014\r\n\r\n# Рефакторинг database - хорошо справляется\r\n\r\nh2. январь 2015\r\n\r\n# Рефакторинг database продолжаем #141\r\n\r\n','','2015-01-12 11:09:55',5),(10,10,3,'h1. Установка snmp-agent на win2014\r\n\r\n1. распаковать Python34.zip в C:\\Python34\r\n2. переместить памку nms_snmp_agent в C:\\\r\n2. использовать nssm.exe чтобы создать сервис. C:\\Python34\\python.exe C:\\nms_snmp_agent\\nms_snmp_agent.py','','2014-11-27 09:11:48',2),(11,11,3,'h1. GPU install\r\n\r\nAMD has two options, fglrx (closed source drivers)\r\n\r\naticonfig --odgc --odgt\r\nAnd for mesa (open source drivers), you can use RadeonTop\r\n\r\nhttp://support.amd.com/en-us/kb-articles/Pages/AMDSystemMonitor.aspx\r\n\r\nshow cards:\r\nsudo aticonfig --lsa\r\nshow data:\r\ntemp\r\nDISPLAY=:0 sudo aticonfig --odgt --adapter=all\r\nload\r\nDISPLAY=:0 sudo aticonfig --odgc --adapter=all\r\n\r\nнастройка:\r\nexport DISPLAY=:0\r\naticonfig --initial --adapter=all\r\n\r\n\r\nh2. Подготовка к запуску:\r\n\r\nh3. install 14.301.1010-linux-firepro-retail.zip :\r\n\r\n@unzip 14.301.1010-linux-firepro-retail.zip\r\ncd fglrx..\r\n./check\r\n./install.sh -> redhat package -> agree -> no install\r\nsudo yum reinstall ./fglrx64_p_i_c-14.301.1010-1.x86_64.rpm@\r\n\r\nh3. install AMD-APP-SDK-linux-v2.9-1.599.381-GA-x64.tar.bz2\r\n\r\n@sudo ./AMD-APP-SDK-v2.9-1.599.381-GA-linux64.sh@\r\n* agree = y\r\n* enter\r\n\r\nh3. relogin\r\n\r\n@export DISPLAY=:0\r\naticonfig --initial --adapter=all\r\nreboot@\r\n\r\n# export COMPUTE=:0\r\n# export DISPLAY=:0\r\n# xhost +local:\r\n# export COMPUTE=:0; export DISPLAY=:0; xhost +local:\r\ncopy gpu_benchmark\r\naticonfig --initial --adapter=all\r\n\r\nh2. See card driver info:\r\n\r\n/opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo | less\r\n\r\n\r\nh2. After install or remove cards:\r\n\r\n@root\r\nsleep 10; export COMPUTE=:0; export DISPLAY=:0; xhost +local:\r\naticonfig --initial --adapter=all\r\nreboot\r\n\r\n@root\r\nexport COMPUTE=:0; export DISPLAY=:0; xhost +local:; /opt/AMDAPPSDK-2.9-1/bin/x86_64/clinfo | grep \"Number of devices\"\r\n\r\nfglrxinfo\r\n\r\n7 w9100->4gpu\r\n6 w9100->6gpu','','2015-01-12 17:19:10',8);
/*!40000 ALTER TABLE `wiki_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_pages`
--

DROP TABLE IF EXISTS `wiki_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wiki_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL,
  `protected` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_pages_wiki_id_title` (`wiki_id`,`title`),
  KEY `index_wiki_pages_on_wiki_id` (`wiki_id`),
  KEY `index_wiki_pages_on_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_pages`
--

LOCK TABLES `wiki_pages` WRITE;
/*!40000 ALTER TABLE `wiki_pages` DISABLE KEYS */;
INSERT INTO `wiki_pages` VALUES (1,2,'Wiki','2014-08-27 04:18:36',0,NULL),(2,2,'План_тестирования','2014-08-27 04:20:42',0,1),(3,2,'План_рефакторинга','2014-08-27 04:35:55',0,1),(4,2,'Спецификация_-_Оборудование','2014-10-21 14:36:04',0,1),(5,2,'Спецификация_-_Технологии','2014-10-21 14:36:33',0,1),(6,2,'Техническое_задание','2014-10-21 14:42:24',0,1),(7,2,'Загрузка_по_сети','2014-10-21 14:50:30',0,1),(8,2,'Установка_системы_на_Ubuntu','2014-10-21 15:06:19',0,1),(9,2,'Артем','2014-11-24 11:32:41',0,1),(10,2,'Установка_snmp-agent_на_win2014','2014-11-26 11:51:52',0,1),(11,2,'GPU_install','2014-11-27 11:52:44',0,1);
/*!40000 ALTER TABLE `wiki_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_redirects`
--

DROP TABLE IF EXISTS `wiki_redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_redirects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wiki_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `redirects_to` varchar(255) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_redirects_wiki_id_title` (`wiki_id`,`title`),
  KEY `index_wiki_redirects_on_wiki_id` (`wiki_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_redirects`
--

LOCK TABLES `wiki_redirects` WRITE;
/*!40000 ALTER TABLE `wiki_redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wikis`
--

DROP TABLE IF EXISTS `wikis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wikis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `start_page` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `wikis_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wikis`
--

LOCK TABLES `wikis` WRITE;
/*!40000 ALTER TABLE `wikis` DISABLE KEYS */;
INSERT INTO `wikis` VALUES (1,1,'Wiki',1),(2,2,'Wiki',1),(3,3,'Wiki',1);
/*!40000 ALTER TABLE `wikis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows`
--

DROP TABLE IF EXISTS `workflows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_id` int(11) NOT NULL DEFAULT '0',
  `old_status_id` int(11) NOT NULL DEFAULT '0',
  `new_status_id` int(11) NOT NULL DEFAULT '0',
  `role_id` int(11) NOT NULL DEFAULT '0',
  `assignee` tinyint(1) NOT NULL DEFAULT '0',
  `author` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(30) DEFAULT NULL,
  `field_name` varchar(30) DEFAULT NULL,
  `rule` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wkfs_role_tracker_old_status` (`role_id`,`tracker_id`,`old_status_id`),
  KEY `index_workflows_on_old_status_id` (`old_status_id`),
  KEY `index_workflows_on_role_id` (`role_id`),
  KEY `index_workflows_on_new_status_id` (`new_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows`
--

LOCK TABLES `workflows` WRITE;
/*!40000 ALTER TABLE `workflows` DISABLE KEYS */;
INSERT INTO `workflows` VALUES (1,1,1,2,3,0,0,'WorkflowTransition',NULL,NULL),(2,1,1,3,3,0,0,'WorkflowTransition',NULL,NULL),(3,1,1,4,3,0,0,'WorkflowTransition',NULL,NULL),(4,1,1,5,3,0,0,'WorkflowTransition',NULL,NULL),(5,1,1,6,3,0,0,'WorkflowTransition',NULL,NULL),(6,1,2,1,3,0,0,'WorkflowTransition',NULL,NULL),(7,1,2,3,3,0,0,'WorkflowTransition',NULL,NULL),(8,1,2,4,3,0,0,'WorkflowTransition',NULL,NULL),(9,1,2,5,3,0,0,'WorkflowTransition',NULL,NULL),(10,1,2,6,3,0,0,'WorkflowTransition',NULL,NULL),(11,1,3,1,3,0,0,'WorkflowTransition',NULL,NULL),(12,1,3,2,3,0,0,'WorkflowTransition',NULL,NULL),(13,1,3,4,3,0,0,'WorkflowTransition',NULL,NULL),(14,1,3,5,3,0,0,'WorkflowTransition',NULL,NULL),(15,1,3,6,3,0,0,'WorkflowTransition',NULL,NULL),(16,1,4,1,3,0,0,'WorkflowTransition',NULL,NULL),(17,1,4,2,3,0,0,'WorkflowTransition',NULL,NULL),(18,1,4,3,3,0,0,'WorkflowTransition',NULL,NULL),(19,1,4,5,3,0,0,'WorkflowTransition',NULL,NULL),(20,1,4,6,3,0,0,'WorkflowTransition',NULL,NULL),(21,1,5,1,3,0,0,'WorkflowTransition',NULL,NULL),(22,1,5,2,3,0,0,'WorkflowTransition',NULL,NULL),(23,1,5,3,3,0,0,'WorkflowTransition',NULL,NULL),(24,1,5,4,3,0,0,'WorkflowTransition',NULL,NULL),(25,1,5,6,3,0,0,'WorkflowTransition',NULL,NULL),(26,1,6,1,3,0,0,'WorkflowTransition',NULL,NULL),(27,1,6,2,3,0,0,'WorkflowTransition',NULL,NULL),(28,1,6,3,3,0,0,'WorkflowTransition',NULL,NULL),(29,1,6,4,3,0,0,'WorkflowTransition',NULL,NULL),(30,1,6,5,3,0,0,'WorkflowTransition',NULL,NULL),(31,2,1,2,3,0,0,'WorkflowTransition',NULL,NULL),(32,2,1,3,3,0,0,'WorkflowTransition',NULL,NULL),(33,2,1,4,3,0,0,'WorkflowTransition',NULL,NULL),(34,2,1,5,3,0,0,'WorkflowTransition',NULL,NULL),(35,2,1,6,3,0,0,'WorkflowTransition',NULL,NULL),(36,2,2,1,3,0,0,'WorkflowTransition',NULL,NULL),(37,2,2,3,3,0,0,'WorkflowTransition',NULL,NULL),(38,2,2,4,3,0,0,'WorkflowTransition',NULL,NULL),(39,2,2,5,3,0,0,'WorkflowTransition',NULL,NULL),(40,2,2,6,3,0,0,'WorkflowTransition',NULL,NULL),(41,2,3,1,3,0,0,'WorkflowTransition',NULL,NULL),(42,2,3,2,3,0,0,'WorkflowTransition',NULL,NULL),(43,2,3,4,3,0,0,'WorkflowTransition',NULL,NULL),(44,2,3,5,3,0,0,'WorkflowTransition',NULL,NULL),(45,2,3,6,3,0,0,'WorkflowTransition',NULL,NULL),(46,2,4,1,3,0,0,'WorkflowTransition',NULL,NULL),(47,2,4,2,3,0,0,'WorkflowTransition',NULL,NULL),(48,2,4,3,3,0,0,'WorkflowTransition',NULL,NULL),(49,2,4,5,3,0,0,'WorkflowTransition',NULL,NULL),(50,2,4,6,3,0,0,'WorkflowTransition',NULL,NULL),(51,2,5,1,3,0,0,'WorkflowTransition',NULL,NULL),(52,2,5,2,3,0,0,'WorkflowTransition',NULL,NULL),(53,2,5,3,3,0,0,'WorkflowTransition',NULL,NULL),(54,2,5,4,3,0,0,'WorkflowTransition',NULL,NULL),(55,2,5,6,3,0,0,'WorkflowTransition',NULL,NULL),(56,2,6,1,3,0,0,'WorkflowTransition',NULL,NULL),(57,2,6,2,3,0,0,'WorkflowTransition',NULL,NULL),(58,2,6,3,3,0,0,'WorkflowTransition',NULL,NULL),(59,2,6,4,3,0,0,'WorkflowTransition',NULL,NULL),(60,2,6,5,3,0,0,'WorkflowTransition',NULL,NULL),(61,3,1,2,3,0,0,'WorkflowTransition',NULL,NULL),(62,3,1,3,3,0,0,'WorkflowTransition',NULL,NULL),(63,3,1,4,3,0,0,'WorkflowTransition',NULL,NULL),(64,3,1,5,3,0,0,'WorkflowTransition',NULL,NULL),(65,3,1,6,3,0,0,'WorkflowTransition',NULL,NULL),(66,3,2,1,3,0,0,'WorkflowTransition',NULL,NULL),(67,3,2,3,3,0,0,'WorkflowTransition',NULL,NULL),(68,3,2,4,3,0,0,'WorkflowTransition',NULL,NULL),(69,3,2,5,3,0,0,'WorkflowTransition',NULL,NULL),(70,3,2,6,3,0,0,'WorkflowTransition',NULL,NULL),(71,3,3,1,3,0,0,'WorkflowTransition',NULL,NULL),(72,3,3,2,3,0,0,'WorkflowTransition',NULL,NULL),(73,3,3,4,3,0,0,'WorkflowTransition',NULL,NULL),(74,3,3,5,3,0,0,'WorkflowTransition',NULL,NULL),(75,3,3,6,3,0,0,'WorkflowTransition',NULL,NULL),(76,3,4,1,3,0,0,'WorkflowTransition',NULL,NULL),(77,3,4,2,3,0,0,'WorkflowTransition',NULL,NULL),(78,3,4,3,3,0,0,'WorkflowTransition',NULL,NULL),(79,3,4,5,3,0,0,'WorkflowTransition',NULL,NULL),(80,3,4,6,3,0,0,'WorkflowTransition',NULL,NULL),(81,3,5,1,3,0,0,'WorkflowTransition',NULL,NULL),(82,3,5,2,3,0,0,'WorkflowTransition',NULL,NULL),(83,3,5,3,3,0,0,'WorkflowTransition',NULL,NULL),(84,3,5,4,3,0,0,'WorkflowTransition',NULL,NULL),(85,3,5,6,3,0,0,'WorkflowTransition',NULL,NULL),(86,3,6,1,3,0,0,'WorkflowTransition',NULL,NULL),(87,3,6,2,3,0,0,'WorkflowTransition',NULL,NULL),(88,3,6,3,3,0,0,'WorkflowTransition',NULL,NULL),(89,3,6,4,3,0,0,'WorkflowTransition',NULL,NULL),(90,3,6,5,3,0,0,'WorkflowTransition',NULL,NULL),(91,1,1,2,4,0,0,'WorkflowTransition',NULL,NULL),(92,1,1,3,4,0,0,'WorkflowTransition',NULL,NULL),(93,1,1,4,4,0,0,'WorkflowTransition',NULL,NULL),(94,1,1,5,4,0,0,'WorkflowTransition',NULL,NULL),(95,1,2,3,4,0,0,'WorkflowTransition',NULL,NULL),(96,1,2,4,4,0,0,'WorkflowTransition',NULL,NULL),(97,1,2,5,4,0,0,'WorkflowTransition',NULL,NULL),(98,1,3,2,4,0,0,'WorkflowTransition',NULL,NULL),(99,1,3,4,4,0,0,'WorkflowTransition',NULL,NULL),(100,1,3,5,4,0,0,'WorkflowTransition',NULL,NULL),(101,1,4,2,4,0,0,'WorkflowTransition',NULL,NULL),(102,1,4,3,4,0,0,'WorkflowTransition',NULL,NULL),(103,1,4,5,4,0,0,'WorkflowTransition',NULL,NULL),(104,2,1,2,4,0,0,'WorkflowTransition',NULL,NULL),(105,2,1,3,4,0,0,'WorkflowTransition',NULL,NULL),(106,2,1,4,4,0,0,'WorkflowTransition',NULL,NULL),(107,2,1,5,4,0,0,'WorkflowTransition',NULL,NULL),(108,2,2,3,4,0,0,'WorkflowTransition',NULL,NULL),(109,2,2,4,4,0,0,'WorkflowTransition',NULL,NULL),(110,2,2,5,4,0,0,'WorkflowTransition',NULL,NULL),(111,2,3,2,4,0,0,'WorkflowTransition',NULL,NULL),(112,2,3,4,4,0,0,'WorkflowTransition',NULL,NULL),(113,2,3,5,4,0,0,'WorkflowTransition',NULL,NULL),(114,2,4,2,4,0,0,'WorkflowTransition',NULL,NULL),(115,2,4,3,4,0,0,'WorkflowTransition',NULL,NULL),(116,2,4,5,4,0,0,'WorkflowTransition',NULL,NULL),(117,3,1,2,4,0,0,'WorkflowTransition',NULL,NULL),(118,3,1,3,4,0,0,'WorkflowTransition',NULL,NULL),(119,3,1,4,4,0,0,'WorkflowTransition',NULL,NULL),(120,3,1,5,4,0,0,'WorkflowTransition',NULL,NULL),(121,3,2,3,4,0,0,'WorkflowTransition',NULL,NULL),(122,3,2,4,4,0,0,'WorkflowTransition',NULL,NULL),(123,3,2,5,4,0,0,'WorkflowTransition',NULL,NULL),(124,3,3,2,4,0,0,'WorkflowTransition',NULL,NULL),(125,3,3,4,4,0,0,'WorkflowTransition',NULL,NULL),(126,3,3,5,4,0,0,'WorkflowTransition',NULL,NULL),(127,3,4,2,4,0,0,'WorkflowTransition',NULL,NULL),(128,3,4,3,4,0,0,'WorkflowTransition',NULL,NULL),(129,3,4,5,4,0,0,'WorkflowTransition',NULL,NULL),(130,1,1,5,5,0,0,'WorkflowTransition',NULL,NULL),(131,1,2,5,5,0,0,'WorkflowTransition',NULL,NULL),(132,1,3,5,5,0,0,'WorkflowTransition',NULL,NULL),(133,1,4,5,5,0,0,'WorkflowTransition',NULL,NULL),(134,1,3,4,5,0,0,'WorkflowTransition',NULL,NULL),(135,2,1,5,5,0,0,'WorkflowTransition',NULL,NULL),(136,2,2,5,5,0,0,'WorkflowTransition',NULL,NULL),(137,2,3,5,5,0,0,'WorkflowTransition',NULL,NULL),(138,2,4,5,5,0,0,'WorkflowTransition',NULL,NULL),(139,2,3,4,5,0,0,'WorkflowTransition',NULL,NULL),(140,3,1,5,5,0,0,'WorkflowTransition',NULL,NULL),(141,3,2,5,5,0,0,'WorkflowTransition',NULL,NULL),(142,3,3,5,5,0,0,'WorkflowTransition',NULL,NULL),(143,3,4,5,5,0,0,'WorkflowTransition',NULL,NULL),(144,3,3,4,5,0,0,'WorkflowTransition',NULL,NULL);
/*!40000 ALTER TABLE `workflows` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-01-13  7:36:30
